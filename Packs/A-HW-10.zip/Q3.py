class NetworkGraph:
    def __init__(self, num_routers):
        self.num_routers = num_routers
        self.matrix = [[0 for _ in range(num_routers)]
                       for _ in range(num_routers)]

    def add_link(self, u, v):
        self.matrix[u][v] = 1  # گراف جهت‌دار است

    def has_connection(self, start_router, target_router):
        if start_router == target_router:
            return True

        visited = [False] * self.num_routers
        stack = [start_router]

        while stack:
            current = stack.pop()
            if not visited[current]:
                visited[current] = True
                for i in range(self.num_routers):
                    if self.matrix[current][i] == 1:
                        if i == target_router:
                            return True
                        if not visited[i]:
                            stack.append(i)
        return False


# بخش اصلی برای خواندن ورودی و چاپ خروجی (مناسب برای Quera)
if __name__ == "__main__":
    num_routers = int(input().strip())
    num_links = int(input().strip())

    graph = NetworkGraph(num_routers)

    for _ in range(num_links):
        u, v = map(int, input().split())
        graph.add_link(u, v)

    start, target = map(int, input().split())

    result = graph.has_connection(start, target)
    print(result)
