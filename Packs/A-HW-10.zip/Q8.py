class AvengersRescueMission:
    def __init__(self, n, edges, energy_limit):
        self.n = n
        self.energy_limit = energy_limit
        # تشخیص وزن منفی
        for u, v, w in edges:
            if w < 0:
                raise ValueError(
                    "Loki's Chaos magic detected - Negative weights!")

        # ساخت گراف غیرجهت‌دار
        self.graph = [[] for _ in range(n)]
        for u, v, w in edges:
            self.graph[u].append((v, w))
            self.graph[v].append((u, w))

    def dijkstra(self, start, end):
        INF = float('inf')
        dist = [INF] * self.n
        visited = [False] * self.n
        dist[start] = 0

        for _ in range(self.n):
            u = -1
            best = INF
            for i in range(self.n):
                if not visited[i] and dist[i] < best:
                    best = dist[i]
                    u = i
            if u == -1:
                break
            visited[u] = True
            for v, w in self.graph[u]:
                if dist[u] + w < dist[v]:
                    dist[v] = dist[u] + w
        return dist[end]

    def get_edge_weight(self, u, v):
        for neighbor, w in self.graph[u]:
            if neighbor == v:
                return w
        return float('inf')

    def get_path(self, start, end):
        INF = float('inf')
        dist = [INF] * self.n
        parent = [None] * self.n
        visited = [False] * self.n
        dist[start] = 0

        for _ in range(self.n):
            u = -1
            best = INF
            for i in range(self.n):
                if not visited[i] and dist[i] < best:
                    best = dist[i]
                    u = i
            if u == -1:
                break
            visited[u] = True
            for v, w in self.graph[u]:
                if dist[u] + w < dist[v]:
                    dist[v] = dist[u] + w
                    parent[v] = u

        if dist[end] == INF:
            return []

        path = []
        cur = end
        while cur is not None:
            path.append(cur)
            cur = parent[cur]
        path.reverse()
        return path

    def compute_total_time(self, start, stone_locations):
        current = start
        energy_used = 0
        total_time = 0
        targets = stone_locations + [start]

        for target in targets:
            path = self.get_path(current, target)
            if not path:
                # مسیری وجود ندارد (در این سوال فرض می‌شود همیشه مسیر وجود دارد)
                return -1

            for i in range(1, len(path)):
                u = path[i-1]
                v = path[i]
                step_time = self.get_edge_weight(u, v)

                # اگر این حرکت باعث شود انرژی از حد بیشتر شود، قبل از حرکت شارژ کن
                if energy_used + step_time > self.energy_limit:
                    energy_used = 0  # شارژ

                energy_used += step_time
                total_time += step_time

            current = target

        return total_time


# --- اجرای اصلی برای Quera ---
if __name__ == "__main__":
    try:
        n = int(input().strip())
        m = int(input().strip())

        edges = []
        for _ in range(m):
            u, v, w = map(int, input().split())
            edges.append((u, v, w))

        energy_limit = int(input().strip())
        start = int(input().strip())
        k = int(input().strip())

        if k == 0:
            stone_locations = []
        else:
            stone_locations = list(map(int, input().split()))

        mission = AvengersRescueMission(n, edges, energy_limit)
        total = mission.compute_total_time(start, stone_locations)
        print(total)

    except ValueError as e:
        print(e)
