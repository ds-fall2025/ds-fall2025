class OptimizedPowerNetwork:
    def __init__(self, num_nodes, edges):
        self.n = num_nodes
        self.edges = edges
        self.dist = None
        self.parent = None

    def compute_shortest_paths(self, source):
        INF = float('inf')
        self.dist = [INF] * self.n
        self.parent = [None] * self.n
        self.dist[source] = 0

        # Relax یال‌ها (n-1) بار
        for _ in range(self.n - 1):
            updated = False
            for u, v, w in self.edges:
                if self.dist[u] != INF and self.dist[u] + w < self.dist[v]:
                    self.dist[v] = self.dist[u] + w
                    self.parent[v] = u
                    updated = True
            if not updated:
                break

        # چک کردن چرخه منفی
        self.has_negative_cycle = False
        for u, v, w in self.edges:
            if self.dist[u] != INF and self.dist[u] + w < self.dist[v]:
                self.has_negative_cycle = True
                break

    def get_distance(self, target):
        return self.dist[target]


# --- بخش اصلی برای Quera ---
if __name__ == "__main__":
    # خواندن تمام ورودی
    data = []
    try:
        while True:
            line = input().strip()
            if line == '':
                break
            data.extend(line.split())
    except EOFError:
        pass

    # تبدیل به اعداد
    n = int(data[0])
    m = int(data[1])
    edges = []
    idx = 2
    for i in range(m):
        u = int(data[idx])
        v = int(data[idx+1])
        w = int(data[idx+2])
        idx += 3
        edges.append((u, v, w))
    s = int(data[idx])
    t = int(data[idx+1])

    # محاسبه
    network = OptimizedPowerNetwork(n, edges)
    network.compute_shortest_paths(s)

    if network.has_negative_cycle:
        print("هشدار: چرخه منفی در شبکه کشف شد!")
    else:
        dist = network.get_distance(t)
        if dist == float('inf'):
            print("inf")
        else:
            # اگر عدد صحیح است، به عنوان int چاپ کن (برای جلوگیری از .0)
            if dist == int(dist):
                print(int(dist))
            else:
                print(dist)
