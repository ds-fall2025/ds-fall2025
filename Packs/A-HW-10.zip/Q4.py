class InfectionTracker:
    def __init__(self, num_servers, num_edges):
        self.n = num_servers
        # لیست مجاورت برای پیمایش (برای DFS اولیه)
        self.adj = [[] for _ in range(num_servers)]
        # ماتریس وقوع (برای رعایت شرط سوال — در محاسبه flow استفاده نمی‌شود ولی وجود دارد)
        self.incidence = [[0] * num_edges for _ in range(num_servers)]
        # residual graph برای max-flow (ظرفیت‌ها 0 یا 1)
        self.residual = [[0] * num_servers for _ in range(num_servers)]

    def add_edge(self, u, v, edge_id):
        self.adj[u].append(v)
        self.incidence[u][edge_id] = 1
        self.incidence[v][edge_id] = -1
        self.residual[u][v] = 1  # ظرفیت اولیه = 1

    def _has_any_path(self, s, t):
        """بررسی اولیه وجود مسیر (بدون flow)"""
        visited = [False] * self.n
        stack = [s]
        while stack:
            u = stack.pop()
            if u == t:
                return True
            if not visited[u]:
                visited[u] = True
                for v in self.adj[u]:
                    if not visited[v]:
                        stack.append(v)
        return False

    def _dfs_for_flow(self, u, t, visited):
        """DFS برای پیدا کردن یک مسیر افزایشی در residual graph"""
        if u == t:
            return True
        visited[u] = True
        for v in range(self.n):
            if not visited[v] and self.residual[u][v] > 0:
                if self._dfs_for_flow(v, t, visited):
                    # به‌روزرسانی residual graph
                    self.residual[u][v] -= 1
                    self.residual[v][u] += 1
                    return True
        return False

    def find_cut_edges(self, start, target):
        if start == target:
            return 0

        # اگر اصلاً مسیری نیست، -1 برگردان
        if not self._has_any_path(start, target):
            return -1

        max_flow = 0
        while True:
            visited = [False] * self.n
            if self._dfs_for_flow(start, target, visited):
                max_flow += 1
            else:
                break

        return max_flow


# --- بخش اصلی برای Quera ---
if __name__ == "__main__":
    num_servers = int(input().strip())
    num_edges = int(input().strip())

    tracker = InfectionTracker(num_servers, num_edges)

    for edge_id in range(num_edges):
        parts = input().split()
        u = int(parts[0])
        v = int(parts[1])
        eid = int(parts[2])
        tracker.add_edge(u, v, eid)

    start, target = map(int, input().split())

    result = tracker.find_cut_edges(start, target)
    print(result)
