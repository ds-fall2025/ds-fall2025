# Bubble Sort - One Pass Check
# ورودی: لیست اعداد با جداکننده‌ی کاما
# خروجی: فقط YES یا NO

def is_sorted(arr):
    """بررسی می‌کند که آیا آرایه صعودی مرتب است یا نه."""
    for i in range(len(arr) - 1):
        if arr[i] > arr[i + 1]:
            return False
    return True

def one_pass_bubble_sort(arr):
    """فقط یک پاس از الگوریتم مرتب‌سازی حبابی را اجرا می‌کند."""
    n = len(arr)
    for i in range(n - 1):
        if arr[i] > arr[i + 1]:
            arr[i], arr[i + 1] = arr[i + 1], arr[i]
    return arr

# --- دریافت ورودی ---
data = input().strip()
arr = list(map(int, data.split(',')))

# --- اجرای یک پاس ---
after_pass = one_pass_bubble_sort(arr)

# --- بررسی مرتب بودن ---
if is_sorted(after_pass):
    print("YES")
else:
    print("NO")