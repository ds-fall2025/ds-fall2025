### تمام توضیحات به زبان انگلیسی نوشته شده‌ن تا از مشکلات تراز چپ-راست جلوگیری بشه ###

### چندین بخش از این کد صرفا برای درک بهتر گنجونده شده و می‌تونن حذف یا کامنت‌گذاری بشن ###



def cocktail_shaker_sort(arr):
    """
    Cocktail Shaker Sort algorithm (bidirectional bubble sort)
    Sorts array while counting comparisons and swaps
    
    Args:
        arr: List of integers to sort
        
    Returns:
        tuple: (sorted_array, comparisons, swaps)
    """
    n = len(arr)
    comparisons = 0  # Counter for number of comparisons
    swaps = 0        # Counter for number of swaps
    
    # Initially, we need to traverse the entire array
    start = 0
    end = n - 1
    
    # Flag to check if any swap happened in current iteration
    swapped = True
    
    # Continue until no swaps occur (array is sorted)
    while swapped:
        # Reset swapped flag at the beginning of each iteration
        swapped = False
        
        # FORWARD PASS: Move from left to right (like bubble sort)
        # This pushes larger elements towards the end
        for i in range(start, end):
            comparisons += 1  # Count this comparison
            
            # Compare adjacent elements
            if arr[i] > arr[i + 1]:
                # Swap if left element is greater than right
                arr[i], arr[i + 1] = arr[i + 1], arr[i]
                swaps += 1      # Count this swap
                swapped = True  # Mark that a swap occurred
        
        # If no swaps occurred in forward pass, array is sorted
        if not swapped:
            break
        
        # Decrease end pointer since largest element is now at correct position
        end -= 1
        
        # Reset swapped flag for backward pass
        swapped = False
        
        # BACKWARD PASS: Move from right to left
        # This pushes smaller elements towards the beginning
        for i in range(end, start, -1):
            comparisons += 1  # Count this comparison
            
            # Compare adjacent elements
            if arr[i] < arr[i - 1]:
                # Swap if right element is smaller than left
                arr[i], arr[i - 1] = arr[i - 1], arr[i]
                swaps += 1      # Count this swap
                swapped = True  # Mark that a swap occurred
        
        # Increase start pointer since smallest element is now at correct position
        start += 1
    
    return arr, comparisons, swaps


def main():
    """
    Main function to test Cocktail Shaker Sort for Willy Wonka's chocolate factory
    """
    print("🍫 Willy Wonka's Chocolate Factory Sorting System 🍫")
    print("Oompa-Loompas using Cocktail Shaker Sort!")
    print("=" * 60)
    
    # Get input from user
    print("Enter chocolate box weights (space-separated, can include decimals):")
    print("Example: 8 3.5 1 7.2 4 6.8 2 5")
    
    try:
        # Read input and convert to list of floats
        user_input = input("Weights: ").strip()
        
        if not user_input:
            print("No input provided! Using default example...")
            weights = [8, 3.5, 1, 7.2, 4, 6.8, 2, 5]
        else:
            weights = list(map(float, user_input.split()))
        
        print(f"\nOriginal weights: {weights}")
        print("\nSorting in progress...")
        print("-" * 40)
        
        # Perform cocktail shaker sort
        sorted_weights, comparisons, swaps = cocktail_shaker_sort(weights.copy())
        
        # Output results in required format
        print("\n" + "=" * 60)
        print("RESULTS:")
        print("=" * 60)
        print(sorted_weights)
        print(comparisons)
        print(swaps)
        
        # Additional info (not required by problem, but helpful)
        print("\n" + "-" * 60)
        print("Willy Wonka: 'Excellent work, Oompa-Loompas!'")
        print(f"Total comparisons: {comparisons}")
        print(f"Total swaps: {swaps}")
        print("Charlie and Grandpa Joe are impressed!")
        
    except ValueError:
        print("Invalid input! Please enter numbers only.")
        print("Example: 8 3.5 1 7.2 4 6.8 2 5")
    except Exception as e:
        print(f"An error occurred: {e}")


# Time Complexity Analysis:
"""
🕐 Time Complexity:
- Best Case: O(n) - When array is already sorted, only one forward pass needed
- Average Case: O(n²) - Similar to bubble sort
- Worst Case: O(n²) - When array is reverse sorted

🔄 Space Complexity: O(1) - In-place sorting, only uses constant extra space

💡 Why faster than regular Bubble Sort?
- Regular bubble sort only moves in one direction
- Cocktail sort moves both directions, so small elements at the end 
  move to the beginning faster (turtles move faster!)
- Can terminate earlier if array becomes sorted
"""

if __name__ == "__main__":
    main()