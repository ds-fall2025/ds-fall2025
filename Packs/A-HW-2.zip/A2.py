### تمام توضیحات به زبان انگلیسی نوشته شده‌ن تا از مشکلات تراز چپ-راست جلوگیری بشه ###

### چندین بخش از این کد صرفا برای درک بهتر گنجونده شده و می‌تونن حذف یا کامنت‌گذاری بشن ###



def shell_sort(arr):
    """
    Shell Sort algorithm with comparison and swap counting
    More efficient than insertion sort due to gap-based sorting
    
    Args:
        arr: List of integers to sort (Agent entry timestamps)
        
    Returns:
        tuple: (sorted_array, comparisons, swaps)
    """
    n = len(arr)
    comparisons = 0  # Counter for number of comparisons
    swaps = 0        # Counter for number of swaps
    
    # Start with a large gap, then reduce it
    # Using gap = n // 2 and halving each iteration (Shell's original sequence)
    gap = n // 2
    
    # Continue until gap becomes 0
    while gap > 0:
        # Perform gapped insertion sort for this gap size
        # Elements at gap distance apart are sorted
        
        # Start from gap-th element and go through the array
        for i in range(gap, n):
            # Store current element to be positioned
            temp = arr[i]
            j = i
            
            # Shift earlier gap-sorted elements up until correct location found
            # This is like insertion sort but with gap distance instead of 1
            while j >= gap:
                comparisons += 1  # Count this comparison
                
                if arr[j - gap] > temp:
                    # Move element at (j-gap) position forward by gap
                    arr[j] = arr[j - gap]
                    swaps += 1      # Count this as a swap/move
                    j -= gap        # Move to next gap position
                else:
                    # Found correct position, break
                    break
            
            # Place temp at its correct position
            if arr[j] != temp:
                arr[j] = temp
        
        # Reduce gap for next iteration
        gap //= 2
    
    return arr, comparisons, swaps


def main():
    """
    Main function to test Shell Sort for Matrix security system
    """
    print("🎬 Matrix Security System - Agent Entry Analysis 🎬")
    print("Neo using Shell Sort to identify attack pattern!")
    print("=" * 60)
    
    # Get input from user
    print("Enter Agent entry timestamps in seconds (space-separated, can include decimals):")
    print("Example: 29 10.5 14 37.2 13 25.8 18")
    
    try:
        # Read input and convert to list of floats
        user_input = input("Timestamps: ").strip()
        
        if not user_input:
            print("No input provided! Using default example...")
            timestamps = [29, 10.5, 14, 37.2, 13, 25.8, 18]
        else:
            timestamps = list(map(float, user_input.split()))
        
        print(f"\nOriginal timestamps: {timestamps}")
        print("\nAnalyzing attack pattern...")
        print("-" * 40)
        
        # Perform shell sort
        sorted_timestamps, comparisons, swaps = shell_sort(timestamps.copy())
        
        # Output results in required format
        print("\n" + "=" * 60)
        print("RESULTS:")
        print("=" * 60)
        print(sorted_timestamps)
        print(comparisons)
        print(swaps)
        
        # Additional info (not required by problem, but helpful)
        print("\n" + "-" * 60)
        print("Morpheus: 'You're starting to believe, Neo!'")
        print(f"Total comparisons: {comparisons}")
        print(f"Total swaps: {swaps}")
        print("Attack pattern identified successfully!")
        
    except ValueError:
        print("Invalid input! Please enter numbers only.")
        print("Example: 29 10.5 14 37.2 13 25.8 18")
    except Exception as e:
        print(f"An error occurred: {e}")


# Time Complexity Analysis:
"""
🕐 Time Complexity:
- Best Case: O(n log n) - When array is already sorted or nearly sorted
  Shell sort makes fewer comparisons as gaps decrease
  
- Average Case: O(n^1.3) to O(n^1.5) - Depends on gap sequence
  Much better than O(n²) of insertion sort
  
- Worst Case: O(n²) - With poor gap sequence
  But in practice performs much better than insertion sort

🔄 Space Complexity: O(1) - In-place sorting, only uses constant extra space

💡 Why Shell Sort is faster than Insertion Sort:
1. Large gaps move elements quickly towards their final position
2. By the time gap=1 (regular insertion sort), array is nearly sorted
3. Insertion sort on nearly-sorted arrays is very fast (close to O(n))
4. Small elements at the end don't need to bubble all the way to start

📊 Gap Sequence:
- We use Shell's original: n/2, n/4, n/8, ..., 1
- Other sequences (Knuth, Sedgewick) can be even more efficient
- Choice of gap sequence affects performance significantly

🎯 When to use Shell Sort:
- Medium-sized arrays (100-5000 elements)
- When you need better than O(n²) but can't use O(n log n) complex algorithms
- Embedded systems with limited memory
- When simplicity is valued (easier than quicksort/mergesort)
"""

if __name__ == "__main__":
    main()