class Stack:
    """
    کلاس پیاده‌سازی ساختار داده پشته (Stack)
    
    این کلاس یک پشته با عملیات‌های استاندارد LIFO را پیاده‌سازی می‌کند
    """
    
    def __init__(self, max_capacity=3):
        """
        سازنده کلاس - مقداردهی اولیه پشته
        
        ورودی:
            max_capacity: حداکثر ظرفیت پشته (پیش‌فرض 3)
        """
        self.items = []  # لیست برای ذخیره عناصر پشته
        self.max_capacity = max_capacity  # حداکثر ظرفیت پشته
    
    def push(self, item):
        """
        اضافه کردن یک عنصر به بالای پشته
        
        ورودی:
            item: عنصر برای اضافه کردن
        """
        # اگر پشته پر باشد، قدیمی‌ترین عنصر (ته پشته) حذف می‌شود
        if self.is_full():
            self.remove_bottom()
        
        # افزودن عنصر جدید به بالای پشته
        self.items.append(item)
    
    def pop(self):
        """
        حذف و برگرداندن عنصر بالای پشته
        
        خروجی:
            عنصر حذف شده از بالای پشته یا None اگر پشته خالی باشد
        """
        if not self.is_empty():
            return self.items.pop()  # حذف و برگرداندن آخرین عنصر
        return None
    
    def peek(self):
        """
        مشاهده عنصر بالای پشته بدون حذف
        
        خروجی:
            عنصر بالای پشته یا None اگر پشته خالی باشد
        """
        if not self.is_empty():
            return self.items[-1]  # برگرداندن آخرین عنصر بدون حذف
        return None
    
    def is_empty(self):
        """
        بررسی خالی بودن پشته
        
        خروجی:
            True اگر پشته خالی باشد، در غیر این صورت False
        """
        return len(self.items) == 0
    
    def is_full(self):
        """
        بررسی پر بودن پشته
        
        خروجی:
            True اگر پشته پر باشد، در غیر این صورت False
        """
        return len(self.items) >= self.max_capacity
    
    def size(self):
        """
        برگرداندن تعداد عناصر پشته
        
        خروجی:
            تعداد عناصر موجود در پشته
        """
        return len(self.items)
    
    def clear(self):
        """
        خالی کردن کامل پشته
        """
        self.items = []
    
    def remove_bottom(self):
        """
        حذف قدیمی‌ترین عنصر (ته پشته) با استفاده از پشته کمکی
        
        این تابع برای مدیریت حافظه محدود استفاده می‌شود
        """
        # ایجاد یک پشته کمکی برای ذخیره موقت عناصر
        temp_stack = Stack(max_capacity=self.max_capacity)
        
        # انتقال تمام عناصر به پشته کمکی (به جز عنصر ته)
        while self.size() > 1:
            temp_stack.push(self.pop())
        
        # حذف آخرین عنصر باقی‌مانده (ته پشته اصلی)
        self.pop()
        
        # بازگرداندن عناصر از پشته کمکی به پشته اصلی
        while not temp_stack.is_empty():
            # self.items.insert(0, temp_stack.pop())
            self.push(temp_stack.pop())
    
    def to_list(self):
        """
        تبدیل پشته به لیست برای نمایش از ته به بالا
        
        خروجی:
            لیست عناصر پشته از ته (اولین عنصر اضافه شده) به بالا (آخرین عنصر)
        
        توضیح:
            در پشته، items[0] ته پشته و items[-1] بالای پشته است
            برای نمایش از ته به بالا، همان ترتیب لیست را برمی‌گردانیم
        """
        # برگرداندن لیست از ته (اندیس 0) به بالا (اندیس -1)
        return self.items.copy()


class BrowserHistory:
    """
    کلاس مدیریت تاریخچه مرورگر با پشته و حافظه محدود
    
    این کلاس قابلیت جابه‌جایی بین صفحات با دکمه‌های Back و Forward را
    با استفاده از دو پشته شبیه‌سازی می‌کند
    """
    
    def __init__(self):
        """
        سازنده کلاس - مقداردهی اولیه سیستم تاریخچه
        """
        self.back_stack = Stack(max_capacity=3)  # پشته صفحات قبلی
        self.forward_stack = Stack(max_capacity=3)  # پشته صفحات بعدی
        self.current_page = None  # صفحه فعلی که در حال نمایش است
    
    def visit(self, url):
        """
        باز کردن یک صفحه جدید
        
        ورودی:
            url: آدرس صفحه جدید
        """
        # بررسی معتبر بودن URL
        if not url or url.strip() == "":
            print("Invalid URL")
            return
        
        # اگر صفحه فعلی وجود دارد، آن را به پشته Back اضافه کن
        if self.current_page is not None:
            self.back_stack.push(self.current_page)
        
        # تنظیم صفحه جدید به عنوان صفحه فعلی
        self.current_page = url
        
        # پاک کردن کامل پشته Forward (طبق قوانین مرورگر)
        self.forward_stack.clear()
        
        # نمایش پیام باز شدن صفحه
        print(f"Page opened: {url}")
    
    def back(self):
        """
        بازگشت به صفحه قبلی
        """
        # بررسی خالی بودن پشته Back
        if self.back_stack.is_empty():
            print("No previous page to go back")
            return
        
        # انتقال صفحه فعلی به پشته Forward
        self.forward_stack.push(self.current_page)
        
        # برداشتن آخرین صفحه از پشته Back و تنظیم به عنوان صفحه فعلی
        self.current_page = self.back_stack.pop()
        
        # نمایش پیام بازگشت
        print(f"Back to: {self.current_page}")
    
    def forward(self):
        """
        حرکت به صفحه بعدی
        """
        # بررسی خالی بودن پشته Forward
        if self.forward_stack.is_empty():
            print("No next page to go forward")
            return
        
        # انتقال صفحه فعلی به پشته Back
        self.back_stack.push(self.current_page)
        
        # برداشتن آخرین صفحه از پشته Forward و تنظیم به عنوان صفحه فعلی
        self.current_page = self.forward_stack.pop()
        
        # نمایش پیام پیشروی
        print(f"Forward to: {self.current_page}")
    
    def show(self):
        """
        نمایش وضعیت فعلی سیستم (صفحه فعلی و دو پشته)
        
        نمایش پشته‌ها از ته به بالا:
        - ته پشته: اولین عنصری که اضافه شده (قدیمی‌ترین)
        - بالای پشته: آخرین عنصری که اضافه شده (جدیدترین)
        """
        # نمایش صفحه فعلی
        print(f"Current Page: {self.current_page}")
        
        # نمایش محتوای پشته Back از ته به بالا
        back_list = self.back_stack.to_list()
        print(f"Back Stack: {back_list}")
        
        # نمایش محتوای پشته Forward از ته به بالا
        forward_list = self.forward_stack.to_list()
        print(f"Forward Stack: {forward_list}")


def main():
    """
    تابع اصلی برنامه - دریافت دستورات و اجرای آن‌ها
    """
    # ایجاد نمونه از سیستم تاریخچه مرورگر
    browser = BrowserHistory()
    
    # حلقه اصلی برای دریافت و پردازش دستورات
    while True:
        # دریافت دستور از کاربر
        command = input().strip()
        
        # بررسی خالی بودن دستور
        if not command:
            continue
        
        # تجزیه دستور به قسمت‌های مختلف
        parts = command.split(maxsplit=1)
        action = parts[0].lower()  # دستور اصلی (حروف کوچک)
        
        # اجرای دستور مناسب
        if action == "visit":
            # دستور باز کردن صفحه جدید
            if len(parts) == 2:
                url = parts[1].strip()
                browser.visit(url)
            else:
                print("Invalid URL")
        
        elif action == "back":
            # دستور بازگشت به عقب
            browser.back()
        
        elif action == "forward":
            # دستور حرکت به جلو
            browser.forward()
        
        elif action == "show":
            # دستور نمایش وضعیت
            browser.show()
        
        elif action == "exit":
            # دستور خروج از برنامه
            break
        
        else:
            # دستور نامعتبر
            print("Invalid command")


# نقطه شروع برنامه
if __name__ == "__main__":
    main()

