class CircularQueue:
    """
    کلاس مدیریت صف چرخشی درخواست‌های امداد و نجات
    
    این کلاس یک صف چرخشی (Circular Queue) را پیاده‌سازی می‌کند که
    درخواست‌های امداد را بر اساس اولویت (ID) مدیریت می‌کند.
    """
    
    def __init__(self, capacity):
        """
        سازنده کلاس - مقداردهی اولیه صف
        
        ورودی:
            capacity: ظرفیت صف (تعداد حداکثر درخواست‌ها)
        """
        self.capacity = capacity  # ظرفیت کل صف
        self.queue = [None] * capacity  # آرایه ذخیره‌سازی صف
        self.front_index = -1  # اشاره‌گر به ابتدای صف
        self.rear_index = -1  # اشاره‌گر به انتهای صف
        self.size = 0  # تعداد عناصر فعلی در صف
    
    def is_empty(self):
        """
        بررسی خالی بودن صف
        
        خروجی:
            True اگر صف خالی باشد، در غیر این صورت False
        """
        return self.size == 0
    
    def is_full(self):
        """
        بررسی پر بودن صف
        
        خروجی:
            True اگر صف پر باشد، در غیر این صورت False
        """
        return self.size == self.capacity
    
    def is_duplicate(self, id):
        """
        بررسی تکراری بودن ID در صف
        
        ورودی:
            id: شناسه حادثه برای بررسی
        
        خروجی:
            True اگر ID تکراری باشد، در غیر این صورت False
        """
        # اگر صف خالی است، تکراری نیست
        if self.is_empty():
            return False
        
        # بررسی تمام عناصر موجود در صف
        i = self.front_index
        for _ in range(self.size):
            if self.queue[i] == id:
                return True
            i = (i + 1) % self.capacity  # حرکت چرخشی در صف
        
        return False
    
    def enqueue(self, id):
        """
        درج یک درخواست جدید در صف بر اساس اولویت
        
        ورودی:
            id: شناسه حادثه (باید بین 1 تا 100 باشد)
        
        قوانین درج:
            - اگر id > 50: در ابتدای صف (front) اضافه می‌شود
            - اگر id <= 50: در انتهای صف (rear) اضافه می‌شود
        """
        # بررسی اعتبار ID (باید بین 1 تا 100 باشد)
        if id < 1 or id > 100:
            print("ERROR")
            return
        
        # بررسی پر بودن صف
        if self.is_full():
            print("FULL")
            return
        
        # بررسی تکراری بودن ID
        if self.is_duplicate(id):
            print("DUPLICATE")
            return
        
        # اگر صف خالی است
        if self.is_empty():
            self.front_index = 0
            self.rear_index = 0
            self.queue[0] = id
            self.size = 1
        else:
            # اگر ID > 50: اضافه کردن به ابتدای صف (اولویت بالا)
            if id > 50:
                # جابجایی front به عقب به صورت چرخشی
                self.front_index = (self.front_index - 1 + self.capacity) % self.capacity
                self.queue[self.front_index] = id
                self.size += 1
            # اگر ID <= 50: اضافه کردن به انتهای صف (اولویت پایین)
            else:
                # جابجایی rear به جلو به صورت چرخشی
                self.rear_index = (self.rear_index + 1) % self.capacity
                self.queue[self.rear_index] = id
                self.size += 1
        
        # نمایش وضعیت فعلی صف
        self.display()
    
    def sort_queue(self):
        """
        مرتب‌سازی نزولی عناصر صف با استفاده از الگوریتم Insertion Sort
        
        این تابع فقط عناصر موجود در صف را مرتب می‌کند (نه کل آرایه)
        مرتب‌سازی نزولی: از بزرگ به کوچک (اولویت بالاتر اول)
        """
        # اگر صف خالی یا فقط یک عنصر دارد، نیازی به مرتب‌سازی نیست
        if self.size <= 1:
            return
        
        # کپی کردن عناصر صف به یک آرایه موقت
        temp = []
        i = self.front_index
        for _ in range(self.size):
            temp.append(self.queue[i])
            i = (i + 1) % self.capacity
        
        # مرتب‌سازی درجی (Insertion Sort) به صورت نزولی
        for j in range(1, len(temp)):
            key = temp[j]  # عنصر جاری برای قرار دادن در جای مناسب
            k = j - 1
            
            # جابجایی عناصر کوچک‌تر از key به سمت راست
            while k >= 0 and temp[k] < key:  # نزولی: اگر temp[k] کوچک‌تر از key باشد
                temp[k + 1] = temp[k]
                k -= 1
            
            temp[k + 1] = key  # قرار دادن key در موقعیت صحیح
        
        # بازگشت عناصر مرتب‌شده به صف
        i = self.front_index
        for j in range(self.size):
            self.queue[i] = temp[j]
            i = (i + 1) % self.capacity
    
    def dequeue(self):
        """
        حذف درخواست با بالاترین اولویت از ابتدای صف
        
        قبل از حذف، صف مرتب‌سازی می‌شود تا درخواست با ID بزرگ‌تر حذف شود
        """
        # بررسی خالی بودن صف
        if self.is_empty():
            print("EMPTY")
            return
        
        # مرتب‌سازی صف قبل از حذف
        self.sort_queue()
        
        # حذف عنصر از ابتدای صف
        removed_id = self.queue[self.front_index]
        self.queue[self.front_index] = None  # خالی کردن خانه
        
        # اگر فقط یک عنصر در صف بود، صف خالی می‌شود
        if self.front_index == self.rear_index:
            self.front_index = -1
            self.rear_index = -1
        else:
            # انتقال front به خانه بعدی به صورت چرخشی
            self.front_index = (self.front_index + 1) % self.capacity
        
        self.size -= 1  # کاهش تعداد عناصر صف
        
        # چاپ ID حذف شده
        print(removed_id)
        
        # نمایش وضعیت فعلی صف
        self.display()
    
    def display(self):
        """
        نمایش وضعیت فعلی صف از front تا rear به صورت چرخشی
        """
        # اگر صف خالی است
        if self.is_empty():
            print("Queue: []")
            return
        
        # ساخت لیست عناصر صف برای نمایش
        elements = []
        i = self.front_index
        for _ in range(self.size):
            elements.append(str(self.queue[i]))
            i = (i + 1) % self.capacity  # حرکت چرخشی
        
        # چاپ عناصر با فرمت "Queue: elem1 elem2 ..."
        print("Queue: " + " ".join(elements))
    
    def front(self):
        """
        نمایش ID حادثه‌ای که در ابتدای صف است (بدون حذف)
        """
        # بررسی خالی بودن صف
        if self.is_empty():
            print("EMPTY")
            return
        
        # چاپ عنصر موجود در ابتدای صف با فرمت "Front: value"
        print(f"Front: {self.queue[self.front_index]}")


def get_valid_integer(prompt=""):
    """
    دریافت یک عدد صحیح معتبر از کاربر
    
    ورودی:
        prompt: پیام نمایشی (اختیاری)
    
    خروجی:
        عدد صحیح معتبر
    
    این تابع تا زمانی که ورودی معتبر دریافت نکند، ادامه می‌دهد
    """
    while True:
        try:
            # دریافت ورودی از کاربر
            user_input = input(prompt).strip()
            
            # تبدیل به عدد صحیح
            value = int(user_input)
            
            return value
        
        except ValueError:
            # اگر ورودی قابل تبدیل به عدد نباشد
            print("INVALID INPUT")
        except EOFError:
            # پایان ورودی
            return None


def get_valid_command():
    """
    دریافت یک دستور معتبر از کاربر
    
    خروجی:
        tuple: (نام دستور, لیست پارامترها) یا None در صورت پایان ورودی
    
    این تابع تا زمانی که دستور معتبر دریافت نکند، ادامه می‌دهد
    """
    while True:
        try:
            # دریافت دستور از کاربر
            command_line = input().strip()
            
            # بررسی خالی بودن دستور
            if not command_line:
                print("INVALID INPUT")
                continue
            
            # تجزیه دستور
            command_parts = command_line.split()
            
            # بررسی وجود دستور
            if len(command_parts) == 0:
                print("INVALID INPUT")
                continue
            
            # دریافت نام دستور (حروف بزرگ)
            command = command_parts[0].upper()
            
            # بررسی معتبر بودن دستور
            valid_commands = ["ENQUEUE", "DEQUEUE", "DISPLAY", "FRONT"]
            
            if command not in valid_commands:
                print("INVALID INPUT")
                continue
            
            return command, command_parts
        
        except EOFError:
            # پایان ورودی
            return None, None


def main():
    """
    تابع اصلی برنامه - دریافت ورودی و اجرای عملیات‌ها
    """
    # دریافت ظرفیت صف از کاربر (با اعتبارسنجی)
    while True:
        n = get_valid_integer()
        
        # بررسی پایان ورودی
        if n is None:
            return
        
        # بررسی معتبر بودن ظرفیت
        if n <= 0:
            print("INVALID INPUT")
            continue
        
        # ظرفیت معتبر دریافت شد
        break
    
    # ایجاد یک نمونه از صف امداد با ظرفیت n
    emergency_queue = CircularQueue(n)
    
    # دریافت تعداد عملیات‌ها (با اعتبارسنجی)
    while True:
        m = get_valid_integer()
        
        # بررسی پایان ورودی
        if m is None:
            return
        
        # بررسی معتبر بودن تعداد عملیات
        if m < 0:
            print("INVALID INPUT")
            continue
        
        # تعداد عملیات معتبر دریافت شد
        break
    
    # پردازش هر عملیات
    operations_processed = 0
    
    while operations_processed < m:
        # دریافت دستور معتبر
        command, command_parts = get_valid_command()
        
        # بررسی پایان ورودی
        if command is None:
            return
        
        # پردازش دستور بر اساس نوع آن
        if command == "ENQUEUE":
            # بررسی وجود پارامتر ID
            if len(command_parts) != 2:
                print("INVALID INPUT")
                continue
            
            try:
                # دریافت ID از دستور و تبدیل به عدد صحیح
                id = int(command_parts[1])
                emergency_queue.enqueue(id)
                operations_processed += 1
            except ValueError:
                # اگر ID یک عدد صحیح نباشد
                print("INVALID INPUT")
        
        elif command == "DEQUEUE":
            # بررسی اینکه دستور DEQUEUE پارامتر اضافی نداشته باشد
            if len(command_parts) != 1:
                print("INVALID INPUT")
                continue
            
            emergency_queue.dequeue()
            operations_processed += 1
        
        elif command == "DISPLAY":
            # بررسی اینکه دستور DISPLAY پارامتر اضافی نداشته باشد
            if len(command_parts) != 1:
                print("INVALID INPUT")
                continue
            
            emergency_queue.display()
            operations_processed += 1
        
        elif command == "FRONT":
            # بررسی اینکه دستور FRONT پارامتر اضافی نداشته باشد
            if len(command_parts) != 1:
                print("INVALID INPUT")
                continue
            
            emergency_queue.front()
            operations_processed += 1


# نقطه شروع برنامه
if __name__ == "__main__":
    main()
