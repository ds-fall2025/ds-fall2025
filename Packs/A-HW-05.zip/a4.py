class Node:
    """
    کلاس گره (Node) برای نمایش یک خانه در لیست پیوندی
    
    هر گره شامل اطلاعات یک خانه و اشاره‌گر به خانه بعدی است
    """
    
    def __init__(self, house_id, room_count):
        """
        سازنده کلاس - مقداردهی اولیه گره
        
        ورودی:
            house_id: شماره منحصربه‌فرد خانه
            room_count: تعداد اتاق‌های خانه
        """
        self.house_id = house_id  # شماره خانه
        self.room_count = room_count  # تعداد اتاق‌ها
        self.next = None  # اشاره‌گر به گره بعدی (در ابتدا None)


class HouseReservationSystem:
    """
    کلاس سامانه رزرو خانه با استفاده از لیست پیوندی یک‌طرفه
    
    این کلاس خانه‌های خالی را مدیریت کرده و امکان افزودن، رزرو و نمایش را فراهم می‌کند
    """
    
    def __init__(self):
        """
        سازنده کلاس - مقداردهی اولیه لیست پیوندی
        """
        self.head = None  # اشاره‌گر به اولین خانه در لیست (در ابتدا خالی)
    
    def add_house(self, house_id, room_count):
        """
        افزودن خانه جدید به لیست به ترتیب صعودی house_id
        
        ورودی:
            house_id: شماره خانه (باید عدد صحیح مثبت باشد)
            room_count: تعداد اتاق‌ها (باید عدد صحیح مثبت باشد)
        """
        # بررسی معتبر بودن house_id و room_count (باید عدد صحیح مثبت باشند)
        if not isinstance(house_id, int) or house_id <= 0:
            print("invalid input")
            return
        
        if not isinstance(room_count, int) or room_count <= 0:
            print("invalid input")
            return
        
        # بررسی تکراری بودن house_id
        current = self.head
        while current is not None:
            if current.house_id == house_id:
                print("duplicate house id")
                return
            current = current.next
        
        # ایجاد گره جدید
        new_node = Node(house_id, room_count)
        
        # حالت 1: لیست خالی است یا باید در ابتدای لیست قرار گیرد
        if self.head is None or self.head.house_id > house_id:
            new_node.next = self.head
            self.head = new_node
            print(f"house {house_id} with {room_count} rooms added")
            return
        
        # حالت 2: جستجو برای یافتن موقعیت مناسب در وسط یا انتهای لیست
        current = self.head
        while current.next is not None and current.next.house_id < house_id:
            current = current.next
        
        # درج گره جدید در موقعیت مناسب
        new_node.next = current.next
        current.next = new_node
        
        print(f"house {house_id} with {room_count} rooms added")
    
    def request_house(self, requested_rooms):
        """
        رزرو خانه بر اساس تعداد اتاق درخواستی
        
        ورودی:
            requested_rooms: تعداد اتاق‌های درخواستی (باید عدد صحیح مثبت باشد)
        
        الگوریتم انتخاب:
            1. اولویت اول: خانه با تعداد اتاق دقیقاً برابر با درخواست
            2. اولویت دوم: خانه با کمترین اختلاف نسبت به درخواست (بیشتر از درخواست)
            3. در صورت تساوی: خانه با house_id کوچک‌تر (اولین خانه در لیست)
        """
        # بررسی معتبر بودن requested_rooms (باید عدد صحیح مثبت باشد)
        if not isinstance(requested_rooms, int) or requested_rooms <= 0:
            print("invalid input")
            return
        
        # بررسی خالی بودن لیست
        if self.head is None:
            print("no house available")
            return
        
        # متغیرهای جستجو
        best_node = None  # بهترین گره یافت شده
        best_prev = None  # گره قبلی بهترین گره
        min_diff = float('inf')  # کمترین اختلاف
        
        # پیمایش لیست با یک بار عبور
        prev = None
        current = self.head
        
        while current is not None:
            # اگر خانه‌ای دقیقا مطابق درخواست باشد، همان را انتخاب کن و متوقف شو
            if current.room_count == requested_rooms:
                best_node = current
                best_prev = prev
                break  # چون اولین خانه‌ی مناسب پیدا شد
            
            # اگر تعداد اتاق‌های خانه فعلی بیشتر از درخواست باشد
            elif current.room_count > requested_rooms:
                diff = current.room_count - requested_rooms
                if diff < min_diff:
                    min_diff = diff
                    best_node = current
                    best_prev = prev
            
            # حرکت به گره بعدی
            prev = current
            current = current.next
        
        # اگر هیچ خانه مناسبی یافت نشد
        if best_node is None:
            print("no house available")
            return
        
        # حذف خانه انتخاب شده از لیست
        if best_prev is None:
            # خانه در ابتدای لیست قرار دارد
            self.head = best_node.next
        else:
            # خانه در وسط یا انتهای لیست قرار دارد
            best_prev.next = best_node.next
        
        # چاپ پیام موفقیت
        print(f"house {best_node.house_id} with {best_node.room_count} rooms rented")
    
    def show_houses(self):
        """
        نمایش وضعیت فعلی لیست خانه‌ها
        """
        # بررسی خالی بودن لیست
        if self.head is None:
            print("no available houses")
            return
        
        # چاپ head
        print(f"head = {self.head.house_id}")
        
        # پیمایش و چاپ تمام گره‌ها
        current = self.head
        while current is not None:
            # تعیین house_id بعدی
            next_id = current.next.house_id if current.next is not None else "None"
            
            # چاپ اطلاعات گره فعلی
            print(f"house {current.house_id} : rooms={current.room_count} next={next_id}")
            
            # حرکت به گره بعدی
            current = current.next


def main():
    """
    تابع اصلی برنامه - دریافت دستورات و اجرای عملیات‌ها
    """
    # ایجاد نمونه از سامانه رزرو خانه
    system = HouseReservationSystem()
    
    # حلقه اصلی برای دریافت و پردازش دستورات
    while True:
        try:
            # دریافت دستور از کاربر
            command_line = input().strip()
            
            # بررسی خالی بودن دستور
            if not command_line:
                print("invalid input")
                continue
            
            # تجزیه دستور به قسمت‌های مختلف
            command_parts = command_line.split()
            
            # بررسی وجود دستور
            if len(command_parts) == 0:
                print("invalid input")
                continue
            
            # دریافت نام دستور (حروف کوچک)
            command = command_parts[0].lower()
            
            # شناسایی نوع دستور و اجرای آن
            if command == "add":
                # بررسی وجود پارامترهای لازم
                if len(command_parts) != 3:
                    print("invalid input")
                    continue
                
                try:
                    # دریافت house_id و room_count
                    house_id = int(command_parts[1])
                    room_count = int(command_parts[2])
                    
                    # افزودن خانه (اعتبارسنجی در متد add_house انجام می‌شود)
                    system.add_house(house_id, room_count)
                except ValueError:
                    # اگر پارامترها عدد صحیح نباشند
                    print("invalid input")
            
            elif command == "request":
                # بررسی وجود پارامتر تعداد اتاق
                if len(command_parts) != 2:
                    print("invalid input")
                    continue
                
                try:
                    # دریافت room_count
                    room_count = int(command_parts[1])
                    
                    # رزرو خانه (اعتبارسنجی در متد request_house انجام می‌شود)
                    system.request_house(room_count)
                except ValueError:
                    # اگر پارامتر عدد صحیح نباشد
                    print("invalid input")
            
            elif command == "show":
                # بررسی اینکه دستور show پارامتر اضافی نداشته باشد
                if len(command_parts) != 1:
                    print("invalid input")
                    continue
                
                # نمایش خانه‌ها
                system.show_houses()
            
            elif command == "exit":
                # خروج از برنامه
                break
            
            else:
                # دستور نامعتبر
                print("invalid input")
        
        except EOFError:
            # پایان ورودی
            break
        except Exception as e:
            # خطای غیرمنتظره
            print("invalid input")


# نقطه شروع برنامه
if __name__ == "__main__":
    main()
# ```

# **تغییرات اصلی:**

# ✅ **رفع مشکل دستور `request`:**
# - حذف شرط اضافی که باعث چاپ `invalid input` می‌شد
# - اعتبارسنجی فقط در متد `request_house` انجام می‌شود

# ✅ **اعتبارسنجی تعداد اتاق‌ها:**
# - در متد `add_house`: بررسی اینکه `house_id` و `room_count` عدد صحیح مثبت باشند
# - در متد `request_house`: بررسی اینکه `requested_rooms` عدد صحیح مثبت باشد

# ✅ **محاسبه اختلاف:**
# - اختلاف (`diff = current.room_count - requested_rooms`) همیشه عدد صحیح مثبت یا صفر است
# - چون فقط خانه‌هایی که `room_count >= requested_rooms` در نظر گرفته می‌شوند

# **مثال اجرا:**
# ```
# add 12 3
# add 8 2
# add 15 4
# request 3
# show
# add 10 2
# request 2
# show
# exit
# ```

# **خروجی:**
# ```
# house 12 with 3 rooms added
# house 8 with 2 rooms added
# house 15 with 4 rooms added
# house 12 with 3 rooms rented
# head = 8
# house 8 : rooms=2 next=15
# house 15 : rooms=4 next=None
# house 10 with 2 rooms added
# house 8 with 2 rooms rented
# head = 10
# house 10 : rooms=2 next=15
# house 15 : rooms=4 next=None
# ```

# **تست با ورودی‌های نامعتبر:**
# ```
# add -5 3         → invalid input
# add 10 -2        → invalid input
# add 10 0         → invalid input
# request -1       → invalid input
# request 0        → invalid input
# request abc      → invalid input
