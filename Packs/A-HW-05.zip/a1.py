class Order:
    def __init__(self, order_id, customer_name, book_title, urgency_level, timestamp, order_type):
        self.order_id = order_id
        self.customer_name = customer_name
        self.book_title = book_title
        self.urgency_level = urgency_level
        self.timestamp = timestamp
        self.order_type = order_type

order_type_priority = {
    "Rushed Owl": 3,
    "Standard Raven": 2,
    "Bat Courier": 1
}

def compare_orders(o1, o2):
    if o1.urgency_level != o2.urgency_level:
        return o1.urgency_level > o2.urgency_level
    if o1.timestamp != o2.timestamp:
        return o1.timestamp < o2.timestamp
    if order_type_priority[o1.order_type] != order_type_priority[o2.order_type]:
        return order_type_priority[o1.order_type] > order_type_priority[o2.order_type]
    return False

def merge_sort(arr):
    if len(arr) <= 1:
        return arr
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    return merge(left, right)

def merge(left, right):
    result = []
    i = j = 0
    while i < len(left) and j < len(right):
        if compare_orders(left[i], right[j]):
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1
    result.extend(left[i:])
    result.extend(right[j:])
    return result

def print_order(order):
    print(f"{order.order_id} (urgency={order.urgency_level}, time={order.timestamp}, type={order.order_type})")

# Read exactly 3 lines
orders = []
for _ in range(3):
    line = input().strip()
    if line.startswith('Order(') and line.endswith(')'):
        inner = line[6:-1]
        parts = [p.strip() for p in inner.split(',', 5)]
        if len(parts) == 6:
            try:
                order_id = parts[0].strip('"')
                customer_name = parts[1].strip('"')
                book_title = parts[2].strip('"')
                urgency_level = int(parts[3])
                timestamp = int(parts[4])
                order_type = parts[5].strip('"')
                orders.append(Order(order_id, customer_name, book_title, urgency_level, timestamp, order_type))
            except:
                pass

sorted_orders = merge_sort(orders)
for order in sorted_orders:
    print_order(order)