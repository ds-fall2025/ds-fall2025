###############  پرینت های رشته ای برای نمایش روند و درک بهتر هستن و میتونن کامنت شن ################################
#######################################################################################################################

def counting_sort_with_negatives(ages):
    """
    مرتب‌سازی شمارشی پایدار برای سن‌های منفی و مثبت برره‌ای‌ها
    این تابع حتی با سن‌های منفی هم کار می‌کنه و پایداری رو حفظ می‌کنه
   
    Args:
        ages: لیست سن‌های سربازهای برره (ممکنه منفی باشه!)
       
    Returns:
        لیست مرتب‌شده سن‌ها با حفظ پایداری
    """
    if not ages:  # اگه لیست خالی باشه
        return []
   
    n = len(ages)
   
    # مرحله 1: پیدا کردن کمترین و بیشترین سن
    min_age = min(ages)
    max_age = max(ages)
   
    print(f"Min age found: {min_age}")
    print(f"Max age found: {max_age}")
   
    # مرحله 2: محاسبه آف‌ست برای تبدیل اعداد منفی به مثبت
    offset = abs(min_age) if min_age < 0 else 0
    range_size = max_age - min_age + 1
   
    print(f"Offset calculated: {offset}")
    print(f"Range size: {range_size}")
   
    # مرحله 3: ایجاد آرایه شمارش (count array)
    count = [0] * range_size
   
    # شمارش تعداد هر سن (با آف‌ست)
    for age in ages:
        adjusted_age = age + offset  # اعمال offset
        count[adjusted_age] += 1
   
    print(f"Count array: {count}")
   
    # مرحله 4: ایجاد آرایه مرتب‌شده با حفظ پایداری
    sorted_ages = []
   
    # 🔧 اصلاح اصلی: باید از کوچکترین سن شروع کنیم، نه از ترتیب ورودی!
    for adjusted_age in range(range_size):
        original_age = adjusted_age - offset  # برگردوندن به سن اصلی
        
        # برای حفظ پایداری، باید از ورودی اصلی پیمایش کنیم
        for age in ages:
            if age == original_age and count[adjusted_age] > 0:
                sorted_ages.append(age)
                count[adjusted_age] -= 1
   
    return sorted_ages

def main():
    """
    تابع اصلی برای تست مرتب‌سازی شمارشی برره‌ای
    """
    print("="*70)
    print("🪖 Welcome to Kianosh's Shakh-e Tapeh Emergency Sorting! 🪖")
    print("="*70)
    print()
   
    print("Yavar Toghrol needs urgent reinforcement for Shakh-e Tapeh!")
    print("We need to sort soldiers by age (youngest first).")
    print("Note: Some soldiers might have negative ages (this is Barrah!)")
    print()
   
    # گرفتن ورودی از کاربر
    print("Please enter soldier ages separated by spaces:")
    print("(Example: 25 -5 30 18 25 -5 22 30 19)")
   
    try:
        # خواندن سن‌ها از کاربر
        user_input = input("Enter ages: ").strip()
        if not user_input:
            print("No input provided! Using default example...")
            ages = [25, -5, 30, 18, 25, -5, 22, 30, 19]
        else:
            ages = list(map(int, user_input.split()))
       
        print(f"\nReceived ages: {ages}")
       
        print("\n" + "-"*50)
        print("Starting Counting Sort process...")
        print("-"*50)
       
        # اجرای مرتب‌سازی شمارشی
        sorted_ages = counting_sort_with_negatives(ages)
       
        print("\n" + "="*70)
        print("📊 MISSION RESULTS:")
        print("="*70)
        print(f"Original ages: {ages}")
        print(f"Sorted ages: {sorted_ages}")
        print()
        print("✅ SUCCESS: Algorithm is stable! Same-age soldiers maintain their original order.")
        print("   Shirfarhad and the team will get proper reinforcement! 🎉")
       
        
        ################## below could be commented ########################
        # تست اضافی برای نمایش پایداری
        # print("\n🔍 STABILITY TEST:")
        # if ages.count(-5) > 1 or ages.count(25) > 1:
        #     print("Notice: Multiple soldiers with same age maintain their original relative order!")
        
    except ValueError:
        print("❌ Invalid input! Please enter numbers only.")
        print("Example: 25 -5 30 18 25 -5 22 30 19")
    except Exception as e:
        print(f"❌ An error occurred: {e}")

if __name__ == "__main__":
    main()