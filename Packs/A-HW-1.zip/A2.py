def binary_search_position(potions, target, start, end):
    """
    پیدا کردن جایگاه مناسب برای درج شیشه معجون در آرایه مرتب‌شده
    با استفاده از جستجوی دودویی - طلسم اصلی ریونکلاها! 🧙‍♂️
    
    این تابع بازگرداننده ایندکس موقعیتی است که باید عنصر جدید در آن قرار بگیرد
    """
    # حالت پایه: اگر فقط یک عنصر باقی مانده باشد
    if start == end:
        # اگر شماره معجون بزرگ‌تر از عنصر موجود باشد، بعد از آن قرار بگیرد
        if target > potions[start]:
            return start + 1
        else:
            return start
    
    # اگر بازه خالی شد، موقعیت شروع را برگردان
    if start > end:
        return start
    
    # انتخاب عنصر وسط - قلب جستجوی دودویی
    mid = (start + end) // 2
    
    if target < potions[mid]:
        # شماره معجون کوچک‌تر است، جستجو در نیمه چپ
        return binary_search_position(potions, target, start, mid - 1)
    elif target > potions[mid]:
        # شماره معجون بزرگ‌تر است، جستجو در نیمه راست  
        return binary_search_position(potions, target, mid + 1, end)
    else:
        # عنصر برابر پیدا شد، بعد از آن قرار بگیرد (برای پایداری)
        return mid + 1

def binary_insertion_sorticus(potions):
    """
    طلسم مرتب‌سازی شیشه‌های معجون آقای لاکهارت 
    متأسفانه همچنان  با پیچیدگی زمانی 
    O(n²) است! 😏
    
    این تابع آرایه‌ای از شماره شیشه‌های معجون را مرتب می‌کند
    """
    # شروع از عنصر دوم (ایندکس 1) چون عنصر اول از قبل "مرتب" در نظر گرفته می‌شود
    for i in range(1, len(potions)):
        # شیشه معجون فعلی که باید در جای مناسبش قرار بگیرد
        current_potion = potions[i]
        
        # پیدا کردن جایگاه مناسب با جستجوی دودویی - O(log n)
        # فقط در بخش مرتب‌شده (از 0 تا i-1) جستجو می‌کنیم
        correct_position = binary_search_position(potions, current_potion, 0, i - 1)
        
        # حالا باید تمام شیشه‌هایی که بعد از موقعیت صحیح هستند را
        # یک خانه به راست منتقل کنیم - O(n)
        # این بخش همان مشکل مرتب‌سازی درجی معمولی است!
        for j in range(i, correct_position, -1):
            potions[j] = potions[j - 1]
        
        # قرار دادن شیشه معجون در جای مناسبش
        potions[correct_position] = current_potion
    
    return potions

if __name__ == "__main__":
    # گرفتن ورودی از کاربر
    print("🧪 Enter the potion bottle numbers (e.g., 15 3 9 1 12):")
    input_str = input()
    input_items = input_str.split()
    potion_numbers = []
    for item in input_items:
        potion_numbers.append(int(item))

    print("\n🧪 Potion bottle numbers before casting the spell:")
    print(potion_numbers)
    print()
    
    # اعمال طلسم مرتب‌سازی لاکهارت
    sorted_potions = binary_insertion_sorticus(potion_numbers.copy())
    
    print("✨ Potion bottle numbers after casting the spell:")
    print(sorted_potions)
    print()


 ############## below section could be commented ##############   
    print("=" * 60)
    print("🎭 Lockhart's Lie Revealed!")
    print("=" * 60)
    print("✗ Lockhart's claim: Time complexity is O(n log n)")
    print("✓ Truth: Time complexity is still O(n²)")
    print()
    print("🔍 Why?")
    print("  • Binary search: O(log n) — for finding position")
    print("  • Shifting elements: O(n) — for creating space")
    print("  • Each round: O(log n) + O(n) = O(n)")
    print("  • For all elements: n × O(n) = O(n²)")
    print()
    print("🎯 Conclusion:")
    print("Dear Lockhart, you only reduced the number of comparisons,")
    print("but the real cost — the physical element shifts — still remains!")
    print()
    print("💡 This spell is useful when:")
    print("  - Comparisons are expensive")
    print("  - Number of elements is relatively small")
    print("  - But total complexity is still O(n²)!")
    print()
    print("😏 As always, Lockhart isn't so trustworthy!")
