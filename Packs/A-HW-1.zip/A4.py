###پرینت های مربوط به داستان و اجرای هر تکرار میتونن کامنت شن.###
### هدف از نمایش هر تکرار درک کارکرد الگوریتم بوده###
##############################################################################

def double_ended_selection_sort(magic_stones):
    """
    طلسم مرتب‌سازی انتخابی دوطرفه - ایده درخشان سم وایز! 🥔✨
    
    "آقای فرودو، بجای اینکه یکی‌یکی کوچکترین سنگ رو پیدا کنیم، 
    چرا هم کوچکترین و هم بزرگترین رو همزمان پیدا نکنیم؟"
    
    Args:
        magic_stones: لیستی از اعداد صحیح نشان‌دهنده اندازه سنگ‌های جادویی
    
    Returns:
        همان لیست مرتب شده به صورت صعودی (کوچک به بزرگ)
    """
    
    # اگر تعداد سنگ‌ها خیلی کم باشه، نیازی به طلسم نیست
    if len(magic_stones) <= 1:
        return magic_stones
    
    # کپی از سنگ‌های اصلی برای حفظ امانت گندالف
    stones = magic_stones.copy()
    n = len(stones)
    
    # تعریف محدوده جادویی: از left تا right
    left = 0        # ابتدای بخش مرتب‌نشده - سمت غرب
    right = n - 1   # انتهای بخش مرتب‌نشده - سمت شرق
    
    print(f"Samwise: 'Mr. Frodo, we've got {n} magic stones!'")
    print(f"Initial stones: {stones}")
    print("Sam: 'I'm using the double-ended sort spell Gandalf taught me!'")
    print("=" * 60)
    
    # تا زمانی که محدوده جادویی وجود داره
    while left < right:
        
        # مرحله 1: سم شروع می‌کنه به جستجوی همزمان
        min_stone = stones[left]    # فرض اولیه برای کوچکترین
        max_stone = stones[left]    # فرض اولیه برای بزرگترین
        min_position = left         # موقعیت کوچکترین سنگ
        max_position = left         # موقعیت بزرگترین سنگ
        
        # سم با دقت هر سنگ رو بررسی می‌کنه
        for i in range(left, right + 1):
            
            # اگر سنگی کوچکتر از کوچکترین فعلی پیدا شد
            if stones[i] < min_stone:
                min_stone = stones[i]
                min_position = i
            
            # اگر سنگی بزرگتر از بزرگترین فعلی پیدا شد
            if stones[i] > max_stone:
                max_stone = stones[i]
                max_position = i
        
        step = (n - (right - left)) // 2 + 1
        print(f"Step {step}:")
        print(f"   Range: {left} to {right}")
        print(f"   Min stone: {min_stone} (position {min_position})")
        print(f"   Max stone: {max_stone} (position {max_position})")
        
        # مرحله 2: قرار دادن کوچکترین سنگ در غرب (ابتدا)
        if min_position != left:
            stones[left], stones[min_position] = stones[min_position], stones[left]
            print(f"   Swapped min {min_stone} to the west!")
            
            # نکته مهم: اگر بزرگترین سنگ در موقعیت left بود، 
            # حالا به جای کوچکترین منتقل شده
            if max_position == left:
                max_position = min_position
        
        # مرحله 3: قرار دادن بزرگترین سنگ در شرق (انتها)
        if max_position != right:
            stones[right], stones[max_position] = stones[max_position], stones[right]
            print(f"   Swapped max {max_stone} to the east!")
        
        print(f"   Stones now: {stones}")
        
        # مرحله 4: کوچک کردن محدوده جادویی از هر دو طرف
        left += 1    # یک قدم به سمت شرق
        right -= 1   # یک قدم به سمت غرب
        
        print(f"   New range: {left} to {right}")
        print("   Frodo: 'Great job, Sam!'")
        print("-" * 40)
    
    print("Sam: 'All done, Mr. Frodo!'")
    print("✨ The stones are glowing and showing us the way!")
    print(f"Sorted stones: {stones}")
    return stones


#################################### below section could be commented as well ####################
# بررسی صحت طلسم جادویی
def verify_magic_spell(original_stones, sorted_stones):
    """بررسی نهایی توسط گندالف"""
    print("\nGandalf appears to inspect the spell...")

    if sorted(original_stones) == sorted_stones:
        print("✅ Gandalf: 'Excellent, Sam! Your spell worked perfectly!'")
        print("🧙‍♂️ Gandalf: 'You proved that even the smallest hobbits...'")
        print("             '...can make the biggest difference!'")
        return True
    else:
        print("❌ Gandalf: 'Alas, something went wrong. Some stones are missing!'")
        print("🧙‍♂️ Gandalf: 'You must try again, brave hobbits.'")
        return False
#####################################################################################################

# --- اجرای ماجراجویی جدید با ورودی کاربر ---
if __name__ == "__main__":
    print("🧪 Enter the size of stones (e.g. 15 3 9 1 12):")
    try:
        # گرفتن ورودی کاربر و تبدیل به لیست عددی
        raw_input = input()
        input_list = list(map(int, raw_input.strip().split()))

        print("\n🧪 size of stones before the spell:")
        print(input_list)

        # اعمال طلسم مرتب‌سازی
        sorted_list = double_ended_selection_sort(input_list)

        print("\n✨ size after the spell:")
        print(sorted_list)

        # بررسی صحت طلسم
        verify_magic_spell(input_list, sorted_list)

    except Exception as e:
        print("⚠️ Oops! Something went wrong with your input.")
        print(f"Error: {e}")
