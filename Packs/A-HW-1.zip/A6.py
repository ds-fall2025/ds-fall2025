#################### پرینت های متعدد برای نمایش کارکرد الگورتم هستن و میتونن کامنت شن #####################################


def insertion_sort(arr):
    """
    مرتب‌سازی درجی برای مرتب کردن عناصر درون هر سطل
    این الگوریتم برای آرایه‌های کوچک بسیار کارآمد است

    Args:
        arr: لیست اعداد اعشاری برای مرتب‌سازی

    Returns:
        همان لیست به صورت مرتب‌شده درجا
    """
    for i in range(1, len(arr)):
        key = arr[i]  # عنصر فعلی که باید جای مناسبش پیدا شود
        j = i - 1     # شروع از عنصر قبلی

        # عناصر بزرگتر از key را یک موقعیت به راست انتقال می‌دهیم
        while j >= 0 and arr[j] > key:
            arr[j + 1] = arr[j]
            j -= 1

        # key را در موقعیت درست قرار می‌دهیم
        arr[j + 1] = key

    return arr


def bucket_sort(grades, num_buckets=3):
    """
    مرتب‌سازی سطلی برای نمرات اعشاری در بازه [1, 4]
    استراتژی ندا برای برد در مسابقه کدنویسی!

    Args:
        grades: لیست نمرات اعشاری در بازه [1, 4]
        num_buckets: تعداد سطل‌ها (پیش‌فرض 3 سطل)

    Returns:
        لیست مرتب‌شده نمرات
    """
    if not grades:  # اگر لیست خالی باشد
        return []

    n = len(grades)

    # مرحله 1: ایجاد سطل‌های خالی
    buckets = [[] for _ in range(num_buckets)]

    print(f"Step 1: Created {num_buckets} empty buckets")
    print(f"Bucket ranges:")
    print(f"  Bucket 0: [1.0, 2.0)")
    print(f"  Bucket 1: [2.0, 3.0)")
    print(f"  Bucket 2: [3.0, 4.0]")
    print()

    # مرحله 2: توزیع نمرات به سطل‌های مناسب
    print("Step 2: Distributing grades into buckets...")
    for grade in grades:
        # محاسبه شماره سطل براساس نمره
        # برای بازه [1, 4] و 3 سطل:
        # سطل 0: [1.0, 2.0), سطل 1: [2.0, 3.0), سطل 2: [3.0, 4.0]
        if grade < 2.0:
            bucket_index = 0
        elif grade < 3.0:
            bucket_index = 1
        else:
            bucket_index = 2

        buckets[bucket_index].append(grade)
        print(f"  Grade {grade} -> Bucket {bucket_index}")

    print()
    print("Buckets after distribution:")
    for i, bucket in enumerate(buckets):
        print(f"  Bucket {i}: {bucket}")
    print()

    # مرحله 3: مرتب‌سازی درون هر سطل با Insertion Sort
    print("Step 3: Sorting within each bucket using Insertion Sort...")
    for i in range(num_buckets):
        if buckets[i]:  # اگر سطل خالی نباشد
            print(f"  Sorting Bucket {i}: {buckets[i]}")
            insertion_sort(buckets[i])
            print(f"  After sorting: {buckets[i]}")
        else:
            print(f"  Bucket {i} is empty, skipping...")
    print()

    # مرحله 4: ترکیب سطل‌های مرتب‌شده
    print("Step 4: Concatenating sorted buckets...")
    sorted_grades = []
    for i, bucket in enumerate(buckets):
        if bucket:
            print(f"  Adding Bucket {i}: {bucket}")
            sorted_grades.extend(bucket)

    print(f"Final result: {sorted_grades}")
    return sorted_grades


def main():
    """
    تابع اصلی برای تست مرتب‌سازی سطلی در مسابقه کدنویسی
    """
    print("="*70)
    print("🏆 Computer Engineering Department Coding Competition - Round 1 🏆")
    print("="*70)
    print()
    print("Team Neda-Arya's Bucket Sort Strategy for Grade Analysis!")
    print("We need to sort decimal grades in range [1, 4] efficiently.")
    print()

    # گرفتن ورودی از کاربر
    print("Please enter student grades (1.0 to 4.0) separated by spaces:")
    print("(Example: 3.2 1.5 2.8 3.9 1.1 2.4 2.2 3.3)")

    try:
        # خواندن نمرات از کاربر
        user_input = input("Enter grades: ").strip()
        if not user_input:
            print("No input provided! Using default example...")
            grades = [3.2, 1.5, 2.8, 3.9, 1.1, 2.4, 2.2, 3.3]
        else:
            grades = list(map(float, user_input.split()))

        # بررسی معتبر بودن نمرات
        invalid_grades = [g for g in grades if g < 1.0 or g > 4.0]
        if invalid_grades:
            print(f"Warning: Some grades are out of range [1.0, 4.0]: {invalid_grades}")
            print("Continuing with all provided grades...")

        print(f"\nReceived grades: {grades}")
        print(f"Number of grades: {len(grades)}")
        print("\n" + "-"*50)
        print("Starting Bucket Sort process...")
        print("-"*50)

        # اجرای مرتب‌سازی سطلی
        sorted_grades = bucket_sort(grades)

        print("\n" + "="*70)
        print("📊 COMPETITION RESULTS:")
        print("="*70)
        print(f"Original grades: {grades}")
        print(f"Sorted grades:   {sorted_grades}")

        # بررسی درستی نتیجه
        expected_result = sorted(grades)
        if sorted_grades == expected_result:
            print("\n✅ SUCCESS: Team Neda-Arya wins Round 1!")
            print("   Bucket Sort strategy worked perfectly! 🎉")
            print("   Ready for Round 2 of the competition!")
        else:
            print("\n❌ ERROR: Something went wrong with the sorting!")
            print(f"   Expected: {expected_result}")
            print(f"   Got:      {sorted_grades}")

        # آمار عملکرد
        # print("\n📈 Performance Analysis:")
        # print(f"   - Input size: {len(grades)} grades")
        # print(f"   - Algorithm: Bucket Sort + Insertion Sort")
        # print(f"   - Time Complexity: O(n + k) average case")
        # print(f"   - Space Complexity: O(n + k)")
        # print(f"   - Optimal for: Uniformly distributed data in limited range")

    except ValueError:
        print("❌ Invalid input! Please enter decimal numbers only.")
        print("Example: 3.2 1.5 2.8 3.9 1.1 2.4 2.2 3.3")
    except Exception as e:
        print(f"❌ An error occurred: {e}")


# نکته پاسخ سوال تفکر انتقادی:
"""
🤔 پاسخ سوال: برای بازه [0,20] با توزیع نامنظم:
1. باید تعداد سطل‌ها را افزایش داد (مثلاً 10-20 سطل)
2. اگر اکثر داده‌ها در [15-20] باشند، سطل‌های [0-15] خالی خواهند بود
3. ممکن است Radix Sort یا Quick Sort مناسب‌تر باشند
4. می‌توان سطل‌ها را adaptive تعریف کرد (سطل‌های کوچک‌تر برای نواحی پرتراکم)

🏆 تیم ندا-آریا: "Strategy beats brute force every time!" 💪
"""

if __name__ == "__main__":
    main()
