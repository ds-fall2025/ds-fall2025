#################### پرینت های متعدد برای نمایش کارکرد الگورتم هستن و میتونن کامنت شن #####################################
####################  دو مد برای این کد آماده شده که قابل انتخاب هستن #################################

def partial_insertion_sort(case_years):
    """
    مرتب‌سازی درجی جزئی برای پرونده‌های شرلوک هلمز
    این تابع پرونده‌ها را یکی یکی پردازش می‌کند و فوراً در جای مناسب قرار می‌دهد
    
    Args:
        case_years: لیست سال‌های پرونده‌های نامرتب
        
    Returns:
        لیست مرتب‌شده سال‌های پرونده‌ها
    """
    if not case_years:  # اگر لیست خالی باشد
        return []
    
    # لیست مرتب‌شده که با اولین پرونده شروع می‌شود
    sorted_cases = []
    
    print("=" * 60)
    print("🕵️‍♂️ Sherlock Holmes Case Analysis System - Emergency Mode")
    print("=" * 60)
    print()
    
    # پردازش هر پرونده یکی یکی
    for i, current_case_year in enumerate(case_years):
        print(f"📁 Processing case from year: {current_case_year}")
        
        # اگر این اولین پرونده است، فقط اضافه‌اش کن
        if len(sorted_cases) == 0:
            sorted_cases.append(current_case_year)
            print(f"   ✅ Ready cases for analysis: {sorted_cases} ({len(sorted_cases)} case ready)")
            print()
            continue
        
        # پیدا کردن جای مناسب برای پرونده جدید در لیست مرتب‌شده
        insertion_index = 0
        
        # جستجو از چپ به راست برای پیدا کردن جای مناسب
        for j in range(len(sorted_cases)):
            if current_case_year <= sorted_cases[j]:
                insertion_index = j
                break
            else:
                insertion_index = j + 1  # باید در انتها قرار بگیرد
        
        # اضافه کردن پرونده جدید در جای مناسب
        sorted_cases.insert(insertion_index, current_case_year)
        
        # گزارش وضعیت فعلی به شرلوک
        case_word = "case" if len(sorted_cases) == 1 else "cases"
        print(f"   ✅ Ready cases for analysis: {sorted_cases} ({len(sorted_cases)} {case_word} ready)")
        print()
    
    print("🎯 All cases sorted! Sherlock can now analyze the complete pattern.")
    print(f"📋 Final timeline: {sorted_cases}")
    
    return sorted_cases


def partial_insertion_sort_detailed(case_years):
    """
    نسخه تفصیلی مرتب‌سازی درجی جزئی با نمایش مراحل درونی
    این تابع مراحل جستجو و جایگذاری را نیز نمایش می‌دهد
    
    Args:
        case_years: لیست سال‌های پرونده‌های نامرتب
        
    Returns:
        لیست مرتب‌شده سال‌های پرونده‌ها
    """
    if not case_years:
        return []
    
    sorted_cases = []
    
    print("🔍 Detailed Analysis Mode - Step by Step Process")
    print("-" * 50)
    
    for i, current_case_year in enumerate(case_years):
        print(f"\nProcessing case #{i+1}: Year {current_case_year}")
        
        if len(sorted_cases) == 0:
            sorted_cases.append(current_case_year)
            print(f"  → First case added: {sorted_cases}")
            continue
        
        print(f"  Current sorted cases: {sorted_cases}")
        print(f"  Finding position for year {current_case_year}...")
        
        # پیدا کردن جای مناسب با نمایش مقایسه‌ها
        insertion_index = 0
        for j in range(len(sorted_cases)):
            print(f"    Comparing {current_case_year} with {sorted_cases[j]}", end="")
            if current_case_year <= sorted_cases[j]:
                insertion_index = j
                print(f" → Insert at position {insertion_index}")
                break
            else:
                print(f" → Continue searching...")
                insertion_index = j + 1
        
        if insertion_index == len(sorted_cases):
            print(f"    → Insert at end (position {insertion_index})")
        
        # اضافه کردن در جای مناسب
        sorted_cases.insert(insertion_index, current_case_year)
        print(f"  ✅ Updated: {sorted_cases}")
    
    return sorted_cases


def main():
    """
    تابع اصلی برای تست مرتب‌سازی درجی جزئی پرونده‌های شرلوک
    """
    print("🕵️‍♂️ Welcome to Scotland Yard Case Management System! 🕵️‍♂️")
    print()
    print("Inspector Lestrade needs help sorting case files for Sherlock Holmes.")
    print("Cases must be analyzed chronologically to discover the criminal pattern.")
    print()
    
    # گرفتن ورودی از کاربر
    print("Please enter case years separated by spaces:")
    print("(Example: 1995 1987 2001 1991 1999 1983 2005)")
    
    try:
        # خواندن سال‌های پرونده از کاربر
        user_input = input("Enter case years: ").strip()
        if not user_input:
            print("No input provided! Using default example cases...")
            case_years = [1995, 1987, 2001, 1991, 1999, 1983, 2005]
        else:
            case_years = list(map(int, user_input.split()))
        
        print(f"\nReceived case years: {case_years}")
        print(f"Number of cases: {len(case_years)}")
        print()
        
        # انتخاب نوع نمایش
        print("Choose analysis mode:")
        print("1. Standard mode (faster)")
        print("2. Detailed mode (step-by-step)")
        
        mode_choice = input("Enter your choice (1 or 2): ").strip()
        print()
        
        # اجرای مرتب‌سازی بر اساس انتخاب کاربر
        if mode_choice == "2":
            print("Starting detailed partial insertion sort...")
            print("=" * 60)
            sorted_cases = partial_insertion_sort_detailed(case_years)
        else:
            print("Starting standard partial insertion sort...")
            sorted_cases = partial_insertion_sort(case_years)
        
        print("\n" + "=" * 60)
        print("📊 FINAL RESULTS:")
        print("=" * 60)
        print(f"Original case years: {case_years}")
        print(f"Sorted case years:   {sorted_cases}")
        
        # بررسی درستی نتیجه
        expected_result = sorted(case_years)
        if sorted_cases == expected_result:
            print("\n✅ SUCCESS: All cases sorted correctly!")
            print("   Sherlock Holmes can now analyze the criminal timeline! 🎉")
            print("   The pattern will reveal the location of the next crime!")
        else:
            print("\n❌ ERROR: Sorting failed!")
            print(f"   Expected: {expected_result}")
            print(f"   Got:      {sorted_cases}")
        
        # آمار عملکرد
        # print("\n📈 Algorithm Performance:")
        # print(f"   - Cases processed: {len(case_years)}")
        # print(f"   - Algorithm: Partial Insertion Sort")
        # print(f"   - Time Complexity: O(n²) worst case, O(n) best case")
        # print(f"   - Space Complexity: O(1) - in-place sorting")
        # print(f"   - Advantage: Real-time processing, power-failure resistant")
        
        # شبیه‌سازی قطع برق (اختیاری)
        # print("\n⚡ Power Failure Simulation:")
        # print("   If power had failed after processing 3 cases,")
        # if len(case_years) >= 3:
        #     partial_result = partial_insertion_sort(case_years[:3])
        #     print(f"   These cases would be preserved: {partial_result}")
        #     print("   Work can resume from this point when power returns!")
        # else:
        #     print("   Not enough cases for simulation.")
        
    except ValueError:
        print("❌ Invalid input! Please enter years as numbers only.")
        print("Example: 1995 1987 2001 1991 1999")
    except Exception as e:
        print(f"❌ An error occurred: {e}")


if __name__ == "__main__":
    main()
