###پرینت های مربوط به داستان و اجرای هر تکرار میتونن کامنت شن.###
### هدف از نمایش هر تکرار درک کارکرد الگوریتم بوده###
##############################################################################

def odd_even_sort(arr):
    """
    مرتب‌سازی زوج-فرد (Odd-Even Sort) برای نجات پروژه مهننس!
    این تابع آرایه‌ای از شماره کاشی‌های بهم‌ریخته را مرتب می‌کند
    تا جدول مندلیف کامل شود و آقای مندلیان راضی بشه!
    
    Args:
        arr: لیست شماره کاشی‌های عناصر بهم‌ریخته
        
    Returns:
        همان آرایه به صورت مرتب‌شده (درجا - in-place)
    """
    n = len(arr)
    
    # پرچم برای بررسی اینکه آیا هنوز جابه‌جایی انجام می‌شود یا نه
    # اگر در یک دور کامل هیچ جابه‌جایی نشود، یعنی کار تمام شده!
    sorted_flag = False
    
    print("Starting Mendeleev Table Tile Sorting...")
    print("-" * 50)
    
    round_number = 1
    
    # تا زمانی که هنوز جابه‌جایی انجام می‌شود، ادامه بده
    while not sorted_flag:
        sorted_flag = True  # فرض می‌کنیم این دور، دیگر جابه‌جایی نخواهیم داشت
        
        print(f"Round {round_number}:")
        
        # مرحله اول: کار دستیار - بررسی ایندکس‌های فرد (1, 3, 5, ...)
        print("  Assistant's turn (odd indices):")
        for i in range(1, n - 1, 2):  # از 1 شروع، با گام 2
            if arr[i] > arr[i + 1]:
                # اگر کاشی سمت چپ بزرگتر از سمت راست باشد، جابه‌جا کن
                arr[i], arr[i + 1] = arr[i + 1], arr[i]
                sorted_flag = False  # چون جابه‌جا کردیم، هنوز مرتب نشده
                print(f"    Swapped positions {i} and {i+1}: {arr[i+1]} <-> {arr[i]}")
        
        if sorted_flag:
            print("    No swaps needed by assistant!")
        
        # مرحله دوم: کار مهننس - بررسی ایندکس‌های زوج (0, 2, 4, ...)
        print("  Mohannnes's turn (even indices):")
        for i in range(0, n - 1, 2):  # از 0 شروع، با گام 2
            if arr[i] > arr[i + 1]:
                # اگر کاشی سمت چپ بزرگتر از سمت راست باشد، جابه‌جا کن
                arr[i], arr[i + 1] = arr[i + 1], arr[i]
                sorted_flag = False  # چون جابه‌جا کردیم، هنوز مرتب نشده
                print(f"    Swapped positions {i} and {i+1}: {arr[i+1]} <-> {arr[i]}")
        
        if not any(arr[i] > arr[i + 1] for i in range(0, n - 1, 2)):
            print("    No swaps needed by Mohannnes!")
            
        print(f"  After round {round_number}: {arr}")
        print("-" * 30)
        round_number += 1
    
    print("SUCCESS! Mendeleev Table completed successfully!")
    print(f"Final sorted tiles: {arr}")
    return arr


def main():
    """
    تابع اصلی برای تست الگوریتم مرتب‌سازی زوج-فرد
    """
    print("="*60)
    print("🧪 Welcome to Mohannnes's Mosaic Crisis Solution! 🧪")
    print("="*60)
    print()
    
    # گرفتن ورودی از کاربر
    print("Please enter the tile numbers separated by spaces:")
    print("(Example: 8 3 1 7 4 6 2 5)")
    
    try:
        # خواندن ورودی و تبدیل به لیست اعداد صحیح
        user_input = input("Enter tiles: ").strip()
        element_tiles = list(map(int, user_input.split()))
        
        if len(element_tiles) == 0:
            print("No tiles entered! Using default example...")
            element_tiles = [8, 3, 1, 7, 4, 6, 2, 5]
            
        print(f"\nReceived tiles: {element_tiles}")
        print("\nStarting the sorting process...\n")
        
        # اجرای الگوریتم مرتب‌سازی
        sorted_tiles = odd_even_sort(element_tiles.copy())  # کپی می‌کنیم تا اصل دست‌نخورده بماند
        
        print("\n" + "="*60)
        print("📊 RESULTS SUMMARY:")
        print("="*60)
        print(f"Original tiles: {element_tiles}")
        print(f"Sorted tiles:   {sorted_tiles}")
        

        ########### could be commented ##############
        # بررسی درستی نتیجه
        if sorted_tiles == sorted(element_tiles):
            print("\n✅ SUCCESS: Mr. Mendeleev is satisfied!")
            print("   Mohannnes saved his reputation and got the next project too! 🎉")
        else:
            print("\n❌ ERROR: Something went wrong!")
            print("   Mohannnes might be in trouble... 😱")
            
    except ValueError:
        print("❌ Invalid input! Please enter numbers only.")
        print("Example: 8 3 1 7 4 6 2 5")
    except Exception as e:
        print(f"❌ An error occurred: {e}")


# نکته پاسخ سوال :
"""
🤔 پاسخ سوال: اگر مهننس سه کارگر داشت، می‌توانست کار را به سه فاز تقسیم کند:
- فاز 1: موقعیت‌های 0, 3, 6, 9, ... (باقی‌مانده تقسیم بر 3 برابر 0)
- فاز 2: موقعیت‌های 1, 4, 7, 10, ... (باقی‌مانده تقسیم بر 3 برابر 1)  
- فاز 3: موقعیت‌های 2, 5, 8, 11, ... (باقی‌مانده تقسیم بر 3 برابر 2)

برای رنگ‌ها می‌توان از مقادیر RGB یا HSV استفاده کرد، یا حتی ترتیب رنگین‌کمان! 🌈
"""

if __name__ == "__main__":
    main()