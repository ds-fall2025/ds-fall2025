#################### Many parts of the code can be commented, since they’re only meant to show how the algorithm works step by step.#####################################


def counting_sort_for_bucket(bucket, bucket_number):
    """
    مرتب‌سازی شمارشی برای یک سطل خاص از کتاب‌های رده‌بندی دیویی  
    این تابع کتاب‌های درون یک سطل را به ترتیب کد دیویی مرتب می‌کند

    Args:
        bucket: لیست کدهای دیویی در یک سطل خاص
        bucket_number: شماره سطل (0 تا 9)

    Returns:
        لیست مرتب‌شده کدهای داخل سطل
    """
    if not bucket:  # اگر سطل خالی باشد
        return []

    # محدوده هر سطل 100 کد است (مثلا سطل 7: از 700 تا 799)
    min_code = bucket_number * 100
    max_code = min_code + 99
    range_size = 100  # هر سطل 100 کد مختلف دارد

    # ایجاد آرایه شمارش برای این محدوده
    count = [0] * range_size

    # شمارش تعداد هر کد دیویی
    for code in bucket:
        index = code - min_code  # تبدیل کد به اندیس مناسب (0-99)
        count[index] += 1

    # بازسازی لیست مرتب‌شده
    sorted_bucket = []
    for i in range(range_size):
        actual_code = i + min_code  # تبدیل اندیس به کد واقعی
        # اضافه کردن هر کد به تعداد موجود در آرایه شمارش
        for _ in range(count[i]):
            sorted_bucket.append(actual_code)

    return sorted_bucket


def bucket_sort_dewey_system(dewey_codes):
    """
    مرتب‌سازی سطلی برای کدهای رده‌بندی دیویی در کتابخانه نیمه شب
    این تابع کتاب‌های نورا را بر اساس سیستم دیویی مرتب می‌کند

    Args:
        dewey_codes: لیست کدهای دیویی سه‌رقمی (000-999)

    Returns:
        لیست مرتب‌شده تمام کدهای دیویی
    """
    if not dewey_codes:  # اگر لیست خالی باشد
        return []

    # ایجاد 10 سطل برای دسته‌های اصلی رده‌بندی دیویی
    buckets = [[] for _ in range(10)]

    # نام‌های دسته‌های اصلی رده‌بندی دیویی
    dewey_categories = [
        "Computer Science & Information",    # 000-099
        "Philosophy & Psychology",           # 100-199  
        "Religion",                          # 200-299
        "Social Sciences",                   # 300-399
        "Language",                          # 400-499
        "Natural Sciences & Mathematics",    # 500-599
        "Technology & Applied Sciences",     # 600-699
        "Arts & Recreation",                 # 700-799
        "Literature",                        # 800-899
        "History & Geography"                # 900-999
    ]

    print("=" * 60)
    print("🌙 Midnight Library Sorting System 🌙")
    print("=" * 60)
    print()
    print("Organizing Nora's parallel lives...")
    print(f"Total books to organize: {len(dewey_codes)}")
    print()

    # مرحله 1: توزیع کتاب‌ها در سطل‌های مناسب
    print("📚 Step 1: Distributing books into category buckets...")
    for code in dewey_codes:
        # تعیین شماره سطل بر اساس رقم اول کد دیویی
        bucket_number = code // 100  # مثلا 796 -> 7, 150 -> 1
        buckets[bucket_number].append(code)
        print(f"   Book {code} -> Bucket {bucket_number} ({dewey_categories[bucket_number]})")

    print()
    print("📊 Buckets after distribution:")
    for i in range(10):
        if buckets[i]:  # فقط سطل‌های غیرخالی را نمایش بده
            print(f"   Bucket {i} ({i*100:03d}-{i*100+99:03d}): {buckets[i]}")
    print()

    # مرحله 2: مرتب‌سازی درون هر سطل با Counting Sort
    print("🔢 Step 2: Sorting within each bucket using Counting Sort...")
    for i in range(10):
        if buckets[i]:  # فقط سطل‌های غیرخالی را پردازش کن
            print(f"   Sorting Bucket {i}: {buckets[i]}")
            buckets[i] = counting_sort_for_bucket(buckets[i], i)
            print(f"   After sorting: {buckets[i]}")
        else:
            print(f"   Bucket {i} is empty, skipping...")
    print()

    # مرحله 3: ترکیب سطل‌های مرتب‌شده
    print("🔗 Step 3: Combining sorted buckets...")
    final_sorted_codes = []

    for i in range(10):
        if buckets[i]:  # فقط سطل‌های غیرخالی را اضافه کن
            print(f"Bucket {i} ({i*100:03d}-{i*100+99:03d}): {buckets[i]}")
            final_sorted_codes.extend(buckets[i])

    print()
    print(f"Final sorted lives: {final_sorted_codes}")
    print()
    print("✨ Nora can now easily find any life she wants to explore! ✨")

    return final_sorted_codes


def interpret_dewey_codes(codes):
    """
    تفسیر کدهای دیویی و نمایش معنی آنها
    این تابع به نورا کمک می‌کند تا بفهمد هر کتاب چه زندگی‌ای را روایت میکند

    Args:
        codes: لیست کدهای دیویی

    Returns:
        دیکشنری از تفسیر کدها
    """
    # نمونه‌ای از تفسیرهای رایج کدهای دیویی
    dewey_interpretations = {
        4: "Computer programming & software",
        150: "Psychology & mental processes", 
        220: "Bible & sacred texts",
        510: "Mathematics & mathematical sciences",
        641: "Cooking & food preparation",
        780: "Music & musical arts",
        796: "Sports & athletic activities",
        951: "Chinese history"
    }

    interpretations = {}
    for code in codes:
        if code in dewey_interpretations:
            interpretations[code] = dewey_interpretations[code]
        else:
            # تفسیر عمومی بر اساس دسته اصلی
            category = code // 100
            if category == 0:
                interpretations[code] = "Computer & Information Sciences"
            elif category == 1:
                interpretations[code] = "Philosophy & Psychology"
            elif category == 2:
                interpretations[code] = "Religion & Theology"
            elif category == 3:
                interpretations[code] = "Social Sciences"
            elif category == 4:
                interpretations[code] = "Language & Linguistics"
            elif category == 5:
                interpretations[code] = "Natural Sciences & Mathematics"
            elif category == 6:
                interpretations[code] = "Technology & Applied Sciences"
            elif category == 7:
                interpretations[code] = "Arts & Recreation"
            elif category == 8:
                interpretations[code] = "Literature"
            elif category == 9:
                interpretations[code] = "History & Geography"

    return interpretations


def main():
    """
    تابع اصلی برای تست مرتب‌سازی سطلی کتابخانه نیمه شب
    """
    print("🌙" * 30)
    print("   Welcome to The Midnight Library   ")
    print("🌙" * 30)
    print()
    print("Nora has found herself in a magical library between life and death.")
    print("Every book represents a different life she could have lived!")
    print("Help her organize the books using the Dewey Decimal System.")
    print()

    # گرفتن ورودی از کاربر
    print("Please enter Dewey Decimal codes (000-999) separated by spaces:")
    print("(Example: 796 641 150 510 780 004 951 641 796 220)")

    try:
        # خواندن کدهای دیویی از کاربر
        user_input = input("Enter Dewey codes: ").strip()
        if not user_input:
            print("No input provided! Using Nora's default parallel lives...")
            dewey_codes = [796, 641, 150, 510, 780, 4, 951, 641, 796, 220]
        else:
            dewey_codes = list(map(int, user_input.split()))

        # بررسی معتبر بودن کدها
        invalid_codes = [code for code in dewey_codes if code < 0 or code > 999]
        if invalid_codes:
            print(f"Warning: Some codes are out of Dewey range (000-999): {invalid_codes}")
            print("Continuing with valid codes only...")
            dewey_codes = [code for code in dewey_codes if 0 <= code <= 999]

        print(f"\nReceived Dewey codes: {dewey_codes}")
        print(f"Number of books (parallel lives): {len(dewey_codes)}")

        # نمایش تفسیر کدها
        print("\n📖 What these codes represent:")
        interpretations = interpret_dewey_codes(set(dewey_codes))
        for code in sorted(set(dewey_codes)):
            count = dewey_codes.count(code)
            lives_text = "life" if count == 1 else "lives"
            print(f"   {code:03d}: {interpretations.get(code, 'Unknown category')} ({count} {lives_text})")

        print("\n" + "-"*60)
        print("Starting Bucket Sort with Counting Sort...")
        print("-"*60)

        # اجرای مرتب‌سازی سطلی
        sorted_codes = bucket_sort_dewey_system(dewey_codes)

        print("\n" + "="*60)
        print("📊 FINAL RESULTS:")
        print("="*60)
        print(f"Original codes: {dewey_codes}")
        print("Sorted codes:   [" + ", ".join(f"{code:03d}" for code in sorted_codes) + "]")

        # بررسی درستی نتیجه
        expected_result = sorted(dewey_codes)
        if sorted_codes == expected_result:
            print("\n✅ SUCCESS: All parallel lives organized perfectly!")
            print("   Nora can now explore her lives in perfect order! 🎉")
            print("   From knowledge to arts, from science to spirituality!")
        else:
            print("\n❌ ERROR: Organization failed!")
            print(f"   Expected: {expected_result}")
            print(f"   Got:      {sorted_codes}")

        # آمار عملکرد
        # print("\n📈 Algorithm Performance:")
        # print(f"   - Books organized: {len(dewey_codes)}")
        # print(f"   - Algorithm: Bucket Sort + Counting Sort")
        # print(f"   - Time Complexity: O(n + k) where k=1000")
        # print(f"   - Space Complexity: O(n + k)")
        # print("\n✨ Nora's journey through the Midnight Library continues...")
        # print("   Every organized book is a doorway to a different destiny!")

    except ValueError:
        print("❌ Invalid input! Please enter numbers only.")
        print("Example: 796 641 150 510 780 004 951")
    except Exception as e:
        print(f"❌ An error occurred: {e}")


if __name__ == "__main__":
    main()
