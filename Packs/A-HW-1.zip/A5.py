#################### پرینت های متعدد برای نمایش کارکرد الگورتم هستن و میتونن کامنت شن #####################################


def counting_sort_by_digit(arr, digit_position):
    """
    مرتب‌سازی شمارشی بر اساس رقم مشخص شده
    
    Args:
        arr: لیست اعداد سه‌رقمی
        digit_position: موقعیت رقم (0=یکان، 1=دهگان، 2=صدگان)
    
    Returns:
        لیست مرتب‌شده بر اساس رقم مشخص
    """
    n = len(arr)
    output = [0] * n  # آرایه خروجی (output array)
    count = [0] * 10  # آرایه شمارش برای ارقام 0 تا 9 (count array for digits 0-9)
    
    # شمارش تعداد هر رقم (count frequency of each digit)
    for num in arr:
        digit = (num // (10 ** digit_position)) % 10  # استخراج رقم مورد نظر (extract specific digit)
        count[digit] += 1
    
    # تبدیل count به موقعیت‌های واقعی (convert count to actual positions)
    for i in range(1, 10):
        count[i] += count[i - 1]
    
    # ساختن آرایه خروجی از انتها به ابتدا برای حفظ پایداری (build output array from end to maintain stability)
    for i in range(n - 1, -1, -1):
        digit = (arr[i] // (10 ** digit_position)) % 10
        output[count[digit] - 1] = arr[i]
        count[digit] -= 1
    
    return output

def radix_sort_three_digit(student_codes):
    """
    مرتب‌سازی مبنایی برای کدهای سه‌رقمی دانشجویی
    
    Args:
        student_codes: لیست کدهای سه‌رقمی دانشجویی (000-999)
    
    Returns:
        لیست مرتب‌شده کدهای دانشجویی
    """
    if not student_codes:
        return []
    
    # کپی از لیست اصلی برای عدم تغییر ورودی (copy of original list to avoid modifying input)
    arr = student_codes.copy()
    
    print("Starting Radix Sort...")
    print(f"Input codes: {['{:03d}'.format(c) for c in arr]}")
    print()
    
    # مرحله 1: مرتب‌سازی بر اساس رقم یکان (Step 1: Sort by units digit)
    print("Step 1: Sort by units digit")
    arr = counting_sort_by_digit(arr, 0)
    print(f"Result of step 1: {['{:03d}'.format(c) for c in arr]}")
    print()
    
    # مرحله 2: مرتب‌سازی بر اساس رقم دهگان (Step 2: Sort by tens digit)
    print("Step 2: Sort by tens digit")
    arr = counting_sort_by_digit(arr, 1)
    print(f"Result of step 2: {['{:03d}'.format(c) for c in arr]}")
    print()
    
    # مرحله 3: مرتب‌سازی بر اساس رقم صدگان (Step 3: Sort by hundreds digit)
    print("Step 3: Sort by hundreds digit")
    arr = counting_sort_by_digit(arr, 2)
    print(f"Final result: {['{:03d}'.format(c) for c in arr]}")
    print()
    
    return arr

def main():
    """
    تابع اصلی برای دریافت ورودی و نمایش خروجی
    """
    print("=" * 70)
    print("🎓 Meowvard University Student Sorting System - Alan Fishing 🎓")
    print("=" * 70)
    print()
    
    print("To solve the course selection crisis, we sort student codes!")
    print("Please enter three-digit student codes separated by spaces:")
    print("Example: 123 045 789 012 456")
    print()
    
    try:
        # دریافت ورودی از کاربر (get input from user)
        user_input = input("Enter student codes: ").strip()
        
        if not user_input:
            print("Empty input! Using default example...")
            raw_input_codes = ["234", "123", "045", "789", "012", "456", "023", "567"]
        else:
            # تبدیل ورودی به لیست رشته‌ای سه‌رقمی (as strings to preserve leading zeros)
            raw_input_codes = user_input.split()
        
        # بررسی صحت ورودی‌ها (validate inputs)
        for code in raw_input_codes:
            if not code.isdigit() or len(code) != 3:
                print(f"❌ Error: Code '{code}' must be a 3-digit number (e.g. 012, 999)")
                return
        
        # تبدیل به لیست اعداد برای پردازش عددی (convert to integers)
        student_codes = [int(code) for code in raw_input_codes]
        
        print(f"\nReceived codes: {['{:03d}'.format(c) for c in student_codes]}")
        print("\n" + "-" * 50)
        
        # اجرای مرتب‌سازی مبنایی (execute radix sort)
        sorted_codes = radix_sort_three_digit(student_codes)
        
        print("=" * 70)
        print("📊 FINAL RESULTS:")
        print("=" * 70)
        print(f"Original codes: {['{:03d}'.format(c) for c in student_codes]}")
        print(f"Sorted codes:   {['{:03d}'.format(c) for c in sorted_codes]}")
        print()
        print("✅ Success! Meowvard students can now select their courses! 🎉")
        
    except ValueError:
        print("❌ Error: Please enter only 3-digit integers!")
        print("Correct example: 123 045 789 012")
        
    except Exception as e:
        print(f"❌ Unexpected error: {e}")

if __name__ == "__main__":
    main()