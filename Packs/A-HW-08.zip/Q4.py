def median_of_three(projects, low, high):
    """
    انتخاب محور با استفاده از روش میانه سه عنصر
    
    Args:
        projects: لیست پروژه‌ها
        low: ایندکس شروع
        high: ایندکس پایان
    
    Returns:
        ایندکس محور انتخاب شده
    """
    mid = (low + high) // 2
    
    # مقایسه نمرات پیچیدگی سه عنصر
    score_low = projects[low][1]
    score_mid = projects[mid][1]
    score_high = projects[high][1]
    
    # پیدا کردن میانه
    if score_low <= score_mid <= score_high or score_high <= score_mid <= score_low:
        return mid
    elif score_mid <= score_low <= score_high or score_high <= score_low <= score_mid:
        return low
    else:
        return high


def partition(projects, low, high):
    """
    تقسیم‌بندی آرایه حول محور (مرتب‌سازی صعودی)
    
    Args:
        projects: لیست پروژه‌ها
        low: ایندکس شروع
        high: ایندکس پایان
    
    Returns:
        موقعیت نهایی محور
    """
    # انتخاب محور با روش median-of-three
    pivot_index = median_of_three(projects, low, high)
    
    # انتقال محور به ابتدای بازه
    projects[low], projects[pivot_index] = projects[pivot_index], projects[low]
    
    pivot_score = projects[low][1]
    i = low + 1
    j = high
    
    while True:
        # پیدا کردن عنصری از چپ که بزرگتر از محور باشد
        while i <= j and projects[i][1] <= pivot_score:
            i += 1
        
        # پیدا کردن عنصری از راست که کوچکتر از محور باشد
        while i <= j and projects[j][1] > pivot_score:
            j -= 1
        
        if i <= j:
            # جابجایی
            projects[i], projects[j] = projects[j], projects[i]
        else:
            break
    
    # قرار دادن محور در موقعیت صحیح
    projects[low], projects[j] = projects[j], projects[low]
    return j


def quick_sort_median_of_three(projects, low=0, high=None):
    """
    مرتب‌سازی سریع با استفاده از median-of-three برای انتخاب محور
    
    Args:
        projects: لیست تاپل‌های (project_name, complexity_score)
        low: ایندکس شروع
        high: ایندکس پایان
    
    Returns:
        لیست مرتب‌شده به ترتیب صعودی
    """
    if high is None:
        high = len(projects) - 1
    
    if low < high:
        # تقسیم‌بندی
        pivot_index = partition(projects, low, high)
        
        # مرتب‌سازی بازگشتی
        quick_sort_median_of_three(projects, low, pivot_index - 1)
        quick_sort_median_of_three(projects, pivot_index + 1, high)
    
    return projects


# خواندن ورودی
n = int(input())
projects = []

for _ in range(n):
    line = input().strip()
    parts = line.rsplit(',', 1)
    project_name = parts[0].strip()
    complexity_score = int(parts[1].strip())
    projects.append((project_name, complexity_score))

# مرتب‌سازی
sorted_projects = quick_sort_median_of_three(projects)

# چاپ خروجی
for project in sorted_projects:
    print(f"{project[0]}, {project[1]}")