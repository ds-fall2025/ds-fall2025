class Node:
    """
    کلاس Node برای ذخیره اطلاعات هر دانشجو در linked list
    key: شماره دانشجویی (یکتا)
    value: دیکشنری حاوی اطلاعات دانشجو (نام، معدل، ...)
    next: اشارهگر به Node بعدی در زنجیره
    """
    def __init__(self, key, value):
        self.key = key
        self.value = value
        self.next = None

class HashTable:
    """
    جدول هش با روش زنجیرهسازی مجزا (Separate Chaining)
    برای مدیریت اطلاعات دانشجویان با دسترسی سریع
    """
    def __init__(self, size=10):
        self.size = size
        # ایجاد آرایهای از headهای linked list (None به معنای خالی بودن)
        self.table = [None] * self.size
    
    def hash_function(self, key):
        """
        تابع هش ساده: باقیمانده تقسیم کلید بر اندازه جدول
        میتواند پیچیدهتر شود اما برای نمونه کافی است
        """
        return key % self.size
    
    def insert(self, key, value):
        """
        درج اطلاعات یک دانشجو در جدول هش
        اگر کلید تکراری باشد، مقدار قبلی را بهروزرسانی میکند
        پیچیدگی: O(1) میانگین، O(n) بدترین حالت
        """
        index = self.hash_function(key)
        current = self.table[index]
        
        # بررسی اینکه آیا کلید قبلاً وجود دارد؟
        while current:
            if current.key == key:
                # بهروزرسانی مقدار قبلی
                current.value = value
                return
            current = current.next
        
        # اگر کلید جدید است، Node جدید در ابتدای linked list اضافه کن
        new_node = Node(key, value)
        new_node.next = self.table[index]
        self.table[index] = new_node
    
    def search(self, key):
        """
        جستجوی اطلاعات یک دانشجو بر اساس شماره دانشجویی
        خروجی: دیکشنری اطلاعات دانشجو یا None اگر پیدا نشد
        پیچیدگی: O(1) میانگین، O(n) بدترین حالت
        """
        index = self.hash_function(key)
        current = self.table[index]
        
        # جستجو در linked list مربوطه
        while current:
            if current.key == key:
                # دانشجو پیدا شد
                return current.value
            current = current.next
        
        # دانشجو پیدا نشد
        return None
    
    def delete(self, key):
        """
        حذف اطلاعات یک دانشجو از جدول هش
        خروجی: True اگر حذف موفق بود، False اگر دانشجو پیدا نشد
        پیچیدگی: O(1) میانگین، O(n) بدترین حالت
        """
        index = self.hash_function(key)
        current = self.table[index]
        prev = None
        
        # جستجو در linked list برای پیدا کردن Node مورد نظر
        while current:
            if current.key == key:
                # Node پیدا شد، حذف آن
                if prev:
                    # اگر Node وسط یا انتهای لیست است
                    prev.next = current.next
                else:
                    # اگر Node اول لیست است
                    self.table[index] = current.next
                return True
            
            prev = current
            current = current.next
        
        # دانشجو پیدا نشد، حذف ناموفق
        return False

# --- بخش خواندن ورودی و اجرای برنامه ---
if __name__ == "__main__":
    try:
        # ایجاد جدول هش با اندازه 10
        student_hash_table = HashTable(size=10)
        
        # خواندن تعداد عملیات
        n = int(input())
        
        # اجرای هر عملیات
        for _ in range(n):
            operation_parts = input().split()
            
            if len(operation_parts) < 2:
                continue
            
            operation = operation_parts[0]
            
            if operation == "insert":
                # insert <student_id> <name> <gpa>
                student_id = int(operation_parts[1])
                name = operation_parts[2]
                gpa = float(operation_parts[3])
                student_hash_table.insert(student_id, {"name": name, "gpa": gpa})
            
            elif operation == "search":
                # search <student_id>
                student_id = int(operation_parts[1])
                result = student_hash_table.search(student_id)
                if result:
                    # چاپ اطلاعات دانشجو به صورت ساده
                    print(f"{result['name']},{result['gpa']}")
                else:
                    print("None")
            
            elif operation == "delete":
                # delete <student_id>
                student_id = int(operation_parts[1])
                student_hash_table.delete(student_id)
    
    except ValueError as e:
        print(f"خطا در ورودی: {e}")
    except EOFError:
        print("خطا: ورودی کافی فراهم نشد.")
    except Exception as e:
        print(f"خطای غیرمنتظره: {e}")