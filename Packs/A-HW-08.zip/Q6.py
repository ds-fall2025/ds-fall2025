def median_of_medians(arr, k):
    """
    پیدا کردن k-امین عنصر کوچک در آرایه با استفاده از الگوریتم میانه میانهها
    تضمین پیچیدگی زمانی O(n) در بدترین حالت
    """
    # اگر طول آرایه 5 یا کمتر باشد، مستقیماً مرتب کرده و k-امین عنصر را برمیگردانیم
    if len(arr) <= 5:
        return sorted(arr)[k]
    
    # 1. آرایه را به گروههای 5 تایی تقسیم میکنیم
    groups = [arr[i:i+5] for i in range(0, len(arr), 5)]
    
    # 2. میانه هر گروه را پیدا میکنیم
    medians = [sorted(group)[len(group)//2] for group in groups]
    
    # 3. به صورت بازگشتی میانه میانهها را پیدا میکنیم (محور اصلی)
    pivot = median_of_medians(medians, len(medians)//2)
    
    # 4. آرایه را بر اساس محور به سه بخش تقسیم میکنیم
    left = [x for x in arr if x < pivot]      # عناصر کوچکتر از محور
    middle = [x for x in arr if x == pivot]   # عناصر مساوی با محور
    right = [x for x in arr if x > pivot]     # عناصر بزرگتر از محور
    
    # 5. بسته به موقعیت k، روی بخش مناسب بازگشت انجام میدهیم
    if k < len(left):
        return median_of_medians(left, k)
    elif k < len(left) + len(middle):
        return pivot
    else:
        return median_of_medians(right, k - len(left) - len(middle))

def find_kth_largest_median_of_medians(scores, k):
    """
    پیدا کردن k-امین نمره بزرگترین با استفاده از میانه میانهها
    برای یافتن k-امین بزرگترین، از (n-k)-امین کوچکترین استفاده میکنیم
    """
    if not scores or k < 1 or k > len(scores):
        raise ValueError("ورودی نامعتبر: آرایه خالی یا K خارج از محدوده")
    
    n = len(scores)
    # k-امین بزرگترین = (n-k)-امین کوچکترین
    return median_of_medians(scores, n - k)

# --- بخش خواندن ورودی و اجرای برنامه ---

try:
    # خواندن ورودی لیست نمرات - خط اول
    # نمرات دانشجویان (با فاصله جدا کنید)
    scores = list(map(int, input().split()))

    # خواندن ورودی K (رتبه مورد نظر) - خط دوم
    # رتبه K-امین بزرگترین
    k = int(input())
    
    # پیدا کردن k-امین نمره بزرگترین
    result = find_kth_largest_median_of_medians(scores, k)

    # چاپ خروجی
    print(result)

except ValueError as e:
    print(f"خطا در ورودی: {e}")
except EOFError:
    print("خطا: ورودی کافی فراهم نشد.")
except Exception as e:
    print(f"خطای غیرمنتظره: {e}")