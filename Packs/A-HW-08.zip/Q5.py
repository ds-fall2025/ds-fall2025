def partition(wait_times, low, high):
    """
    تقسیم‌بندی آرایه حول محور (آخرین عنصر)
    
    Args:
        wait_times: لیست زمان‌های انتظار (که تغییر می‌کند)
        low: ایندکس شروع
        high: ایندکس پایان
    
    Returns:
        موقعیت نهایی محور (pivot)
    """
    # انتخاب محور (آخرین عنصر)
    pivot = wait_times[high]
    i = low - 1
    
    for j in range(low, high):
        # اگر عنصر فعلی کوچکتر یا مساوی محور باشد، آن را به سمت چپ می‌برد
        if wait_times[j] <= pivot:
            i += 1
            wait_times[i], wait_times[j] = wait_times[j], wait_times[i]
    
    # قرار دادن محور در موقعیت صحیح خود (بعد از عناصر کوچک‌تر)
    wait_times[i + 1], wait_times[high] = wait_times[high], wait_times[i + 1]
    return i + 1


def quick_select(wait_times, low, high, k_index):
    """
    الگوریتم Quick Select برای پیدا کردن k_index-امین عنصر کوچکترین
    
    Args:
        wait_times: لیست زمان‌های انتظار
        low: ایندکس شروع
        high: ایندکس پایان
        k_index: ایندکس عنصر مورد نظر (0-indexed کوچکترین)
    
    Returns:
        k_index-امین عنصر کوچکترین
    """
    # اگر بخش آرایه فقط یک عنصر داشته باشد
    if low == high:
        return wait_times[low]
    
    # تقسیم‌بندی آرایه
    pivot_index = partition(wait_times, low, high)
    
    # بررسی موقعیت محور نسبت به ایندکس k مورد نظر
    if pivot_index == k_index:
        # پیدا شد
        return wait_times[pivot_index]
    elif pivot_index > k_index:
        # جستجو در سمت چپ (زیرا k کوچکتر از pivot_index است)
        return quick_select(wait_times, low, pivot_index - 1, k_index)
    else:
        # جستجو در سمت راست (زیرا k بزرگتر از pivot_index است)
        return quick_select(wait_times, pivot_index + 1, high, k_index)


def find_kth_largest(wait_times, k):
    """
    پیدا کردن k-امین عنصر بزرگترین با استفاده از Quick Select
    
    Args:
        wait_times: لیست زمان‌های انتظار
        k: رتبه عنصر مورد نظر (1-indexed، k=1 بزرگترین است)
    
    Returns:
        k-امین زمان انتظار بزرگترین
    """
    if not wait_times or k <= 0 or k > len(wait_times):
        # بررسی ورودی نامعتبر (لیست خالی یا k خارج از محدوده)
        raise ValueError("ورودی نامعتبر: لیست زمان‌ها خالی است یا k خارج از محدوده است.")

    n = len(wait_times)
    
    # تبدیل k-امین بزرگترین به ایندکس k_index-امین کوچکترین
    # k-امین بزرگترین = (n - k)-امین کوچکترین (که 0-indexed است)
    kth_smallest_index = n - k
    
    # کپی لیست برای جلوگیری از تغییر لیست اصلی ارسالی
    wait_times_copy = wait_times.copy()
    
    return quick_select(wait_times_copy, 0, n - 1, kth_smallest_index)


# --- بخش خواندن ورودی و اجرای برنامه ---

try:
    # خواندن ورودی N (تعداد) - خط اول
    # N = int(input("تعداد دانشجویان (N): "))
    N = int(input())

    # خواندن ورودی لیست زمان‌های انتظار - خط دوم
    # wait_times = list(map(int, input("زمان‌های انتظار (با فاصله جدا کنید): ").split()))
    wait_times = list(map(int, input().split()))

    # خواندن ورودی K (رتبه مورد نظر) - خط سوم
    # k = int(input("رتبه K-امین بزرگترین: "))
    k = int(input())
    
    # پیدا کردن k-امین زمان انتظار بزرگترین
    result = find_kth_largest(wait_times, k)

    # چاپ خروجی
    print(result)

except ValueError as e:
    # چاپ خطاهای احتمالی در ورودی یا از find_kth_largest
    print(f"خطا در ورودی: {e}")
except EOFError:
    print("خطا: ورودی کافی فراهم نشد.")
except Exception as e:
    print(f"خطای غیرمنتظره: {e}")