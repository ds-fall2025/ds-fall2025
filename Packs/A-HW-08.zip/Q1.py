class UnionFind:
    """
    کلاس Union-Find (Disjoint Set Union) برای مدیریت شبکه‌های کامپیوتری
    
    این کلاس شبکه‌های مجزا را مدیریت کرده و امکان اتصال و جست‌وجو را فراهم می‌کند
    """
    
    def __init__(self):
        """
        سازنده کلاس - مقداردهی اولیه ساختارهای داده
        """
        self.parent = {}  # والد هر گره
        self.rank = {}  # رتبه (عمق تقریبی) هر درخت
        self.graph = {}  # گراف برای ذخیره اتصالات (لیست مجاورت)
    
    def make_set(self, u):
        """
        ایجاد یک شبکه مستقل جدید با یک کامپیوتر
        
        ورودی:
            u: شناسه کامپیوتر
        """
        # بررسی وجود قبلی
        if u in self.parent:
            print("already exist")
            return
        
        # ایجاد شبکه جدید
        self.parent[u] = u  # والد خودش است (ریشه)
        self.rank[u] = 0  # رتبه اولیه صفر
        self.graph[u] = []  # لیست مجاورت خالی
        
        print(f"Computer {u} added as a new network")
    
    def find(self, u):
        """
        پیدا کردن ادمین (ریشه) شبکه‌ای که u در آن قرار دارد
        
        ورودی:
            u: شناسه کامپیوتر
        
        خروجی:
            شناسه ادمین یا None
        """
        # بررسی وجود کامپیوتر
        if u not in self.parent:
            return None
        
        # پیدا کردن ریشه با فشرده‌سازی مسیر (Path Compression)
        if self.parent[u] != u:
            self.parent[u] = self.find(self.parent[u])
        
        return self.parent[u]
    
    def find_command(self, u):
        """
        اجرای دستور find و چاپ نتیجه
        
        ورودی:
            u: شناسه کامپیوتر
        """
        admin = self.find(u)
        
        if admin is None:
            print(f"Computer {u} does not exist")
        else:
            print(f"Admin of {u} is {admin}")
    
    def connect(self, u, v):
        """
        اتصال دو شبکه (اتحاد دو مجموعه)
        
        ورودی:
            u, v: شناسه‌های دو کامپیوتر
        """
        # بررسی وجود هر دو کامپیوتر
        if u not in self.parent or v not in self.parent:
            print(f"Computer {u} or {v} does not exist")
            return
        
        # پیدا کردن ادمین‌های هر شبکه
        root_u = self.find(u)
        root_v = self.find(v)
        
        # اگر در یک شبکه باشند
        if root_u == root_v:
            print(f"{u} and {v} are already in the same network")
            return
        
        # اضافه کردن یال بین ادمین u و v در گراف
        self.graph[root_u].append(root_v)
        self.graph[root_v].append(root_u)
        
        # اتحاد بر اساس رتبه (Union by Rank)
        # ادمین جدید کوچک‌ترین شناسه است
        new_admin = min(root_u, root_v)
        old_admin = max(root_u, root_v)
        
        # تنظیم والد
        self.parent[old_admin] = new_admin
        # اگر جدول والد/عمق قبلاً ساخته شده بود، آن را پاک کنیم تا بار بعد بازسازی شود
        if hasattr(self, '_ptree'):
            del self._ptree
        if hasattr(self, '_depth'):
            del self._depth
        
        # به‌روزرسانی رتبه
        if self.rank[root_u] == self.rank[root_v]:
            self.rank[new_admin] += 1
        
        print(f"Networks of {u} and {v} merged. New admin is {new_admin}")
    
    def send(self, u, v):
        """
        ارسال پیام از u به v و محاسبه تعداد گام‌ها
        
        ورودی:
            u, v: شناسه کامپیوتر مبدأ و مقصد
        """
        # بررسی وجود هر دو کامپیوتر
        if u not in self.parent or v not in self.parent:
            print(f"Computer {u} or {v} does not exist")
            return
        
        # بررسی اینکه در یک شبکه باشند
        if self.find(u) != self.find(v):
            print("Message cannot be sent")
            return
        
        # محاسبه فاصله با استفاده از BFS
        hops = self._calculate_distance(u, v)
        
        print(f"Message from {u} to {v}: {hops} hops")
    
# ---------------------------------------------------------
# 1) ساخت parent_tree و depth روی درخت واقعی (graph)
# ---------------------------------------------------------
    def _build_parent_tree(self, root: int):
        """یکبار BFS از root روی self.graph تا والد واقعی هر گره بدست آید"""
        from collections import deque
        self._ptree = {root: root}          # والد واقعی در گراف
        self._depth = {root: 0}             # عمق از ریشه
        q = deque([root])
        while q:
            cur = q.popleft()
            for nxt in self.graph[cur]:     # یال‌های واقعی
                if nxt not in self._ptree:  # اولین دیدار
                    self._ptree[nxt] = cur
                    self._depth[nxt] = self._depth[cur] + 1
                    q.append(nxt)
        self._last_root = root              # یادداشت ریشه فعلی

    # ---------------------------------------------------------
    # 2) LCA روی درخت واقعی (graph)
    # ---------------------------------------------------------
    def _lca(self, u: int, v: int) -> int:
        """بالا می‌رویم تا اولین ancestor مشترک را پیدا کنیم"""
        root = self.find(u)                 # ریشه فعلی شبکه
        if not hasattr(self, '_ptree') or self._last_root != root:
            self._build_parent_tree(root)

        # مسیر u تا ریشه
        path_u = set()
        cur = u
        while cur != self._ptree[cur]:
            path_u.add(cur)
            cur = self._ptree[cur]
        path_u.add(cur)                     # خود ریشه

        # بالا رفتن از v تا اولین مشترک
        cur = v
        while cur not in path_u:
            cur = self._ptree[cur]
        return cur                          # LCA

    # ---------------------------------------------------------
    # 3) شمارش یال‌ها (hops) = u→LCA + v→LCA
    # ---------------------------------------------------------
    def _calculate_distance(self, u: int, v: int) -> int:
        """فقط با بالا رفتن از والد واقعی، هر یال را می‌شماریم"""
        if u == v:
            return 0
        lca_node = self._lca(u, v)
        hops = 0
        # گام‌های u تا LCA
        cur = u
        while cur != lca_node:
            cur = self._ptree[cur]
            hops += 1
        # گام‌های v تا LCA
        cur = v
        while cur != lca_node:
            cur = self._ptree[cur]
            hops += 1
        return hops
    
def main():
    """
    تابع اصلی برنامه - دریافت دستورات و اجرای عملیات‌ها
    """
    # ایجاد نمونه از ساختار Union-Find
    network = UnionFind()
    
    # حلقه اصلی برای دریافت و پردازش دستورات
    while True:
        try:
            # دریافت دستور از کاربر
            command_line = input().strip()
            
            # بررسی خالی بودن دستور
            if not command_line:
                print("Invalid input")
                continue
            
            # تجزیه دستور به قسمت‌های مختلف
            command_parts = command_line.split()
            
            # بررسی وجود دستور
            if len(command_parts) == 0:
                print("Invalid input")
                continue
            
            # دریافت نام دستور (حروف کوچک)
            command = command_parts[0].lower()
            
            # شناسایی نوع دستور و اجرای آن
            if command == "make_set":
                # بررسی تعداد پارامترها
                if len(command_parts) != 2:
                    print("Invalid input")
                    continue
                
                try:
                    # دریافت شناسه کامپیوتر
                    u = int(command_parts[1])
                    
                    # بررسی مثبت بودن شناسه
                    if u <= 0:
                        print("Invalid input")
                        continue
                    
                    # ایجاد شبکه جدید
                    network.make_set(u)
                except ValueError:
                    # اگر شناسه عدد صحیح نباشد
                    print("Invalid input")
            
            elif command == "find":
                # بررسی تعداد پارامترها
                if len(command_parts) != 2:
                    print("Invalid input")
                    continue
                
                try:
                    # دریافت شناسه کامپیوتر
                    u = int(command_parts[1])
                    
                    # جست‌وجوی ادمین
                    network.find_command(u)
                except ValueError:
                    # اگر شناسه عدد صحیح نباشد
                    print("Invalid input")
            
            elif command == "connect":
                # بررسی تعداد پارامترها
                if len(command_parts) != 3:
                    print("Invalid input")
                    continue
                
                try:
                    # دریافت شناسه‌های دو کامپیوتر
                    u = int(command_parts[1])
                    v = int(command_parts[2])
                    
                    # اتصال دو شبکه
                    network.connect(u, v)
                except ValueError:
                    # اگر شناسه‌ها عدد صحیح نباشند
                    print("Invalid input")
            
            elif command == "send":
                # بررسی تعداد پارامترها
                if len(command_parts) != 3:
                    print("Invalid input")
                    continue
                
                try:
                    # دریافت شناسه‌های مبدأ و مقصد
                    u = int(command_parts[1])
                    v = int(command_parts[2])
                    
                    # ارسال پیام
                    network.send(u, v)
                except ValueError:
                    # اگر شناسه‌ها عدد صحیح نباشند
                    print("Invalid input")
            
            elif command == "exit":
                # خروج از برنامه
                break
            
            else:
                # دستور نامعتبر
                print("Invalid input")
        
        except EOFError:
            # پایان ورودی
            break
        except Exception as e:
            # خطای غیرمنتظره
            print("Invalid input")


# نقطه شروع برنامه
if __name__ == "__main__":
    main()
