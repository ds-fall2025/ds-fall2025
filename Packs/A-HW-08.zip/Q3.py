def quick_sort_events(events):
    """
    مرتب‌سازی سریع برای لیست رویدادها بر اساس تعداد شرکت‌کنندگان (نزولی)
    
    Args:
        events: لیستی از تاپل‌های (event_name, expected_attendance)
    
    Returns:
        لیست مرتب‌شده به ترتیب نزولی بر اساس expected_attendance
    """
    # حالت پایه: اگر لیست خالی یا یک عنصری باشد
    if len(events) <= 1:
        return events
    
    # انتخاب محور (اولین عنصر)
    pivot = events[0]
    pivot_attendance = pivot[1]
    
    # تقسیم آرایه به سه بخش
    # عناصر بزرگتر از محور (برای مرتب‌سازی نزولی)
    greater = [event for event in events[1:] if event[1] > pivot_attendance]
    
    # عناصر مساوی با محور
    equal = [event for event in events if event[1] == pivot_attendance]
    
    # عناصر کوچکتر از محور
    less = [event for event in events[1:] if event[1] < pivot_attendance]
    
    # ترکیب نتایج به صورت بازگشتی
    return quick_sort_events(greater) + equal + quick_sort_events(less)


# خواندن ورودی
n = int(input())
events = []

for _ in range(n):
    line = input().strip()
    parts = line.rsplit(',', 1)  # تقسیم از آخر برای مدیریت کاما در نام
    event_name = parts[0].strip()
    expected_attendance = int(parts[1].strip())
    events.append((event_name, expected_attendance))

# مرتب‌سازی
sorted_events = quick_sort_events(events)

# چاپ خروجی
for event in sorted_events:
    print(f"{event[0]}, {event[1]}")