class HashTableOA:
    """
    جدول هش با روش آدرسدهی باز (Open Addressing) و حل تداخل با کاوش خطی (Linear Probing)
    دادهها مستقیماً در آرایه اصلی ذخیره میشوند و از لیستهای جداگانه (Chaining) استفاده نمیشود
    پیچیدگی میانگین: O(1) برای جستجو، درج و حذف
    پیچیدگی بدترین حالت: O(n) وقتی همه کلیدها به یک اندیس هش شوند
    """
    def __init__(self, size=17):
        """
        ایجاد جدول هش با اندازه مشخص
        از عدد اول استفاده میشود تا توزیع هش یکنواختتر باشد
        """
        self.size = size
        self.table = [None] * self.size
        # نشانگر ویژه برای اسلاتهای حذف شده (مهم برای حفظ زنجیره کاوش خطی)
        self.DELETED = ("__DELETED__", None)

    def hash_function(self, key):
        """
        تابع هش: تبدیل کلید (نام کاربری) به اندیس جدول
        برای رشته: حاصل جمع کد کاراکترها را بر اندازه جدول میگیرد
        """
        # تبدیل کلید به رشته و جمع کد ASCII کاراکترها
        key_str = str(key)
        return sum(ord(char) for char in key_str) % self.size

    def insert(self, key, value):
        """
        درج یا بهروزرسانی اطلاعات در جدول هش
        اگر کلید تکراری باشد، مقدار آن بهروز میشود
        در صورت تداخل، از کاوش خطی استفاده میکند
        """
        idx = self.hash_function(key)
        i = 0  # شمارنده برای کاوش خطی
        
        while True:
            current_slot = self.table[idx]
            
            # اسلات خالی یا حذف شده پیدا شد -> میتوان اینجا درج کرد
            if current_slot is None or current_slot == self.DELETED:
                self.table[idx] = (key, value)
                return True
            
            # کلید قبلاً وجود دارد -> بهروزرسانی مقدار
            if current_slot[0] == key:
                self.table[idx] = (key, value)
                return True
            
            # تداخلی رخ داده -> به سراغ اسلات بعدی (کاوش خطی)
            i += 1
            idx = (self.hash_function(key) + i) % self.size
            
            # اگر کل جدول پر باشد (باید اندازه را افزایش دهیم اما اینجا ساده میکنیم)
            if i >= self.size:
                # میتوانیم اینجا اندازه جدول را تغییر دهیم (resize) یا خطا بدهیم
                # برای سادگی، فقط False برمیگردانیم
                return False

    def search(self, key):
        """
        جستجوی کلید در جدول هش
        در صورت یافتن مقدار (رمز هش شده) را برمیگرداند
        در غیر این صورت None برمیگرداند
        """
        idx = self.hash_function(key)
        i = 0
        
        while True:
            current_slot = self.table[idx]
            
            # اسلات خالی -> کلید پیدا نشد (پایان زنجیره کاوش)
            if current_slot is None:
                return None
            
            # اسلات حذف شده -> ادامه میدهیم (مهم برای حفظ زنجیره کاوش)
            if current_slot == self.DELETED:
                i += 1
                idx = (self.hash_function(key) + i) % self.size
                continue
            
            # کلید پیدا شد
            if current_slot[0] == key:
                return current_slot[1]
            
            # کلید متفاوت -> ادامه کاوش
            i += 1
            idx = (self.hash_function(key) + i) % self.size
            
            # اگر کل جدول کاوش شد و پیدا نشد
            if i >= self.size:
                return None

    def delete(self, key):
        """
        حذف کلید از جدول هش
        به جای خالی کردن اسلات، آن را با نشانگر DELETED علامتگذاری میکنیم
        این کار برای حفظ درستی عملیات جستجو ضروری است
        """
        idx = self.hash_function(key)
        i = 0
        
        while True:
            current_slot = self.table[idx]
            
            # اسلات خالی -> کلید وجود ندارد
            if current_slot is None:
                return False
            
            # اسلات حذف شده -> ادامه میدهیم
            if current_slot == self.DELETED:
                i += 1
                idx = (self.hash_function(key) + i) % self.size
                continue
            
            # کلید پیدا شد -> حذف (علامتگذاری)
            if current_slot[0] == key:
                self.table[idx] = self.DELETED
                return True
            
            i += 1
            idx = (self.hash_function(key) + i) % self.size
            
            # اگر کل جدول کاوش شد و پیدا نشد
            if i >= self.size:
                return False

# --- بخش خواندن ورودی و اجرای برنامه ---
if __name__ == "__main__":
    try:
        # ایجاد جدول هش با اندازه اولیه (عدد اول برای کیفیت بهتر هش)
        wifi_auth_table = HashTableOA(size=17)
        
        # خواندن تعداد عملیات
        n = int(input())
        
        # پردازش هر عملیات
        for _ in range(n):
            operation_parts = input().split()
            
            if len(operation_parts) < 2:
                continue
            
            operation = operation_parts[0]
            
            if operation == "insert" and len(operation_parts) == 3:
                # insert <username> <hashed_password>
                username = operation_parts[1]
                hashed_password = operation_parts[2]
                wifi_auth_table.insert(username, hashed_password)
            
            elif operation == "search" and len(operation_parts) == 2:
                # search <username>
                username = operation_parts[1]
                result = wifi_auth_table.search(username)
                print(result)
            
            elif operation == "delete" and len(operation_parts) == 2:
                # delete <username>
                username = operation_parts[1]
                result = wifi_auth_table.delete(username)
                print(result)
            else:
                # عملیات نامعتبر - نادیده میگیرد
                pass
    
    except ValueError as e:
        print(f"خطا در ورودی: {e}")
    except EOFError:
        print("خطا: ورودی کافی فراهم نشد.")
    except Exception as e:
        print(f"خطای غیرمنتظره: {e}")