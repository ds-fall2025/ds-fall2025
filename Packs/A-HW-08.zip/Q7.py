def binary_search_lower_bound_descending(arr, threshold):
    """
    جستجوی باینری برای پیدا کردن اولین اندیس که عنصر < threshold
    در آرایه نزولی مرتب شده (معادل Lower Bound)
    پیچیدگی زمانی: O(log n)
    """
    left, right = 0, len(arr)
    
    while left < right:
        mid = (left + right) // 2
        if arr[mid] >= threshold:
            # اگر عنصر میانی >= آستانه، هنوز در ناحیه پذیرفتهشدگان هستیم
            left = mid + 1
        else:
            # اگر عنصر میانی < آستانه، وارد ناحیه ردشدگان شدیم
            right = mid
    
    return left

def binary_search_upper_bound_descending(arr, threshold):
    """
    جستجوی باینری برای پیدا کردن اولین اندیس که عنصر <= threshold
    در آرایه نزولی مرتب شده (معادل Upper Bound)
    """
    left, right = 0, len(arr)
    
    while left < right:
        mid = (left + right) // 2
        if arr[mid] > threshold:
            left = mid + 1
        else:
            right = mid
    
    return left

# --- بخش خواندن ورودی و اجرای برنامه ---
if __name__ == "__main__":
    try:
        # خواندن لیست نمرات اولویت (خط اول) - فرض بر اینکه نزولی مرتب شده
        scores = list(map(int, input().split()))
        
        # خواندن آستانه نمره حداقل مورد نیاز (خط دوم)
        threshold = int(input())
        
        # پیدا کردن اندیس اولین دانشجویی که نتوانسته ثبتنام کند (Lower Bound)
        # این دانشجو اولین نفری است که نمره < آستانه را دارد
        rejected_index = binary_search_lower_bound_descending(scores, threshold)
        
        # چاپ خروجی
        print(rejected_index)
        
    except ValueError as e:
        print(f"خطا در ورودی: {e}")
    except EOFError:
        print("خطا: ورودی کافی فراهم نشد.")
    except Exception as e:
        print(f"خطای غیرمنتظره: {e}")