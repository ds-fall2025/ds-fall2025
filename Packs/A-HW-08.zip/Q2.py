class Node:
    """
    کلاس گره (Node) برای نمایش یک مرحله در پل جادویی
    
    هر گره نمایانگر یک نقطه عبور در پل است
    """
    
    def __init__(self, name):
        """
        سازنده کلاس - مقداردهی اولیه گره
        
        ورودی:
            name: نام نود
        """
        self.name = name      # نام نود
        self.next = None      # اشاره‌گر به نود بعدی در لیست پیوندی


class UnionFind:
    """
    کلاس Union-Find (Disjoint Set) برای مدیریت سگمنت‌های پل
    
    این کلاس مجموعه‌های مجزا را مدیریت می‌کند و عملیات اتحاد و جست‌وجو را فراهم می‌کند
    """
    
    def __init__(self):
        """
        سازنده کلاس - مقداردهی اولیه
        """
        self.parent = {}       # والد هر نود
        self.rank = {}         # رتبه (عمق تقریبی) هر مجموعه
        self.segment_info = {} # اطلاعات سگمنت هر نود
    
    def make_set(self, node_name, segment_number):
        """
        ایجاد یک مجموعه مستقل جدید برای یک نود
        
        ورودی:
            node_name: نام نود
            segment_number: شماره سگمنت متعلق به آن
        """
        self.parent[node_name] = node_name
        self.rank[node_name] = 0
        self.segment_info[node_name] = segment_number
    
    def find(self, node_name):
        """
        پیدا کردن نماینده (ریشه) مجموعه‌ای که نود در آن قرار دارد
        
        ورودی:
            node_name: نام نود
        
        خروجی:
            نام نماینده مجموعه
        
        از تکنیک Path Compression برای بهینه‌سازی استفاده می‌شود
        """
        if node_name not in self.parent:
            return None
        
        if self.parent[node_name] != node_name:
            self.parent[node_name] = self.find(self.parent[node_name])
        
        return self.parent[node_name]
    
    def union(self, node1, node2):
        """
        اتحاد دو مجموعه (اتصال دو نود)
        
        ورودی:
            node1, node2: نام دو نود برای اتحاد
        
        از تکنیک Union by Rank برای بهینه‌سازی استفاده می‌شود
        """
        root1 = self.find(node1)
        root2 = self.find(node2)
        
        if root1 == root2:
            return False
        
        if self.rank[root1] < self.rank[root2]:
            self.parent[root1] = root2
        elif self.rank[root1] > self.rank[root2]:
            self.parent[root2] = root1
        else:
            self.parent[root2] = root1
            self.rank[root1] += 1
        
        return True


class Segment:
    """
    کلاس سگمنت (بخش) برای مدیریت یک بخش از پل
    
    هر سگمنت شامل چندین نود است که به صورت لیست پیوندی مدیریت می‌شوند
    """
    
    def __init__(self, segment_number, nodes):
        """
        سازنده کلاس - مقداردهی اولیه سگمنت
        
        ورودی:
            segment_number: شماره سگمنت
            nodes: لیست نام نودهای سگمنت
        """
        self.segment_number = segment_number  # شماره سگمنت
        self.head = None                      # سر لیست پیوندی
        self.tail = None                      # انتهای لیست پیوندی
        self.nodes_list = []                  # لیست تمام نودها
        
        # ایجاد نودها و اتصال آن‌ها
        for node_name in nodes:
            self.add_node(node_name)
    
    def add_node(self, name):
        """
        اضافه کردن نود جدید به انتهای سگمنت
        
        ورودی:
            name: نام نود جدید
        """
        new_node = Node(name)
        self.nodes_list.append(new_node)
        
        if self.head is None:
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            self.tail = new_node


class BridgeGame:
    """
    کلاس اصلی بازی پیکار پل‌های جادویی
    
    این کلاس مدیریت کامل بازی شامل سگمنت‌ها، نودها و حرکت جنگجو را انجام می‌دهد
    با استفاده از Union-Find برای مدیریت مجموعه‌های مجزا
    """
    
    def __init__(self):
        """
        سازنده کلاس - مقداردهی اولیه بازی
        """
        self.segments = []                    # لیست تمام سگمنت‌ها
        self.union_find = UnionFind()         # ساختار Union-Find برای مدیریت مجموعه‌ها
        self.current_node = None              # نود فعلی
        self.current_segment_index = 0        # شماره سگمنت فعلی
        self.bridge_path = []                 # مسیر طی شده روی پل
        self.game_over = False                # وضعیت پایان بازی
    
    def load_segments(self):
        """
        دریافت تعداد سگمنت‌ها و سپس دریافت دقیقاً همان تعداد سگمنت معتبر
        هر ورودی اشتباه → فقط Invalid input چاپ می‌شود و ادامه می‌یابد
        شماره سگمنت مهم نیست، فقط فرمت درست باشد
        """
        # مرحله ۱: دریافت تعداد سگمنت‌ها (تا وقتی عدد معتبر وارد نشود ادامه بده)
        n = None
        while n is None:
            try:
                line = input().strip()
                if not line:
                    print("Invalid input")
                    continue
                num = int(line)
                if num <= 0:
                    print("Invalid input")
                    continue
                n = num
            except ValueError:
                print("Invalid input")
            except EOFError:
                return False

        # مرحله ۲: دریافت n تا سگمنت معتبر
        loaded = 0
        used_segment_numbers = set()  # برای جلوگیری از تکرار شماره سگمنت 

        while loaded < n:
            try:
                line = input().strip()
                if not line:
                    print("Invalid input")
                    continue

                # بررسی فرمت: Segment X: nodes...
                if not line.startswith("Segment ") or ":" not in line:
                    print("Invalid input")
                    continue

                prefix, nodes_part = line.split(":", 1)
                nodes_str = nodes_part.strip()

                # استخراج شماره سگمنت
                seg_part = prefix[8:].strip()  # بعد از "Segment "
                try:
                    seg_num = int(seg_part)
                    if seg_num <= 0 or seg_num in used_segment_numbers:
                        print("Invalid input")
                        continue
                except ValueError:
                    print("Invalid input")
                    continue

                if not nodes_str:
                    print("Invalid input")
                    continue

                nodes = nodes_str.split()
                if not nodes:
                    print("Invalid input")
                    continue

                # سگمنت معتبر است → اضافه کن
                segment = Segment(seg_num, nodes)
                self.segments.append(segment)
                used_segment_numbers.add(seg_num)

                # ثبت در Union-Find
                for node_name in nodes:
                    self.union_find.make_set(node_name, seg_num)
                for i in range(len(nodes) - 1):
                    self.union_find.union(nodes[i], nodes[i + 1])

                loaded += 1

            except EOFError:
                break

        return loaded == n
    def start_game(self):
        """
        شروع بازی و تنظیم نود اولیه
        """
        if len(self.segments) == 0:
            print("No segments available")
            return False
        
        self.current_node = self.segments[0].head
        self.current_segment_index = 0
        self.bridge_path = []
        return True
    
    
    def reset_to_start(self):
        """
        بازگشت به ابتدای بازی (نود اول سگمنت اول)
        """
        # نمایش مسیر فعلی پل
        if self.bridge_path:
            bridge_str = " ".join(self.bridge_path)
            print(f"Bridge: {bridge_str}")
        
        # بازسازی کامل Union-Find (مهم!)
        self.union_find = UnionFind()
        for idx, segment in enumerate(self.segments, 1):
            nodes = [node.name for node in segment.nodes_list]
            for node_name in nodes:
                self.union_find.make_set(node_name, idx)
            for i in range(len(nodes) - 1):
                self.union_find.union(nodes[i], nodes[i + 1])
        
        # ریست وضعیت بازی
        self.bridge_path = []
        self.current_node = self.segments[0].head
        self.current_segment_index = 0
    
    def process_command(self, command):
        """
        پردازش دستور وارد شده توسط کاربر
        
        ورودی:
            command: دستور (T, F, exit)
        
        خروجی:
            True اگر بازی ادامه دارد، False اگر باید خاتمه یابد
        """
        command = command.strip().upper()
        
        if command == "EXIT":
            self.game_over = True
            return False
        
        if command == "T":
            self.pass_node()
        elif command == "F":
            self.fail_node()
        else:
            print("Invalid input")
        
        return True
    
    
    def pass_node(self):
        """
        عبور موفق از نود فعلی
        """
        # اضافه کردن نود به مسیر
        self.bridge_path.append(self.current_node.name)
        
        print(f"Passed node {self.current_node.name}")
        
        # حرکت به نود بعدی
        if self.current_node.next is None:
            # پایان سگمنت فعلی
            print(f"Completed Segment {self.segments[self.current_segment_index].segment_number}")
            
            # بررسی پایان بازی
            if self.current_segment_index == len(self.segments) - 1:
                print("Victory")
                self.game_over = True
                return
            
            # حرکت به سگمنت بعدی
            self.current_segment_index += 1
            self.current_node = self.segments[self.current_segment_index].head
        else:
            # حرکت به نود بعدی در همان سگمنت
            next_node = self.current_node.next
            self.current_node = next_node  # همیشه متصل هستند → چک حذف شد
    
    def fail_node(self):
        """
        شکست در نود فعلی و بازگشت به ابتدا
        """
        print(f"Failed at {self.current_node.name}, resetting to start")
        self.reset_to_start()
    
    
    def play(self):
        """
        حلقه اصلی بازی
        """
        # بارگذاری سگمنت‌ها
        if not self.load_segments():
            return
        
        # شروع بازی
        if not self.start_game():
            return
        
        # حلقه اصلی بازی
        while not self.game_over:
            try:
                # نمایش نود فعلی
                print(f"Current node: {self.current_node.name}")
                
                # دریافت دستور کاربر
                command = input().strip()
                if not command:
                    print("Invalid input")
                    continue
                
                # پردازش دستور
                if not self.process_command(command):
                    break  # exit یا پیروزی
            
            except EOFError:
                break


def main():
    """
    تابع اصلی برنامه
    """
    game = BridgeGame()
    game.play()


if __name__ == "__main__":
    main()