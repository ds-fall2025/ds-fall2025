def binary_search_existence(arr, target):
    """
    جستجوی باینری برای بررسی وجود یک عنصر در آرایه مرتب شده صعودی
    پیچیدگی زمانی: O(log n)
    خروجی: True اگر عنصر وجود داشت، False در غیر این صورت
    """
    left, right = 0, len(arr) - 1
    
    # ادامه جستجو تا زمانی که محدوده معتبر باشد
    while left <= right:
        mid = (left + right) // 2  # محاسبه اندیس میانی
        
        if arr[mid] == target:
            # عنصر پیدا شد
            return True
        elif arr[mid] < target:
            # اگر عنصر میانی کوچکتر از هدف است، بخش چپ را حذف کن
            left = mid + 1
        else:
            # اگر عنصر میانی بزرگتر از هدف است، بخش راست را حذف کن
            right = mid - 1
    
    # عنصر در آرایه یافت نشد
    return False

# --- بخش خواندن ورودی و اجرای برنامه ---
if __name__ == "__main__":
    try:
        # خواندن لیست شمارههای طبقهبندی (خط اول) - فضاها را جدا کننده در نظر میگیرد
        call_numbers = list(map(int, input().split()))
        
        # خواندن شماره کتاب مورد جستجو (خط دوم)
        target_book = int(input())
        
        # بررسی وجود کتاب در کاتالوگ
        exists = binary_search_existence(call_numbers, target_book)
        
        # چاپ نتیجه (True یا False)
        print(exists)
        
    except ValueError as e:
        print(f"خطا در ورودی: {e}")
    except EOFError:
        print("خطا: ورودی کافی فراهم نشد.")
    except Exception as e:
        print(f"خطای غیرمنتظره: {e}")