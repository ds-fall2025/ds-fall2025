# صفحات ثابت
pages = {
    "PageA": ["data", "mining", "python"],
    "PageB": ["python", "machine", "learning"],
    "PageC": ["algorithm", "data", "search"],
    "PageD": ["database", "query", "sql"]
}

# تابع هش وزن‌دار: در نظر گرفتن موقعیت هر حرف


def weighted_hash(word):
    return sum((i + 1) * ord(c) for i, c in enumerate(word.lower()))

# محاسبه min-hash هر لیست از کلمات


def min_hash(word_list):
    # مرتب‌سازی کلمات قبل از محاسبه min-hash
    return min(weighted_hash(word) for word in word_list)

# تابع پیدا کردن مشابه‌ترین صفحه


def find_most_similar_page(new_page_str):
    # تبدیل رشته ورودی به لیست کلمات
    new_page = [word.strip()
                for word in new_page_str.split(",") if word.strip()]
    new_min_hash = min_hash(new_page)

    # بررسی min-hash صفحات موجود
    for name, keywords in pages.items():
        if min_hash(keywords) == new_min_hash:
            return name  # اولین صفحه مشابه را بازمی‌گرداند

    return "No match"  # اگر مشابهی یافت نشد


# -------------------------------
# تست: ورودی از کاربر
input_page = input()
result = find_most_similar_page(input_page)
print(result)
