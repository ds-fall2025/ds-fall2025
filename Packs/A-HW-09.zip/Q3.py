# تابع هش ساده: باقی‌مانده تقسیم کلید بر اندازه جدول
def hash_func(key, size):
    return key % size

# درج یک کلید در جدول با روش Linear Probing


def linear_probe_insert(table, key):
    size = len(table)
    index = hash_func(key, size)  # محاسبه ایندکس اولیه با استفاده از هش
    for i in range(size):
        # محاسبه موقعیت بعدی در صورت پر بودن خانه
        probe_index = (index + i) % size
        if table[probe_index] is None:  # اگر خانه خالی بود، کلید را درج کن
            table[probe_index] = key
            return True  # درج موفق
    return False  # اگر جدول پر باشد، درج موفق نبود

# بازحجیم و افزایش اندازه جدول


def rehash_and_resize(old_table, new_size):
    new_table = [None] * new_size  # ایجاد جدول جدید با اندازه بزرگتر
    for item in old_table:
        if item is not None:  # فقط عناصر غیر تهی را دوباره درج کن
            linear_probe_insert(new_table, item)
    return new_table

# درج کلیدها با مدیریت پر شدن جدول و بازحجیم


def insert_keys(keys):
    size = 5  # اندازه اولیه جدول
    table = [None] * size

    for key in keys:
        inserted = linear_probe_insert(table, key)  # تلاش برای درج کلید
        if not inserted:
            # اگر جدول پر بود، اندازه را دو برابر کن و بازحجیم انجام بده
            size *= 2
            table = rehash_and_resize(table, size)
            linear_probe_insert(table, key)  # درج کلید پس از بازحجیم

    return table

# چاپ عناصر جدول به صورت مرتب (حلقوی)


def print_circular_sorted(table):
    values = [x for x in table if x is not None]  # حذف خانه‌های تهی
    values.sort()  # مرتب‌سازی عناصر
    print(*values)  # چاپ عناصر با فاصله


# ----------------------------
# گرفتن ورودی از کاربر
input_str = input()  # ورودی اعداد با فاصله
keys = list(map(int, input_str.strip().split()))  # تبدیل به لیست اعداد صحیح

final_table = insert_keys(keys)  # درج کلیدها در جدول
print_circular_sorted(final_table)  # چاپ خروجی مرتب
