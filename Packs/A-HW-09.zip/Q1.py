class DynamicHashTable:
    def __init__(self, initial_size=5):
        # مقدار اولیه اندازه جدول هش
        self.size = initial_size

        # تعداد عناصر درج‌شده در جدول
        self.count = 0

        # ایجاد لیست اصلی با زنجیره‌های لیست خالی برای برخوردها
        self.table = [[] for _ in range(self.size)]

    def _hash(self, key: str) -> int:
        """
        تابع هش:
        مجموع کدهای ASCII کاراکترهای کلید را حساب می‌کند
        و سپس باقی‌مانده تقسیم آن بر اندازه جدول را برمی‌گرداند
        """
        return sum(ord(char) for char in key) % self.size

    def _rehash(self):
        """
        زمانی که تعداد عناصر برابر یا بیشتر از اندازه جدول شود،
        اندازه جدول دو برابر می‌شود و تمام عناصر در جدول جدید
        دوباره درج (reinsert) می‌گردند.
        """
        old_table = self.table

        # دو برابر کردن اندازه جدول
        self.size *= 2

        # ایجاد جدول جدید با اندازه جدید
        self.table = [[] for _ in range(self.size)]

        # شمارنده باید از اول محاسبه شود
        self.count = 0

        # بازدرج تمام عناصر قبلی بدون ایجاد ریهش دوباره
        for chain in old_table:
            for key in chain:
                self.insert_without_rehash(key)

    def insert_without_rehash(self, key: str):
        """
        درج یک عنصر بدون بررسی یا انجام ریهش.
        فقط برای زمانی استفاده می‌شود که جدول در حال بازسازی است.
        """
        index = self._hash(key)
        self.table[index].append(key)
        self.count += 1

    def insert(self, key: str):
        """
        درج عنصر جدید:
        - اگر جدول پر شود، ابتدا ریهش انجام می‌شود.
        - سپس کلید در مکان مناسب درج می‌شود.
        """
        if self.count >= self.size:
            self._rehash()

        self.insert_without_rehash(key)

    def display(self):
        """
        چاپ تمام خانه‌های جدول هش همراه با محتویات زنجیره هر خانه
        """
        for i in range(self.size):
            print(f"خانه {i}: {self.table[i]}")


# -------------------------
# برنامه اصلی
# -------------------------

# دریافت ورودی از کاربر و حذف فاصله‌های اضافه
raw_input_names = input().strip()

# تبدیل ورودی به لیست اسامی
if raw_input_names == "":
    names = []
else:
    names = [name.strip() for name in raw_input_names.split(",")]

# ایجاد جدول هش با اندازه اولیه ۵
hash_table = DynamicHashTable(initial_size=5)

# درج هر نام در جدول هش
for name in names:
    if name:  # جلوگیری از درج رشته خالی
        hash_table.insert(name)

# چاپ جدول نهایی
hash_table.display()
