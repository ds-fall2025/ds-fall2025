def get_min_hashes(items):
    """
    دریافت لیست کالاها و برگشت یک لیست شامل ۳ مقدار min-hash بر اساس ترتیب حروف الفبا:
    h1: اولین عنصر (کوچک‌ترین)
    h2: دومین عنصر
    h3: سومین عنصر
    اگر تعداد عناصر کمتر باشد، مقدار None برمی‌گردد.

    Parameters:
        items (set or list): مجموعه یا لیست کالاها

    Returns:
        list: لیستی شامل سه مقدار حداقل بر اساس ترتیب حروف الفبا
    """
    # تبدیل مجموعه به لیست و مرتب‌سازی حروف الفبا
    sorted_items = sorted(list(items))

    # انتخاب ۳ مقدار اول یا None اگر تعداد کمتر باشد
    h1 = sorted_items[0] if len(sorted_items) > 0 else None
    h2 = sorted_items[1] if len(sorted_items) > 1 else None
    h3 = sorted_items[2] if len(sorted_items) > 2 else None

    return [h1, h2, h3]


def compute_similarity(hashes1, hashes2):
    """
    محاسبه شباهت دو لیست min-hash بر اساس تعداد موقعیت‌های برابر
    و تقسیم بر تعداد موقعیت‌های معتبر.

    Parameters:
        hashes1 (list): لیست min-hash کاربر اول
        hashes2 (list): لیست min-hash کاربر دوم

    Returns:
        float: شباهت بین ۰ و ۱
    """
    match_count = 0
    valid_positions = 0
    for i in range(3):
        if hashes1[i] is not None and hashes2[i] is not None:
            valid_positions += 1
            if hashes1[i] == hashes2[i]:
                match_count += 1
    return match_count / valid_positions if valid_positions > 0 else 0


def find_most_similar_user(users, user_x):
    """
    یافتن کاربری که بیشترین شباهت را با مجموعه user_x دارد.

    Parameters:
        users (dict): دیکشنری کاربران و مجموعه کالاهای آن‌ها
        user_x (set): مجموعه کالاهای کاربر جدید

    Returns:
        str: نام کاربری با بیشترین شباهت
    """
    # پاک‌سازی رشته‌ها و حذف فاصله‌های اضافی
    user_x = {item.strip() for item in user_x if item.strip()}

    # محاسبه min-hash برای کاربر جدید
    x_hashes = get_min_hashes(user_x)

    max_similarity = -1
    most_similar_user = None

    for user, items in users.items():
        # پاک‌سازی رشته‌ها و min-hash برای هر کاربر
        items_cleaned = {item.strip() for item in items if item.strip()}
        user_hashes = get_min_hashes(items_cleaned)

        # محاسبه شباهت
        similarity = compute_similarity(x_hashes, user_hashes)

        # اگر شباهت بیشتر بود، به‌روزرسانی بیشترین شباهت
        if similarity > max_similarity:
            max_similarity = similarity
            most_similar_user = user

    return most_similar_user


# -----------------------------
# کاربران پیش‌فرض
users = {
    "User A": {"Sports Shoes", "Headphones", "Jacket"},
    "User B": {"Backpack", "Hiking Shoes", "Tent"},
    "User C": {"Headphones", "Sports Shoes", "Backpack"},
}

# -----------------------------
# دریافت ورودی از کاربر و تبدیل به مجموعه
input_str = input()
user_x = {item.strip() for item in input_str.split(",") if item.strip()}

# -----------------------------
# محاسبه و چاپ کاربری که بیشترین شباهت را دارد
result = find_most_similar_user(users, user_x)
print(result)
