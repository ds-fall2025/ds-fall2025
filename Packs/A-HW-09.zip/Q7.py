import math

# دریافت رشته‌ی ورودی شامل مختصات نقاط، مانند: "1 1, -2 2, -3 -3"
points_input = input()

# جدا کردن هر نقطه بر اساس کاما
points = points_input.split(',')

# شمارنده‌ی نقاط مورد نظر در ناحیه 1 و 3
count = 0

# پیمایش تک‌تک نقاط
for point in points:
    # جدا کردن مختصات x و y از طریق فاصله
    x_str, y_str = point.strip().split()
    x = int(x_str)
    y = int(y_str)

    # محاسبه فاصله نقطه از مبدأ (0,0)
    distance = math.sqrt(x**2 + y**2)

    # بررسی اینکه نقطه داخل یا روی محیط دایره با شعاع 4 قرار دارد
    if distance <= 4:
        # اگر نقطه در ناحیه 1 (x>0,y>0) یا ناحیه 3 (x<0,y<0) باشد
        if (x > 0 and y > 0) or (x < 0 and y < 0):
            count += 1

# چاپ تعداد نقاطی که در ناحیه 1 یا 3 هستند و در دایره قرار دارند
print(count)

