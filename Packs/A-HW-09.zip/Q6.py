# گرفتن ورودی از کاربر و تقسیم آن به بخش‌های مختلف
data = input().split()

# اولین مقدار ورودی، تعداد افراد است
n = int(data[0])

# ایجاد یک دیکشنری برای نگهداری اسامی بر اساس پیش‌شماره پستی
buckets = {}

# پردازش ورودی‌ها برای هر فرد
for i in range(n):
    # دریافت نام فرد
    name = data[1 + i * 2]
    # دریافت کد پستی فرد
    zip_code = data[1 + i * 2 + 1]
    # استخراج دو رقم اول کد پستی به عنوان پیش‌شماره
    prefix = zip_code[:2]

    # اگر پیش‌شماره هنوز در دیکشنری وجود ندارد، یک لیست خالی ایجاد می‌کنیم
    if prefix not in buckets:
        buckets[prefix] = []

    # اضافه کردن نام فرد به لیست مربوط به پیش‌شماره خود
    buckets[prefix].append(name)

# مرتب‌سازی دیکشنری بر اساس کلیدها به صورت عددی و از بزرگ به کوچک
sorted_buckets = sorted(buckets.items(), key=lambda x: int(x[0]), reverse=True)

# چاپ خروجی: پیش‌شماره و تعداد افراد مربوط به آن
for prefix, names in sorted_buckets:
    print(prefix, len(names))
