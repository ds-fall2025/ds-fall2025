import hashlib


def bits(s):
    """
    این تابع هش SHA-256 متن s را می‌گیرد و آن را به رشته باینری 256 بیتی تبدیل می‌کند.

    ورودی:
        s (str): رشته‌ای که باید هش شود
    خروجی:
        str: رشته باینری 256 بیتی متناظر با هش
    """
    hash_hex = hashlib.sha256(
        s.encode('utf-8')).hexdigest()  # تولید هش به صورت هگز
    # تبدیل هگز به عدد صحیح
    hash_int = int(hash_hex, 16)
    binary_str = bin(hash_int)[2:].zfill(
        256)                # تبدیل به باینری 256 بیتی
    return binary_str


# جدول دانشجویان (نام دانشجو -> شماره صندلی)
# نکته: برای سازگاری با ورودی‌ها، همه نام‌ها را به حروف کوچک ذخیره می‌کنیم
students = {
    "ali rezaei": 1001,
    "maryam ahmadi": 1002,
    "saeid abbasi": 1003,
    "negin kazemi": 1004,
    "zahra mohseni": 1005,
    "amir mohammadi": 1006,
    "samira ghorbani": 1007,
    "hasan karimi": 1008,
    "neda shahi": 1009,
    "reza mahmoudi": 1010
}


def find_chair(name):
    """
    این تابع بررسی می‌کند که نام داده شده در کلاس موجود است یا خیر
    و شماره صندلی آن را برمی‌گرداند.

    ورودی:
        name (str): نام دانشجو
    خروجی:
        list: اگر دانشجو پیدا شد [True, شماره صندلی]
              اگر پیدا نشد [False, "Not in this class"]
    """
    name_clean = name.strip().lower()  # پاک‌سازی فاصله‌ها و تبدیل به حروف کوچک
    b = bits(name_clean)               # هش باینری (فعلاً استفاده نشده)
    # سه بیت آخر هش (می‌تواند برای آینده استفاده شود)
    last3 = b[-3:]

    if name_clean in students:
        return [True, students[name_clean]]
    else:
        return [False, "Not in this class"]


# دریافت ورودی از کاربر
input_name = input().strip()  # پاک کردن فاصله‌های اضافی قبل و بعد ورودی
result = find_chair(input_name)
print(result)
