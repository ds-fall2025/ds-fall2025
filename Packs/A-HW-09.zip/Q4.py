# لیست علایق کاربران ثابت
users = {
    "Ali": ["ورزش", "تکنولوژی", "سینما", "سفر"],
    "Sara": ["سفر", "تکنولوژی", "تاریخ", "موسیقی"],
    "Reza": ["ورزش", "سینما", "سفر", "طبیعت"],
    "Niloofar": ["موسیقی", "نقاشی", "سینما", "تکنولوژی"]
}

# دریافت ورودی
input_str = input().strip()

# جایگزینی ویرگول انگلیسی با فارسی
input_str = input_str.replace(",", "،")

# جدا کردن علایق و حذف رشته‌های خالی
new_user = [x.strip() for x in input_str.split("،") if x.strip()]
new_user_set = set(new_user)

max_similarity = -1
most_similar_user = ""

for name, interests in users.items():
    user_set = set(interests)
    intersection_count = len(new_user_set & user_set)
    union_count = len(new_user_set | user_set)

    similarity = intersection_count / union_count if union_count else 0.0

    if similarity > max_similarity:
        max_similarity = similarity
        most_similar_user = name

# چاپ دقیق با دو رقم اعشار
print(
    f"User is most similar to: {most_similar_user} (Similarity: {max_similarity:.2f})")
