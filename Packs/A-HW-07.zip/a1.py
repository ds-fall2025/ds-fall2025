class TreeNode:
    """
    کلاس گره درخت جست‌وجوی دودویی
    
    هر گره نمایانگر یک کتاب با شناسه (ISBN) و عنوان (title) است
    """
    
    def __init__(self, isbn, title):
        """
        سازنده کلاس TreeNode - ایجاد یک گره جدید برای کتاب
        
        ورودی:
            isbn (int): شناسه یکتای کتاب
            title (str): عنوان کتاب
        """
        self.isbn = isbn  # شناسه کتاب
        self.title = title  # عنوان کتاب
        self.left = None  # اشاره‌گر به فرزند چپ
        self.right = None  # اشاره‌گر به فرزند راست


class BinarySearchTree:
    """
    کلاس درخت جست‌وجوی دودویی برای مدیریت کتابخانه
    
    این کلاس عملیات درج، جست‌وجو، حذف و نمایش کتاب‌ها را پیاده‌سازی می‌کند
    """
    
    def __init__(self):
        """
        سازنده کلاس - مقداردهی اولیه درخت خالی
        """
        self.root = None  # اشاره‌گر به ریشه درخت
    
    def add(self, isbn, title):
        """
        افزودن کتاب جدید به درخت
        
        ورودی:
            isbn (int): شناسه کتاب
            title (str): عنوان کتاب
        """
        # بررسی تکراری بودن ISBN
        if self._search(self.root, isbn) is not None:
            print("Book already exists")
            return
        
        # افزودن کتاب به درخت
        self.root = self._add_recursive(self.root, isbn, title)
        print(f"Book {isbn} {title} added")
    
    def _add_recursive(self, node, isbn, title):
        """
        افزودن بازگشتی کتاب به درخت
        
        ورودی:
            node (TreeNode): گره فعلی
            isbn (int): شناسه کتاب
            title (str): عنوان کتاب
        
        خروجی:
            TreeNode: ریشه زیردرخت پس از افزودن
        """
        # اگر به گره خالی رسیدیم، کتاب جدید را اینجا قرار می‌دهیم
        if node is None:
            return TreeNode(isbn, title)
        
        # مقایسه ISBN و تعیین مسیر چپ یا راست
        if isbn < node.isbn:
            node.left = self._add_recursive(node.left, isbn, title)
        else:
            node.right = self._add_recursive(node.right, isbn, title)
        
        return node
    
    def find(self, isbn):
        """
        جست‌وجوی کتاب و نمایش مسیر
        
        ورودی:
            isbn (int): شناسه کتاب مورد جست‌وجو
        """
        # جست‌وجو و ذخیره مسیر
        path = []
        result = self._search_with_path(self.root, isbn, path)
        
        if result is None:
            print("Not found")
        else:
            print(f"Found: {result.isbn} {result.title}")
            print(f"Path: {', '.join(map(str, path))}")
    
    def _search(self, node, isbn):
        """
        جست‌وجوی ساده کتاب بدون ذخیره مسیر
        
        ورودی:
            node (TreeNode): گره فعلی
            isbn (int): شناسه کتاب
        
        خروجی:
            TreeNode یا None
        """
        # اگر به گره خالی رسیدیم، کتاب یافت نشد
        if node is None:
            return None
        
        # اگر کتاب پیدا شد
        if node.isbn == isbn:
            return node
        
        # جست‌وجو در زیردرخت چپ یا راست
        if isbn < node.isbn:
            return self._search(node.left, isbn)
        else:
            return self._search(node.right, isbn)
    
    def _search_with_path(self, node, isbn, path):
        """
        جست‌وجوی کتاب با ذخیره مسیر
        
        ورودی:
            node (TreeNode): گره فعلی
            isbn (int): شناسه کتاب
            path (list): لیست مسیر پیمایش
        
        خروجی:
            TreeNode یا None
        """
        # اگر به گره خالی رسیدیم، کتاب یافت نشد
        if node is None:
            return None
        
        # افزودن گره فعلی به مسیر
        path.append(node.isbn)
        
        # اگر کتاب پیدا شد
        if node.isbn == isbn:
            return node
        
        # جست‌وجو در زیردرخت چپ یا راست
        if isbn < node.isbn:
            return self._search_with_path(node.left, isbn, path)
        else:
            return self._search_with_path(node.right, isbn, path)
    
    def remove(self, isbn):
        """
        حذف کتاب از درخت
        
        ورودی:
            isbn (int): شناسه کتاب مورد نظر برای حذف
        """
        # جست‌وجوی کتاب برای بررسی وجود
        book = self._search(self.root, isbn)
        
        if book is None:
            print("Book not found")
            return
        
        # ذخیره اطلاعات کتاب قبل از حذف
        title = book.title
        
        # حذف کتاب از درخت
        self.root = self._remove_recursive(self.root, isbn)
        print(f"Book {isbn} {title} removed")
    
    def _remove_recursive(self, node, isbn):
        """
        حذف بازگشتی کتاب از درخت
        
        ورودی:
            node (TreeNode): گره فعلی
            isbn (int): شناسه کتاب
        
        خروجی:
            TreeNode: ریشه زیردرخت پس از حذف
        """
        # اگر به گره خالی رسیدیم
        if node is None:
            return None
        
        # پیدا کردن گره مورد نظر
        if isbn < node.isbn:
            node.left = self._remove_recursive(node.left, isbn)
        elif isbn > node.isbn:
            node.right = self._remove_recursive(node.right, isbn)
        else:
            # گره مورد نظر پیدا شد - سه حالت حذف
            
            # حالت 1: گره بدون فرزند (برگ)
            if node.left is None and node.right is None:
                return None
            
            # حالت 2: گره با یک فرزند (فقط فرزند راست)
            if node.left is None:
                return node.right
            
            # حالت 2: گره با یک فرزند (فقط فرزند چپ)
            if node.right is None:
                return node.left
            
            # حالت 3: گره با دو فرزند
            # پیدا کردن کوچک‌ترین مقدار در زیردرخت راست (جانشین)
            successor = self._find_min(node.right)
            
            # جایگزینی مقادیر گره با جانشین
            node.isbn = successor.isbn
            node.title = successor.title
            
            # حذف جانشین از زیردرخت راست
            node.right = self._remove_recursive(node.right, successor.isbn)
        
        return node
    
    def _find_min(self, node):
        """
        پیدا کردن کوچک‌ترین گره در زیردرخت
        
        ورودی:
            node (TreeNode): ریشه زیردرخت
        
        خروجی:
            TreeNode: کوچک‌ترین گره
        """
        # حرکت به سمت چپ تا رسیدن به آخرین گره چپ
        current = node
        while current.left is not None:
            current = current.left
        return current
    
    def show(self):
        """
        نمایش تمام کتاب‌ها به ترتیب صعودی ISBN
        """
        # بررسی خالی بودن درخت
        if self.root is None:
            print("No books in library")
            return
        
        # جمع‌آوری کتاب‌ها به ترتیب صعودی (پیمایش Inorder)
        books = []
        self._inorder_traversal(self.root, books)
        
        # نمایش کتاب‌ها
        print("Books:")
        for isbn, title in books:
            print(f"{isbn} {title}")
    
    def _inorder_traversal(self, node, books):
        """
        پیمایش میان‌وندی درخت برای جمع‌آوری کتاب‌ها به ترتیب صعودی
        
        ورودی:
            node (TreeNode): گره فعلی
            books (list): لیست کتاب‌ها
        """
        if node is None:
            return
        
        # پیمایش زیردرخت چپ
        self._inorder_traversal(node.left, books)
        
        # افزودن گره فعلی
        books.append((node.isbn, node.title))
        
        # پیمایش زیردرخت راست
        self._inorder_traversal(node.right, books)


def main():
    """
    تابع اصلی برنامه - دریافت دستورات و اجرای عملیات‌ها
    """
    # ایجاد درخت جست‌وجوی دودویی
    library = BinarySearchTree()
    
    # حلقه اصلی برنامه که تا دریافت دستور exit ادامه می‌یابد
    while True:
        try:
            # دریافت دستور از کاربر
            command_line = input().strip()
            
            # بررسی خالی بودن دستور
            if not command_line:
                print("invalid input")
                continue
            
            # تجزیه دستور به قسمت‌های مختلف
            command_parts = command_line.split()
            
            # بررسی وجود دستور
            if len(command_parts) == 0:
                print("invalid input")
                continue
            
            # دریافت نام دستور
            command = command_parts[0]
            
            # پردازش دستور add
            if command == "add":
                # بررسی تعداد پارامترهای صحیح (باید 3 قسمت باشد)
                if len(command_parts) != 3:
                    print("invalid input")
                    continue
                
                try:
                    # دریافت ISBN و عنوان کتاب
                    isbn = int(command_parts[1])
                    title = command_parts[2]
                    
                    # بررسی مثبت بودن ISBN
                    if isbn <= 0:
                        print("invalid input")
                        continue
                    
                    # فراخوانی متد افزودن
                    library.add(isbn, title)
                
                except ValueError:
                    # اگر ISBN یک عدد صحیح نباشد
                    print("invalid input")
            
            # پردازش دستور find
            elif command == "find":
                # بررسی تعداد پارامترهای صحیح (باید 2 قسمت باشد)
                if len(command_parts) != 2:
                    print("invalid input")
                    continue
                
                try:
                    # دریافت ISBN برای جست‌وجو
                    isbn = int(command_parts[1])
                    
                    # فراخوانی متد جست‌وجو
                    library.find(isbn)
                
                except ValueError:
                    # اگر ISBN یک عدد صحیح نباشد
                    print("invalid input")
            
            # پردازش دستور remove
            elif command == "remove":
                # بررسی تعداد پارامترهای صحیح (باید 2 قسمت باشد)
                if len(command_parts) != 2:
                    print("invalid input")
                    continue
                
                try:
                    # دریافت ISBN برای حذف
                    isbn = int(command_parts[1])
                    
                    # فراخوانی متد حذف
                    library.remove(isbn)
                
                except ValueError:
                    # اگر ISBN یک عدد صحیح نباشد
                    print("invalid input")
            
            # پردازش دستور show
            elif command == "show":
                # بررسی عدم وجود پارامتر اضافی
                if len(command_parts) != 1:
                    print("invalid input")
                    continue
                
                # فراخوانی متد نمایش
                library.show()
            
            # پردازش دستور exit
            elif command == "exit":
                # خروج از برنامه
                break
            
            # دستور نامعتبر
            else:
                print("invalid input")
        
        except EOFError:
            # در صورت پایان ورودی، برنامه خاتمه می‌یابد
            break
        
        except Exception:
            # مدیریت خطاهای غیرمنتظره
            print("invalid input")


# نقطه شروع برنامه
if __name__ == "__main__":
    main()
