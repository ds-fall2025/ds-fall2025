class TrieNode:
    def __init__(self):
        self.children = {}
        self.is_end_of_word = False


class WordChainGame:
    def __init__(self):
        self.root = TrieNode()
        self.all_words = set()

    def insert_word(self, word):
        self.all_words.add(word)
        current = self.root
        for char in word:
            if char not in current.children:
                current.children[char] = TrieNode()
            current = current.children[char]
        current.is_end_of_word = True

    def get_words_starting_with(self, letter):
        # Since we have all_words, just filter and sort
        return sorted([word for word in self.all_words if word.startswith(letter)])

    def find_longest_chain(self, start_word):
        if start_word not in self.all_words:
            return [start_word]

        best_chain = [start_word]

        def backtrack(current_chain, used):
            nonlocal best_chain

            # Update best_chain if current is better
            if len(current_chain) > len(best_chain):
                best_chain = current_chain[:]
            elif len(current_chain) == len(best_chain) and current_chain < best_chain:
                best_chain = current_chain[:]

            last_char = current_chain[-1][-1]
            for word in self.get_words_starting_with(last_char):
                if word not in used:
                    used.add(word)
                    current_chain.append(word)
                    backtrack(current_chain, used)
                    current_chain.pop()
                    used.remove(word)

        backtrack([start_word], {start_word})
        return best_chain


def solve_word_chain_game():
    n = int(input().strip())
    game = WordChainGame()

    for _ in range(n):
        word = input().strip()
        game.insert_word(word)

    start_word = input().strip()
    chain = game.find_longest_chain(start_word)
    print(" ".join(chain))


if __name__ == "__main__":
    solve_word_chain_game()
