class BinaryTreeTraversal:
    """
    کلاس پیمایش درخت دودویی با نمایش آرایه‌ای
    
    این کلاس یک درخت دودویی را با استفاده از آرایه نمایش می‌دهد و
    سه نوع پیمایش اصلی (Preorder, Inorder, Postorder) را پیاده‌سازی می‌کند
    """
    
    def __init__(self, tree_array):
        """
        سازنده کلاس - مقداردهی اولیه درخت
        
        ورودی:
            tree_array (list): آرایه نمایش درخت دودویی
        """
        self.tree = tree_array  # آرایه ذخیره‌سازی درخت
    
    def inorder(self, index=0):
        """
        پیمایش میان‌وندی (Inorder) درخت دودویی
        ترتیب: چپ -> ریشه -> راست
        
        فرمول‌های اندیس‌دهی (اندیس از 0 شروع می‌شود):
        - فرزند چپ: 2 * index + 1
        - فرزند راست: 2 * index + 2
        
        ورودی:
            index (int): اندیس گره فعلی (پیش‌فرض: 0 برای ریشه)
        
        خروجی:
            list: لیست مقادیر گره‌ها به ترتیب Inorder
        """
        # شرط پایان بازگشت: اندیس خارج از محدوده یا گره None
        if index >= len(self.tree) or self.tree[index] is None:
            return []
        
        result = []
        
        # محاسبه اندیس فرزند چپ: 2 * index + 1
        left_index = 2 * index + 1
        
        # محاسبه اندیس فرزند راست: 2 * index + 2
        right_index = 2 * index + 2
        
        # پیمایش فرزند چپ (بازگشتی)
        result.extend(self.inorder(left_index))
        
        # افزودن گره فعلی (ریشه)
        result.append(self.tree[index])
        
        # پیمایش فرزند راست (بازگشتی)
        result.extend(self.inorder(right_index))
        
        return result
    
    def preorder(self, index=0):
        """
        پیمایش پیش‌وندی (Preorder) درخت دودویی
        ترتیب: ریشه -> چپ -> راست
        
        فرمول‌های اندیس‌دهی (اندیس از 0 شروع می‌شود):
        - فرزند چپ: 2 * index + 1
        - فرزند راست: 2 * index + 2
        
        ورودی:
            index (int): اندیس گره فعلی (پیش‌فرض: 0 برای ریشه)
        
        خروجی:
            list: لیست مقادیر گره‌ها به ترتیب Preorder
        """
        # شرط پایان بازگشت: اندیس خارج از محدوده یا گره None
        if index >= len(self.tree) or self.tree[index] is None:
            return []
        
        result = []
        
        # افزودن گره فعلی (ریشه) ابتدا
        result.append(self.tree[index])
        
        # محاسبه اندیس فرزند چپ: 2 * index + 1
        left_index = 2 * index + 1
        
        # محاسبه اندیس فرزند راست: 2 * index + 2
        right_index = 2 * index + 2
        
        # پیمایش فرزند چپ (بازگشتی)
        result.extend(self.preorder(left_index))
        
        # پیمایش فرزند راست (بازگشتی)
        result.extend(self.preorder(right_index))
        
        return result
    
    def postorder(self, index=0):
        """
        پیمایش پس‌وندی (Postorder) درخت دودویی
        ترتیب: چپ -> راست -> ریشه
        
        فرمول‌های اندیس‌دهی (اندیس از 0 شروع می‌شود):
        - فرزند چپ: 2 * index + 1
        - فرزند راست: 2 * index + 2
        
        ورودی:
            index (int): اندیس گره فعلی (پیش‌فرض: 0 برای ریشه)
        
        خروجی:
            list: لیست مقادیر گره‌ها به ترتیب Postorder
        """
        # شرط پایان بازگشت: اندیس خارج از محدوده یا گره None
        if index >= len(self.tree) or self.tree[index] is None:
            return []
        
        result = []
        
        # محاسبه اندیس فرزند چپ: 2 * index + 1
        left_index = 2 * index + 1
        
        # محاسبه اندیس فرزند راست: 2 * index + 2
        right_index = 2 * index + 2
        
        # پیمایش فرزند چپ (بازگشتی)
        result.extend(self.postorder(left_index))
        
        # پیمایش فرزند راست (بازگشتی)
        result.extend(self.postorder(right_index))
        
        # افزودن گره فعلی (ریشه) در انتها
        result.append(self.tree[index])
        
        return result


class InputValidator:
    """
    کلاس اعتبارسنجی ورودی
    
    این کلاس مسئول بررسی معتبر بودن فرمت و ساختار ورودی است
    """
    
    @staticmethod
    def is_valid_format(input_string):
        """
        بررسی معتبر بودن فرمت ورودی آرایه
        
        ورودی:
            input_string (str): رشته ورودی از کاربر
        
        خروجی:
            bool: True اگر فرمت معتبر باشد، False در غیر این صورت
        """
        # حذف فاصله‌های اضافی از ابتدا و انتها
        input_string = input_string.strip()
        
        # بررسی وجود براکت‌های باز و بسته
        if not input_string.startswith('[') or not input_string.endswith(']'):
            return False
        
        # حذف براکت‌ها
        content = input_string[1:-1].strip()
        
        # اگر محتوا خالی باشد، آرایه خالی نامعتبر است
        if not content:
            return False
        
        # تجزیه عناصر بر اساس کاما
        try:
            elements = content.split(',')
        except:
            return False
        
        # بررسی هر عنصر
        for element in elements:
            element = element.strip()
            
            # اگر عنصر خالی باشد
            if not element:
                return False
            
            # بررسی None
            if element == 'None':
                continue
            
            # بررسی حروف انگلیسی (یک کاراکتر یا بیشتر)
            if element.isalpha():
                continue
            
            # اگر عنصر نامعتبر بود
            return False
        
        return True
    
    @staticmethod
    def parse_array(input_string):
        """
        تبدیل رشته ورودی به لیست پایتون
        
        ورودی:
            input_string (str): رشته ورودی آرایه
        
        خروجی:
            list: لیست عناصر درخت
        """
        # حذف براکت‌ها
        content = input_string.strip()[1:-1].strip()
        
        # تجزیه عناصر
        elements = content.split(',')
        result = []
        
        for element in elements:
            element = element.strip()
            if element == 'None':
                result.append(None)
            else:
                result.append(element)
        
        return result
    
    @staticmethod
    def is_valid_tree_structure(tree):
        """
        بررسی معتبر بودن ساختار درخت دودویی
        
        شرایط نامعتبر:
        1. آرایه خالی
        2. ریشه None است
        3. تمام عناصر None هستند
        4. والد None است اما فرزندان غیرخالی دارد (ساختار غیرممکن)
        
        ورودی:
            tree (list): آرایه نمایش درخت
        
        خروجی:
            bool: True اگر ساختار معتبر باشد، False در غیر این صورت
        """
        # بررسی خالی بودن آرایه
        if len(tree) == 0:
            return False
        
        # بررسی None بودن ریشه
        if tree[0] is None:
            return False
        
        # بررسی تمام عناصر None بودن
        if all(element is None for element in tree):
            return False
        
        # بررسی ساختار درخت دودویی: اگر والد None است، فرزندان نباید مقدار داشته باشند
        for i in range(len(tree)):
            if tree[i] is None:
                # محاسبه اندیس فرزندان
                left_child_index = 2 * i + 1
                right_child_index = 2 * i + 2
                
                # بررسی وجود فرزند چپ غیرخالی
                if left_child_index < len(tree) and tree[left_child_index] is not None:
                    return False
                
                # بررسی وجود فرزند راست غیرخالی
                if right_child_index < len(tree) and tree[right_child_index] is not None:
                    return False
        
        return True


def format_output(result_list):
    """
    تبدیل لیست به فرمت خروجی بدون علامت نقل‌قول
    
    ورودی:
        result_list (list): لیست نتایج پیمایش
    
    خروجی:
        str: رشته فرمت شده بدون علامت نقل‌قول
    """
    # ایجاد رشته خروجی با جدا کردن عناصر با کاما و فاصله
    if len(result_list) == 0:
        return "[]"
    
    # تبدیل لیست به رشته بدون علامت نقل‌قول
    formatted = "[" + ", ".join(result_list) + "]"
    return formatted


def main():
    """
    تابع اصلی برنامه - دریافت آرایه و نمایش پیمایش‌های درخت
    """
    # حلقه اصلی برنامه برای دریافت ورودی معتبر
    while True:
        try:
            # دریافت ورودی از کاربر
            input_string = input().strip()
            
            # بررسی خالی بودن ورودی
            if not input_string:
                print("Invalid input")
                continue
            
            # بررسی معتبر بودن فرمت ورودی
            if not InputValidator.is_valid_format(input_string):
                print("Invalid input")
                continue
            
            # تبدیل رشته ورودی به آرایه
            tree_array = InputValidator.parse_array(input_string)
            
            # بررسی معتبر بودن ساختار درخت دودویی
            if not InputValidator.is_valid_tree_structure(tree_array):
                print("Invalid input")
                continue
            
            # ایجاد شیء درخت دودویی
            binary_tree = BinaryTreeTraversal(tree_array)
            
            # انجام پیمایش‌های مختلف
            inorder_result = binary_tree.inorder()
            preorder_result = binary_tree.preorder()
            postorder_result = binary_tree.postorder()
            
            # نمایش نتایج بدون علامت نقل‌قول
            print("In_Order: " + format_output(inorder_result))
            print("Pre_Order: " + format_output(preorder_result))
            print("Post_Order: " + format_output(postorder_result))
            
            # پایان برنامه پس از پردازش موفق
            break
        
        except EOFError:
            # در صورت پایان ورودی، برنامه خاتمه می‌یابد
            break
        
        except Exception:
            # مدیریت خطاهای غیرمنتظره
            print("Invalid input")


# نقطه شروع برنامه
if __name__ == "__main__":
    main()