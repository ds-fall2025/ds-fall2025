class TrieNode:
    def __init__(self):
        self.children = {}
        self.is_end_of_word = False


class SmartKeyboard:
    def __init__(self):
        self.root = TrieNode()

    def insert_word(self, word):
        current_node = self.root
        for char in word:
            if char not in current_node.children:
                current_node.children[char] = TrieNode()
            current_node = current_node.children[char]
        current_node.is_end_of_word = True

    def find_prefix_node(self, prefix):
        current_node = self.root
        for char in prefix:
            if char not in current_node.children:
                return None
            current_node = current_node.children[char]
        return current_node

    def collect_words_with_prefix(self, node, prefix, limit=5):
        words = []

        def dfs(current_node, current_word):
            if len(words) >= limit:
                return
            if current_node.is_end_of_word:
                words.append(current_word)
            for char in sorted(current_node.children.keys()):
                if len(words) >= limit:
                    break
                dfs(current_node.children[char], current_word + char)

        dfs(node, prefix)
        return words

    def autocomplete(self, prefix, limit=5):
        prefix_node = self.find_prefix_node(prefix)
        if prefix_node is None:
            return []
        return self.collect_words_with_prefix(prefix_node, prefix, limit)

    def word_exists(self, word):
        current_node = self.root
        for char in word:
            if char not in current_node.children:
                return False
            current_node = current_node.children[char]
        return current_node.is_end_of_word

    def autocorrect(self, word):
        # Word already exists
        if self.word_exists(word):
            return "already_correct"

        corrections = []
        alphabet = 'abcdefghijklmnopqrstuvwxyz'

        # Substitution
        for i in range(len(word)):
            for ch in alphabet:
                if ch == word[i]:
                    continue
                new_word = word[:i] + ch + word[i+1:]
                if self.word_exists(new_word):
                    corrections.append(new_word)

        # Insertion
        for i in range(len(word) + 1):
            for ch in alphabet:
                new_word = word[:i] + ch + word[i:]
                if self.word_exists(new_word):
                    corrections.append(new_word)

        # Deletion
        for i in range(len(word)):
            new_word = word[:i] + word[i+1:]
            if self.word_exists(new_word):
                corrections.append(new_word)

        if corrections:
            return sorted(corrections)[0]
        return None


def solve_smart_keyboard():
    n = int(input().strip())
    keyboard = SmartKeyboard()

    for _ in range(n):
        word = input().strip()
        keyboard.insert_word(word)

    query = input().strip().split(' ', 1)
    operation = query[0]
    text = query[1] if len(query) > 1 else ""

    if operation == "autocomplete":
        suggestions = keyboard.autocomplete(text, limit=5)
        if suggestions:
            for s in suggestions:
                print(s)
        else:
            print("No suggestions found")

    elif operation == "autocorrect":
        correction = keyboard.autocorrect(text)
        if correction == "already_correct":
            print("Word is already correct")
        elif correction:
            print(correction)
        else:
            print("No correction found")


if __name__ == "__main__":
    solve_smart_keyboard()
