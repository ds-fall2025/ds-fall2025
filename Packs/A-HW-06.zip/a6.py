class TrieNode:
    def __init__(self):
        self.children = {}
        self.is_end_of_sequence = False


class DNATrie:
    def __init__(self):
        self.root = TrieNode()

    def insert(self, sequence):
        current_node = self.root
        for nucleotide in sequence:
            if nucleotide not in current_node.children:
                current_node.children[nucleotide] = TrieNode()
            current_node = current_node.children[nucleotide]
        current_node.is_end_of_sequence = True

    def search_exact(self, sequence):
        current_node = self.root
        for nucleotide in sequence:
            if nucleotide not in current_node.children:
                return False
            current_node = current_node.children[nucleotide]
        return current_node.is_end_of_sequence

    def search_with_one_mutation(self, sequence):
        for position in range(len(sequence)):
            for new_nucleotide in ['A', 'T', 'C', 'G']:
                if new_nucleotide == sequence[position]:
                    continue
                mutated_sequence = sequence[:position] + \
                    new_nucleotide + sequence[position + 1:]
                if self.search_exact(mutated_sequence):
                    return True
        return False


def solve_dna_matching():
    n = int(input())
    dna_trie = DNATrie()
    for _ in range(n):
        sequence = input().strip()
        dna_trie.insert(sequence)

    query_sequence = input().strip()

    if dna_trie.search_exact(query_sequence):
        print("Exact match found")
    elif dna_trie.search_with_one_mutation(query_sequence):
        print("Match with one mutation found")
    else:
        print("No match found")


if __name__ == "__main__":
    solve_dna_matching()
