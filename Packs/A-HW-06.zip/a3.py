class Node:
    """
    کلاس گره (Node) برای نمایش هر طلسم در لیست پیوندی دوطرفه دایره‌ای
    
    هر گره شامل اطلاعات یک طلسم و اشاره‌گرهای به گره‌های قبل و بعد است
    """
    
    def __init__(self, spell_id, spell_name):
        """
        سازنده کلاس Node - ایجاد یک گره جدید برای طلسم
        
        ورودی:
            spell_id (int): شناسه یکتای طلسم
            spell_name (str): نام طلسم
        """
        self.id = spell_id  # شناسه طلسم
        self.spell_name = spell_name  # نام طلسم
        self.prev = None  # اشاره‌گر به گره قبلی
        self.next = None  # اشاره‌گر به گره بعدی


class CircularDoublyLinkedList:
    """
    کلاس لیست پیوندی دوطرفه دایره‌ای برای مدیریت زنجیره طلسم‌ها
    
    در این ساختار دایره‌ای:
    - آخرین گره (tail) به اولین گره (head) در next اشاره دارد
    - اولین گره (head) به آخرین گره (tail) در prev اشاره دارد
    - عملیات درج، حذف و جست‌وجو به صورت دایره‌ای انجام می‌شود
    """
    
    def __init__(self):
        """
        سازنده کلاس - مقداردهی اولیه لیست خالی
        """
        self.head = None  # اشاره‌گر به اولین گره لیست
    
    def insert(self, spell_id, spell_name):
        """
        درج طلسم جدید در موقعیت مناسب بر اساس ID به ترتیب صعودی
        
        ورودی:
            spell_id (int): شناسه طلسم
            spell_name (str): نام طلسم
        
        خروجی:
            پیام موفقیت یا خطا
        """
        # بررسی تکراری بودن ID یا spell_name
        if self.head is not None:
            current = self.head
            # پیمایش دایره‌ای کامل لیست
            while True:
                # بررسی تکراری بودن ID یا نام طلسم
                if current.id == spell_id or current.spell_name == spell_name:
                    print("Duplicate id or spell name")
                    return
                
                current = current.next
                # اگر به head برگشتیم، پیمایش تمام شد
                if current == self.head:
                    break
        
        # ایجاد گره جدید برای طلسم
        new_node = Node(spell_id, spell_name)
        
        # حالت 1: لیست خالی است - ایجاد دایره تک عنصری
        if self.head is None:
            self.head = new_node
            # گره به خودش در هر دو جهت اشاره می‌کند
            new_node.next = new_node
            new_node.prev = new_node
            print(f"Spell {spell_name} with id {spell_id} successfully added")
            return
        
        # پیدا کردن موقعیت مناسب برای درج (ترتیب صعودی)
        current = self.head
        
        # حالت 2: درج در ابتدای لیست (قبل از head)
        if spell_id < self.head.id:
            # پیدا کردن آخرین گره (tail)
            tail = self.head.prev
            
            # اتصال گره جدید
            new_node.next = self.head
            new_node.prev = tail
            tail.next = new_node
            self.head.prev = new_node
            
            # تغییر head
            self.head = new_node
            print(f"Spell {spell_name} with id {spell_id} successfully added")
            return
        
        # حالت 3: درج در وسط یا انتهای لیست
        # پیمایش تا یافتن موقعیت مناسب
        while True:
            next_node = current.next
            
            # اگر به انتهای لیست رسیدیم یا ID مناسب پیدا کردیم
            if next_node == self.head or spell_id < next_node.id:
                # درج بعد از current
                new_node.next = next_node
                new_node.prev = current
                current.next = new_node
                next_node.prev = new_node
                
                print(f"Spell {spell_name} with id {spell_id} successfully added")
                return
            
            current = next_node
    
    def remove(self, spell_id):
        """
        حذف طلسم با شناسه مشخص از زنجیره دایره‌ای
        
        ورودی:
            spell_id (int): شناسه طلسم مورد نظر برای حذف
        
        خروجی:
            پیام موفقیت یا خطا
        """
        # بررسی خالی بودن لیست
        if self.head is None:
            print("empty")
            return
        
        # جست‌وجوی گره با ID مشخص شده (پیمایش دایره‌ای)
        current = self.head
        
        # پیمایش دایره‌ای کامل لیست
        while True:
            if current.id == spell_id:
                # گره مورد نظر پیدا شد
                spell_name = current.spell_name
                
                # حالت 1: تنها یک گره در لیست وجود دارد
                if current.next == current:
                    self.head = None
                else:
                    # حالت 2: حذف گره (اتصال گره‌های قبل و بعد به هم)
                    current.prev.next = current.next
                    current.next.prev = current.prev
                    
                    # اگر گره حذف شده head بود، head را تغییر می‌دهیم
                    if current == self.head:
                        self.head = current.next
                
                print(f"Spell {spell_name} removed successfully")
                return
            
            current = current.next
            
            # اگر به head برگشتیم، پیمایش تمام شد
            if current == self.head:
                break
        
        # اگر ID پیدا نشد
        print("Invalid id")
    
    def find(self, spell_name):
        """
        جست‌وجوی طلسم با نام مشخص در زنجیره دایره‌ای
        
        ورودی:
            spell_name (str): نام طلسم مورد جست‌وجو
        
        خروجی:
            True اگر طلسم یافت شود، False در غیر این صورت
        """
        # بررسی خالی بودن لیست
        if self.head is None:
            print("False")
            return
        
        # پیمایش دایره‌ای تمام گره‌های لیست
        current = self.head
        
        while True:
            if current.spell_name == spell_name:
                print("True")
                return
            
            current = current.next
            
            # اگر به head برگشتیم، پیمایش تمام شد
            if current == self.head:
                break
        
        # اگر طلسم پیدا نشد
        print("False")
    
    def display(self):
        """
        نمایش تمام طلسم‌های موجود در زنجیره دایره‌ای
        با فرمت شامل prev و next
        """
        # بررسی خالی بودن لیست
        if self.head is None:
            print("No spells to display")
            return
        
        # پیمایش دایره‌ای و نمایش تمام گره‌ها
        current = self.head
        
        while True:
            # در ساختار دایره‌ای، prev و next همیشه به گره‌های دیگر اشاره دارند
            prev_value = str(current.prev.id)
            next_value = str(current.next.id)
            
            # چاپ با فرمت مشخص شده
            print(f"Spell: {current.spell_name}, id: {current.id}, prev: {prev_value}, next: {next_value}")
            
            current = current.next
            
            # اگر به head برگشتیم، پیمایش تمام شد
            if current == self.head:
                break


def main():
    """
    تابع اصلی برنامه - دریافت دستورات و اجرای عملیات‌ها
    """
    # ایجاد لیست پیوندی دوطرفه دایره‌ای برای نگهداری طلسم‌ها
    spell_chain = CircularDoublyLinkedList()
    
    # حلقه اصلی برنامه که تا دریافت دستور EXIT ادامه می‌یابد
    while True:
        try:
            # دریافت دستور از کاربر
            command_line = input().strip()
            
            # بررسی خالی بودن دستور
            if not command_line:
                print("Invalid input")
                continue
            
            # تجزیه دستور به قسمت‌های مختلف
            command_parts = command_line.split()
            
            # بررسی وجود دستور
            if len(command_parts) == 0:
                print("Invalid input")
                continue
            
            # دریافت دستور
            command = command_parts[0]
            
            #  بررسی دقیق دستور EXIT (فقط با حروف بزرگ)
            if command == "EXIT":
                # خروج از برنامه - فقط با حروف بزرگ
                break
            
            #  بررسی دقیق دستور INSERT (فقط با حروف بزرگ)
            elif command == "INSERT":
                # بررسی تعداد پارامترهای صحیح (باید 3 قسمت باشد)
                if len(command_parts) != 3:
                    print("Invalid input")
                    continue
                
                try:
                    # دریافت ID و نام طلسم
                    spell_id = int(command_parts[1])
                    spell_name = command_parts[2]
                    
                    # فراخوانی متد درج
                    spell_chain.insert(spell_id, spell_name)
                
                except ValueError:
                    # اگر ID یک عدد صحیح نباشد
                    print("Invalid input")
            
            #  بررسی دقیق دستور REMOVE (فقط با حروف بزرگ)
            elif command == "REMOVE":
                # بررسی تعداد پارامترهای صحیح (باید 2 قسمت باشد)
                if len(command_parts) != 2:
                    print("Invalid input")
                    continue
                
                try:
                    # دریافت ID طلسم برای حذف
                    spell_id = int(command_parts[1])
                    
                    # فراخوانی متد حذف
                    spell_chain.remove(spell_id)
                
                except ValueError:
                    # اگر ID یک عدد صحیح نباشد
                    print("Invalid input")
            
            #   بررسی دقیق دستور FIND (فقط با حروف بزرگ)
            elif command == "FIND":
                # بررسی تعداد پارامترهای صحیح (باید 2 قسمت باشد)
                if len(command_parts) != 2:
                    print("Invalid input")
                    continue
                
                # دریافت نام طلسم برای جست‌وجو
                spell_name = command_parts[1]
                
                # فراخوانی متد جست‌وجو
                spell_chain.find(spell_name)
            
            #  بررسی دقیق دستور DISPLAY (فقط با حروف بزرگ)
            elif command == "DISPLAY":
                # بررسی عدم وجود پارامتر اضافی
                if len(command_parts) != 1:
                    print("Invalid input")
                    continue
                
                # فراخوانی متد نمایش
                spell_chain.display()
            
            #  هر دستور دیگری (حتی با حروف کوچک) نامعتبر است
            else:
                print("Invalid input")
        
        except EOFError:
            # در صورت پایان ورودی، برنامه خاتمه می‌یابد
            break
        
        except Exception:
            # مدیریت خطاهای غیرمنتظره
            print("Invalid input")


# نقطه شروع برنامه
if __name__ == "__main__":
    main()