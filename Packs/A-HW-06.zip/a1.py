class Stack:
    """
    کلاس پیاده‌سازی ساختار داده پشته (Stack)
    
    این کلاس یک پشته با عملیات‌های استاندارد LIFO را پیاده‌سازی می‌کند
    """
    
    def __init__(self):
        """
        سازنده کلاس - مقداردهی اولیه پشته
        """
        self.items = []  # لیست برای ذخیره عناصر پشته
    
    def push(self, item):
        """
        اضافه کردن یک عنصر به بالای پشته
        
        ورودی:
            item: عنصر برای اضافه کردن
        """
        self.items.append(item)  # افزودن عنصر به انتهای لیست (بالای پشته)
    
    def pop(self):
        """
        حذف و برگرداندن عنصر بالای پشته
        
        خروجی:
            عنصر حذف شده از بالای پشته
        """
        if not self.is_empty():
            return self.items.pop()  # حذف و برگرداندن آخرین عنصر (بالای پشته)
        return None
    
    def peek(self):
        """
        مشاهده عنصر بالای پشته بدون حذف
        
        خروجی:
            عنصر بالای پشته
        """
        if not self.is_empty():
            return self.items[-1]  # برگرداندن آخرین عنصر بدون حذف
        return None
    
    def is_empty(self):
        """
        بررسی خالی بودن پشته
        
        خروجی:
            True اگر پشته خالی باشد، در غیر این صورت False
        """
        return len(self.items) == 0
    
    def size(self):
        """
        برگرداندن تعداد عناصر پشته
        
        خروجی:
            تعداد عناصر موجود در پشته
        """
        return len(self.items)


class StackMasterCalculator:
    """
    کلاس شبیه‌سازی ماشین حساب باستانی کالکوتک (Calcutech StackMaster)
    
    این کلاس عملیات جمع دو عدد صحیح را با استفاده از سه پشته
    و عملیات push و pop انجام می‌دهد
    """
    
    def __init__(self):
        """
        سازنده کلاس - مقداردهی اولیه پشته‌ها
        """
        self.stack1 = Stack()  # پشته برای ذخیره رقم‌های عدد اول
        self.stack2 = Stack()  # پشته برای ذخیره رقم‌های عدد دوم
        self.result_stack = Stack()  # پشته برای ذخیره نتیجه جمع
    
    def is_valid_digit(self, element):
        """
        بررسی معتبر بودن یک رقم
        
        ورودی:
            element: عنصر برای بررسی
        
        خروجی:
            True اگر عنصر یک رقم عددی معتبر باشد (0-9)
        """
        # بررسی اینکه عنصر یک عدد صحیح باشد و در بازه 0 تا 9 قرار گیرد
        return isinstance(element, int) and 0 <= element <= 9
    
    def validate_input(self, input_array):
        """
        اعتبارسنجی آرایه ورودی
        
        ورودی:
            input_array: آرایه ورودی شامل رقم‌ها و علامت '+'
        
        خروجی:
            tuple: (وضعیت معتبر بودن, پیام خطا)
        """
        # بررسی خالی بودن آرایه
        if not input_array or len(input_array) == 0:
            return False, "Error: Invalid Input"
        
        # بررسی شروع آرایه با علامت '+' (ترتیب اشتباه)
        if input_array[0] == '+':
            return False, "Error: Invalid Sequence"
        
        # شمارش تعداد علامت '+' (باید دقیقاً یکی باشد)
        plus_count = input_array.count('+')
        if plus_count != 1:
            return False, "Error: Invalid Sequence"
        
        # بررسی اینکه '+' در انتهای آرایه نباشد
        if input_array[-1] == '+':
            return False, "Error: Invalid Sequence"
        
        # بررسی معتبر بودن تمام عناصر (فقط رقم یا '+')
        for element in input_array:
            if element != '+' and not self.is_valid_digit(element):
                return False, "Error: Invalid Character"
        
        return True, None
    
    def load_stacks(self, input_array):
        """
        بارگذاری رقم‌ها از آرایه ورودی به دو پشته
        
        ورودی:
            input_array: آرایه ورودی معتبر
        """
        # پیدا کردن موقعیت علامت '+'
        plus_index = input_array.index('+')
        
        # بارگذاری رقم‌های عدد اول به پشته اول
        # رقم‌ها به ترتیب از چپ به راست push می‌شوند
        for i in range(plus_index):
            self.stack1.push(input_array[i])
        
        # بارگذاری رقم‌های عدد دوم به پشته دوم
        # رقم‌ها به ترتیب از چپ به راست push می‌شوند
        for i in range(plus_index + 1, len(input_array)):
            self.stack2.push(input_array[i])
    
    def stack_based_addition(self):
        """
        انجام عملیات جمع پشته‌ای با استفاده از عملیات push و pop
        
        این تابع رقم‌ها را از بالای دو پشته (آخرین رقم‌ها) با هم جمع می‌کند
        و نتیجه را در پشته سوم ذخیره می‌کند
        """
        # متغیر کری (عدد نگه‌داری) - در ابتدا صفر است
        carry = 0
        
        # ادامه جمع تا زمانی که هر دو پشته و کری پردازش شوند
        while not self.stack1.is_empty() or not self.stack2.is_empty() or carry > 0:
            # گرفتن رقم از بالای پشته اول (آخرین رقم)
            # اگر پشته خالی باشد، از صفر استفاده می‌کنیم
            digit1 = self.stack1.pop() if not self.stack1.is_empty() else 0
            
            # گرفتن رقم از بالای پشته دوم (آخرین رقم)
            # اگر پشته خالی باشد، از صفر استفاده می‌کنیم
            digit2 = self.stack2.pop() if not self.stack2.is_empty() else 0
            
            # جمع دو رقم به اضافه کری قبلی
            total = digit1 + digit2 + carry
            
            # محاسبه رقم یکان (باقیمانده تقسیم بر 10)
            current_digit = total % 10
            
            # محاسبه کری جدید (خارج قسمت تقسیم بر 10)
            carry = total // 10
            
            # اضافه کردن رقم به بالای پشته نتیجه
            self.result_stack.push(current_digit)
    
    def get_result_as_array(self):
        """
        تبدیل پشته نتیجه به آرایه
        
        خروجی:
            لیست رقم‌های نتیجه به ترتیب صحیح
        """
        # آرایه برای ذخیره نتیجه نهایی
        result_array = []
        
        # خالی کردن پشته نتیجه و اضافه کردن به آرایه
        # چون رقم‌ها در پشته به صورت معکوس هستند، با pop کردن ترتیب درست می‌شوند
        while not self.result_stack.is_empty():
            result_array.append(self.result_stack.pop())
        
        return result_array
    
    def calculate(self, input_array):
        """
        تابع اصلی محاسبه - انجام جمع با استفاده از پشته‌ها
        
        ورودی:
            input_array: آرایه ورودی شامل رقم‌ها و علامت '+'
        
        خروجی:
            لیست رقم‌های نتیجه یا پیام خطا
        """
        try:
            # مرحله 1: اعتبارسنجی ورودی
            is_valid, error_message = self.validate_input(input_array)
            if not is_valid:
                return error_message
            
            # مرحله 2: بارگذاری رقم‌ها به پشته‌های اول و دوم
            self.load_stacks(input_array)
            
            # بررسی خالی نبودن پشته‌ها
            if self.stack1.is_empty() or self.stack2.is_empty():
                return "Error: Invalid Input"
            
            # مرحله 3: انجام جمع پشته‌ای
            self.stack_based_addition()
            
            # مرحله 4: تبدیل پشته نتیجه به آرایه
            result = self.get_result_as_array()
            
            return result
        
        except Exception as e:
            # مدیریت خطاهای غیرمنتظره
            return "Error: Calculation Error"


def main():
    """
    تابع اصلی برنامه - دریافت ورودی به صورت لیست و نمایش خروجی
    """
    try:
        # دریافت ورودی از کاربر به صورت رشته
        user_input = input().strip()
        
        # بررسی خالی بودن ورودی
        if not user_input:
            print("Error: Invalid Input")
            return
        
        # تلاش برای تبدیل ورودی به لیست
        # ورودی باید به فرمت [1, 2, 3, '+', 4, 5, 6] باشد
        input_array = eval(user_input)
        
        # بررسی اینکه نتیجه یک لیست باشد
        if not isinstance(input_array, list):
            print("Error: Invalid Input")
            return
        
        # ایجاد نمونه از ماشین حساب
        calculator = StackMasterCalculator()
        
        # انجام محاسبه
        result = calculator.calculate(input_array)
        
        # نمایش نتیجه
        print(result)
    
    except (SyntaxError, NameError, ValueError, TypeError):
        # خطا در پردازش ورودی
        print("Error: Invalid Input")
    except EOFError:
        # پایان ورودی
        pass
    except Exception as e:
        # سایر خطاها
        print("Error: Invalid Input")


# نقطه شروع برنامه
if __name__ == "__main__":
    main()
