class CircularQueue:
    """
    کلاس مدیریت صف چرخشی برای مدیریت رکوردهای زمانی ماشین‌ها
    
    این کلاس یک صف چرخشی (Circular Queue) را پیاده‌سازی می‌کند که
    رکوردهای زمانی ماشین‌ها را به ترتیب صعودی (از کوچک به بزرگ) نگه می‌دارد
    """
    
    def __init__(self, capacity):
        """
        سازنده کلاس - مقداردهی اولیه صف
        
        ورودی:
            capacity: ظرفیت صف (تعداد حداکثر رکوردها)
        """
        self.capacity = capacity  # ظرفیت کل صف
        self.queue = [None] * capacity  # آرایه ذخیره‌سازی صف
        self.front_index = -1  # اشاره‌گر به ابتدای صف
        self.rear_index = -1  # اشاره‌گر به انتهای صف
        self.size = 0  # تعداد عناصر فعلی در صف
    
    def is_empty(self):
        """
        بررسی خالی بودن صف
        
        خروجی:
            True اگر صف خالی باشد، در غیر این صورت False
        """
        return self.size == 0
    
    def is_full(self):
        """
        بررسی پر بودن صف
        
        خروجی:
            True اگر صف پر باشد، در غیر این صورت False
        """
        return self.size == self.capacity
    
    def insert(self, time):
        """
        درج یک رکورد زمانی جدید در صف
        
        ورودی:
            time: زمان رکورد جدید (عدد اعشاری)
        
        قوانین درج:
            - قبل از درج، تمام رکوردهایی که زمانشان بیشتر از time است
              باید از انتهای صف حذف شوند
            - سپس time به انتهای صف اضافه می‌شود
        """
        #   بررسی مثبت بودن زمان رکورد
        if time <= 0:
            print("Invalid input")
            return
        
        # بررسی پر بودن صف قبل از حذف عناصر بزرگتر
        # اگر صف پر باشد و هیچ عنصری قابل حذف نباشد، نمی‌توانیم اضافه کنیم
        
        # حذف تمام عناصری که زمانشان بیشتر از time است (از انتهای صف)
        while not self.is_empty() and self.queue[self.rear_index] > time:
            # حذف عنصر از انتهای صف
            self.queue[self.rear_index] = None
            
            # اگر فقط یک عنصر بود، صف خالی می‌شود
            if self.front_index == self.rear_index:
                self.front_index = -1
                self.rear_index = -1
            else:
                # انتقال rear به عقب به صورت چرخشی
                self.rear_index = (self.rear_index - 1 + self.capacity) % self.capacity
            
            self.size -= 1
        
        # بررسی پر بودن صف بعد از حذف عناصر
        if self.is_full():
            print("Queue is full")
            return
        
        # اضافه کردن عنصر جدید به انتهای صف
        if self.is_empty():
            self.front_index = 0
            self.rear_index = 0
        else:
            # انتقال rear به جلو به صورت چرخشی
            self.rear_index = (self.rear_index + 1) % self.capacity
        
        self.queue[self.rear_index] = time
        self.size += 1
        
        # نمایش وضعیت فعلی صف
        self.display()
    
    def delete(self):
        """
        حذف سریع‌ترین رکورد (کوچک‌ترین زمان) از ابتدای صف
        """
        # بررسی خالی بودن صف
        if self.is_empty():
            print("Queue is empty")
            return
        
        # حذف عنصر از ابتدای صف
        removed_time = self.queue[self.front_index]
        self.queue[self.front_index] = None
        
        # اگر فقط یک عنصر در صف بود، صف خالی می‌شود
        if self.front_index == self.rear_index:
            self.front_index = -1
            self.rear_index = -1
        else:
            # انتقال front به جلو به صورت چرخشی
            self.front_index = (self.front_index + 1) % self.capacity
        
        self.size -= 1
        
        # چاپ پیام حذف با فرمت مشخص شده
        print(f"Car sent to starting line: [{removed_time}]")
        
        # نمایش وضعیت فعلی صف
        self.display()
    
    def display(self):
        """
        نمایش وضعیت فعلی صف از front تا rear به صورت چرخشی
        """
        # اگر صف خالی است
        if self.is_empty():
            print("QUEUE: []")
            return
        
        # ساخت لیست عناصر صف برای نمایش
        elements = []
        i = self.front_index
        for _ in range(self.size):
            elements.append(str(self.queue[i]))
            i = (i + 1) % self.capacity
        
        # چاپ عناصر با فرمت "QUEUE: [elem1, elem2, ...]"
        print("QUEUE: [" + ", ".join(elements) + "]")


def main():
    """
    تابع اصلی برنامه - دریافت ورودی و اجرای عملیات‌ها
    """
    # متغیر برای نگهداری نمونه صف (در ابتدا None است)
    race_queue = None
    
    # حلقه اصلی برنامه که تا دریافت دستور EXIT ادامه می‌یابد
    while True:
        try:
            # دریافت ورودی از کاربر
            command_line = input().strip()
            
            # بررسی خالی بودن ورودی
            if not command_line:
                print("Invalid input")
                continue
            
            # تجزیه دستور به قسمت‌های مختلف
            command_parts = command_line.split()
            
            # بررسی وجود دستور
            if len(command_parts) == 0:
                print("Invalid input")
                continue
            
            # دریافت نام دستور (حروف بزرگ)
            command = command_parts[0].upper()
            
            # اگر صف هنوز ایجاد نشده است (ورودی اول باید ظرفیت باشد)
            if race_queue is None:
                # تلاش برای تبدیل ورودی اول به ظرفیت صف
                try:
                    capacity = int(command_parts[0])
                    
                    # بررسی معتبر بودن ظرفیت
                    if capacity <= 0:
                        print("Invalid input")
                        continue
                    
                    # ایجاد صف با ظرفیت مشخص شده
                    race_queue = CircularQueue(capacity)
                    continue
                    
                except ValueError:
                    # اگر ورودی اول عدد نباشد، خطا چاپ شود ولی برنامه ادامه یابد
                    print("Invalid input")
                    continue
            
            # پردازش دستورات مختلف پس از ایجاد صف
            if command == "INSERT":
                # بررسی وجود پارامتر زمان
                if len(command_parts) != 2:
                    print("Invalid input")
                    continue
                
                try:
                    # دریافت زمان از دستور و تبدیل به عدد اعشاری
                    time = float(command_parts[1])
                    
                    race_queue.insert(time)
                except ValueError:
                    # اگر زمان یک عدد معتبر نباشد
                    print("Invalid input")
            
            elif command == "DELETE":
                # بررسی اینکه دستور DELETE پارامتر اضافی نداشته باشد
                if len(command_parts) != 1:
                    print("Invalid input")
                    continue
                
                race_queue.delete()
            
            elif command == "DISPLAY":
                # بررسی اینکه دستور DISPLAY پارامتر اضافی نداشته باشد
                if len(command_parts) != 1:
                    print("Invalid input")
                    continue
                
                race_queue.display()
            
            elif command == "EXIT":
                # خروج از برنامه - تنها راه پایان برنامه
                break
            
            else:
                # دستور نامعتبر
                print("Invalid input")
        
        except EOFError:
            # در صورت پایان ورودی، برنامه خاتمه می‌یابد
            break
        
        except Exception as e:
            # مدیریت خطاهای غیرمنتظره
            print("Invalid input")


# نقطه شروع برنامه
if __name__ == "__main__":
    main()