class TreeNode:
    """
    کلاس گره درخت برای نمایش هر فرد در شجره‌نامه
    
    هر گره شامل اطلاعات یک فرد و اشاره‌گرهای به والد، اولین فرزند و خواهر/برادر بعدی است
    این ساختار از نمایش left_child / right_sibling استفاده می‌کند
    """
    
    def __init__(self, name, age):
        """
        سازنده کلاس TreeNode - ایجاد یک گره جدید برای فرد
        
        ورودی:
            name (str): نام فرد (یکتا)
            age (int): سن فرد
        """
        self.name = name  # نام فرد
        self.age = age  # سن فرد
        self.parent = None  # اشاره‌گر به والد
        self.left_child = None  # اشاره‌گر به اولین فرزند
        self.right_sibling = None  # اشاره‌گر به برادر/خواهر بعدی


class FamilyTree:
    """
    کلاس درخت خانوادگی برای مدیریت شجره‌نامه
    
    این کلاس از ساختار درخت n-ary با نمایش left_child/right_sibling استفاده می‌کند
    """
    
    def __init__(self):
        """
        سازنده کلاس - مقداردهی اولیه درخت خالی
        """
        self.root = None  # اشاره‌گر به ریشه درخت
    
    def find_node(self, name, current=None):
        """
        جست‌وجوی گره با نام مشخص در کل درخت (به صورت بازگشتی)
        
        ورودی:
            name (str): نام فرد مورد جست‌وجو
            current (TreeNode): گره فعلی برای شروع جست‌وجو
        
        خروجی:
            TreeNode یا None
        """
        # اگر گره شروع مشخص نشده، از ریشه شروع می‌کنیم
        if current is None:
            current = self.root
        
        # اگر درخت خالی است
        if current is None:
            return None
        
        # اگر گره فعلی همان گره مورد نظر است
        if current.name == name:
            return current
        
        # جست‌وجو در فرزندان (به صورت عمقی)
        if current.left_child is not None:
            result = self.find_node(name, current.left_child)
            if result is not None:
                return result
        
        # جست‌وجو در خواهر/برادرها
        if current.right_sibling is not None:
            result = self.find_node(name, current.right_sibling)
            if result is not None:
                return result
        
        return None
    
    def add_member(self, parent_name, name, age):
        """
        افزودن عضو جدید به درخت خانوادگی
        
        ورودی:
            parent_name (str): نام والد ("None" برای ریشه)
            name (str): نام فرد جدید
            age (int): سن فرد جدید
        """
        # بررسی تکراری بودن نام
        if self.find_node(name) is not None:
            print("duplicate name")
            return
        
        # ایجاد گره جدید
        new_node = TreeNode(name, age)
        
        #  حالت افزودن ریشه (parent_name == "None")
        if parent_name == "None":
            # بررسی وجود ریشه قبلی
            if self.root is not None:
                print("root already exists")
                return
            
            # تنظیم ریشه جدید
            self.root = new_node
            print(f"member {name} successfully added")
            return
        
        # حالت 2: افزودن فرزند به والد موجود
        parent_node = self.find_node(parent_name)
        
        # بررسی وجود والد
        if parent_node is None:
            print("parent not found")
            return
        
        # تنظیم والد برای گره جدید
        new_node.parent = parent_node
        
        # اگر والد هیچ فرزندی ندارد
        if parent_node.left_child is None:
            parent_node.left_child = new_node
            print(f"member {name} successfully added")
            return
        
        # اگر والد فرزندان دارد، باید در جای مناسب (بر اساس سن نزولی) درج شود
        # حالت: فرزند جدید مسن‌تر از اولین فرزند است
        if age > parent_node.left_child.age:
            new_node.right_sibling = parent_node.left_child
            parent_node.left_child = new_node
            print(f"member {name} successfully added")
            return
        
        # پیدا کردن موقعیت مناسب بین فرزندان (مرتب‌سازی نزولی)
        current = parent_node.left_child
        while current.right_sibling is not None:
            if age > current.right_sibling.age:
                # درج بین current و current.right_sibling
                new_node.right_sibling = current.right_sibling
                current.right_sibling = new_node
                print(f"member {name} successfully added")
                return
            current = current.right_sibling
        
        # درج در انتها (جوان‌ترین فرزند)
        current.right_sibling = new_node
        print(f"member {name} successfully added")
    
    def delete_member(self, name):
        """
        حذف عضو و تمام فرزندان و نوادگانش از درخت
        
        ورودی:
            name (str): نام فرد مورد نظر برای حذف
        """
        # بررسی خالی بودن درخت
        if self.root is None:
            print("empty tree")
            return
        
        # جست‌وجوی گره
        node_to_delete = self.find_node(name)
        
        # بررسی وجود گره
        if node_to_delete is None:
            print("not found")
            return
        
        # حالت 1: حذف ریشه
        if node_to_delete == self.root:
            self.root = None
            print(f"member {name} deleted")
            return
        
        # حالت 2: حذف گره غیر ریشه
        parent = node_to_delete.parent
        
        # اگر گره مورد نظر اولین فرزند والد است
        if parent.left_child == node_to_delete:
            parent.left_child = node_to_delete.right_sibling
        else:
            # پیدا کردن خواهر/برادر قبلی
            current = parent.left_child
            while current.right_sibling != node_to_delete:
                current = current.right_sibling
            
            # حذف گره از زنجیره خواهر/برادرها
            current.right_sibling = node_to_delete.right_sibling
        
        print(f"member {name} deleted")
    
    def find_member(self, name):
        """
        جست‌وجو و نمایش اطلاعات فرد
        
        ورودی:
            name (str): نام فرد مورد جست‌وجو
        """
        # بررسی خالی بودن درخت
        if self.root is None:
            print("empty tree")
            return
        
        # جست‌وجوی گره
        node = self.find_node(name)
        
        # بررسی وجود گره
        if node is None:
            print("not found")
            return
        
        # نمایش اطلاعات
        print(f"Found : name : {node.name} , age : {node.age}")
    
    def get_ancestors(self, name):
        """
        نمایش اجداد فرد از نزدیک‌ترین به دورترین
        
        ورودی:
            name (str): نام فرد
        """
        # بررسی خالی بودن درخت
        if self.root is None:
            print("empty tree")
            return
        
        # جست‌وجوی گره
        node = self.find_node(name)
        
        # بررسی وجود گره
        if node is None:
            print("not found")
            return
        
        # بررسی وجود والد
        if node.parent is None:
            print("no ancestors")
            return
        
        # جمع‌آوری نام اجداد
        ancestors = []
        current = node.parent
        while current is not None:
            ancestors.append(current.name)
            current = current.parent
        
        # نمایش اجداد
        print(f"ancestors of {name} : {' -> '.join(ancestors)}")


def main():
    """
    تابع اصلی برنامه - دریافت دستورات و اجرای عملیات‌ها
    """
    # ایجاد درخت خانوادگی
    family_tree = FamilyTree()
    
    # حلقه اصلی برنامه که تا دریافت دستور EXIT ادامه می‌یابد
    while True:
        try:
            # دریافت دستور از کاربر
            command_line = input().strip()
            
            # بررسی خالی بودن دستور
            if not command_line:
                print("invalid input")
                continue
            
            # تجزیه دستور به قسمت‌های مختلف
            command_parts = command_line.split()
            
            # بررسی وجود دستور
            if len(command_parts) == 0:
                print("invalid input")
                continue
            
            # دریافت نام دستور (بدون تبدیل به حروف بزرگ)
            command = command_parts[0]
            
            # پردازش دستور ADD
            if command == "ADD":
                # بررسی تعداد پارامترهای صحیح (باید 4 قسمت باشد)
                if len(command_parts) != 4:
                    print("invalid input")
                    continue
                
                try:
                    # دریافت پارامترها
                    parent_name = command_parts[1]
                    name = command_parts[2]

                        # بررسی اینکه رشته فقط عدد صحیح مثبت بدون صفر پیشرو باشد
                    if not command_parts[3].isdigit() or command_parts[3].startswith("0"):
                        print("invalid input")
                        continue
                    
                    age = int(command_parts[3])
                    
                    # بررسی مثبت بودن سن
                    if age <= 0:
                        print("invalid input")
                        continue
                    
                    # فراخوانی متد افزودن
                    family_tree.add_member(parent_name, name, age)
                
                except ValueError:
                    # اگر سن یک عدد صحیح نباشد
                    print("invalid input")
            
            # پردازش دستور DELETE
            elif command == "DELETE":
                # بررسی تعداد پارامترهای صحیح (باید 2 قسمت باشد)
                if len(command_parts) != 2:
                    print("invalid input")
                    continue
                
                # دریافت نام فرد برای حذف
                name = command_parts[1]
                
                # فراخوانی متد حذف
                family_tree.delete_member(name)
            
            # پردازش دستور FIND
            elif command == "FIND":
                # بررسی تعداد پارامترهای صحیح (باید 2 قسمت باشد)
                if len(command_parts) != 2:
                    print("invalid input")
                    continue
                
                # دریافت نام فرد برای جست‌وجو
                name = command_parts[1]
                
                # فراخوانی متد جست‌وجو
                family_tree.find_member(name)
            
            # پردازش دستور GET_ANCESTORS
            elif command == "GET_ANCESTORS":
                # بررسی تعداد پارامترهای صحیح (باید 2 قسمت باشد)
                if len(command_parts) != 2:
                    print("invalid input")
                    continue
                
                # دریافت نام فرد
                name = command_parts[1]
                
                # فراخوانی متد نمایش اجداد
                family_tree.get_ancestors(name)
            
            # پردازش دستور EXIT
            elif command == "EXIT":
                # چاپ پیام پایان و خروج از برنامه
                print("program terminated")
                break
            
            # دستور نامعتبر
            else:
                print("invalid input")
        
        except EOFError:
            # در صورت پایان ورودی، برنامه خاتمه می‌یابد
            break
        
        except Exception:
            # مدیریت خطاهای غیرمنتظره
            print("invalid input")


# نقطه شروع برنامه
if __name__ == "__main__":
    main()